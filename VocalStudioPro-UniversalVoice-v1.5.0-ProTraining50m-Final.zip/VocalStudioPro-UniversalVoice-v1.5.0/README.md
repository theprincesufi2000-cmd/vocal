# Vocal Studio Pro v1.5.0 — Pro Training 50m + Universal RVC

Native Android vocal studio built with Kotlin/Jetpack Compose, JNI and C++17 DSP.

## Highlights

- Offline vocal recording/import.
- StudioClean spectral denoise, hum removal and mastering.
- Key-aware Auto-Tune.
- Universal RVC/Applio ONNX import and adaptive fixed/dynamic frame inference.
- **VSPTRAIN3 Pro Voice Training** from isolated voice recordings up to 50 minutes.
- Saved local voice profiles can be selected, exported and imported later.
- 48 kHz / 24-bit WAV output.

## Pro Training 50m

VSPTRAIN3 is designed for mobile training without huge RAM use. It streams the source file, learns a 96-band timbre model, voiced/unvoiced behavior, four pitch registers and 30 adaptive timbre prototypes. During inference it protects consonants and leaves timing/F0 intact to reduce pronunciation damage.

For the strongest local profile, use 10-50 minutes of clean isolated vocal audio. More duration does not compensate for reverb, clipping or background music.

This local trainer is an adaptive speaker-timbre model rather than a full RVC/VITS generator training run. Full RVC neural models can still be imported as ONNX and combined with the trained local profile.

## Android toolchain

- compileSdk / targetSdk: 37
- minSdk: 26
- JDK: 17
- Gradle: 9.6.0
- AGP: 9.4.0
- NDK: 28.2.13676358
- CMake: 3.22.1
- ONNX Runtime Android: 1.29.0

## GitHub Actions

Upload `VocalStudioPro-UniversalVoice-v1.5.0-ProTraining50m-Final.zip` to the repository root and use the included `.github/workflows/build.yml`.

package com.mustafa.vocalstudio.voice

import java.io.File

data class TrainedVoiceProfile(
    val id: String,
    val name: String,
    val file: File,
    val createdAt: Long,
    val sourceSeconds: Float
)

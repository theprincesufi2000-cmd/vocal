package com.mustafa.vocalstudio.voice

import android.content.Context
import android.net.Uri
import com.mustafa.vocalstudio.dsp.NativeDsp
import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.util.Properties
import java.util.UUID

class VoiceProfileManager(private val context: Context) {
    private val dir = File(context.filesDir, "trained_voice_profiles").apply { mkdirs() }

    fun listProfiles(): List<TrainedVoiceProfile> = dir.listFiles { f ->
        f.isFile && f.extension.equals("vsptrain", true)
    }?.mapNotNull(::readProfile)?.sortedByDescending { it.createdAt } ?: emptyList()

    fun trainFromWav(input: File, requestedName: String): TrainedVoiceProfile {
        require(input.isFile) { "ملف التدريب غير موجود" }
        val info = WavUtils.readInfo(input)
        val bytesPerFrame = (info.bitsPerSample / 8).coerceAtLeast(1) * info.channels.coerceAtLeast(1)
        val frames = info.dataSize.toDouble() / bytesPerFrame
        val seconds = (frames / info.sampleRate.coerceAtLeast(1)).toFloat()
        require(seconds >= 5f) { "مقطع التدريب قصير جدًا؛ الحد الأدنى التقني 5 ثوانٍ" }
        require(seconds <= 50f * 60f + 0.5f) { "الحد الأقصى للتدريب الاحترافي هو 50 دقيقة" }

        val name = requestedName.trim().ifBlank { "نموذج صوتي ${System.currentTimeMillis()}" }.take(80)
        val id = UUID.randomUUID().toString().replace("-", "")
        val target = File(dir, "$id.vsptrain")
        val code = NativeDsp.trainVoiceProfile(input.absolutePath, target.absolutePath)
        if (code != 0 || !target.isFile || target.length() < 100) {
            target.delete()
            error("فشل تدريب النموذج المحلي (code=$code)")
        }
        val meta = Properties().apply {
            setProperty("name", name)
            setProperty("createdAt", System.currentTimeMillis().toString())
            setProperty("sourceSeconds", seconds.toString())
            setProperty("format", "VSPTRAIN3")
        }
        File(dir, "$id.properties").outputStream().use { meta.store(it, "VocalStudioPro trained voice profile") }
        return readProfile(target) ?: error("تعذر قراءة النموذج بعد التدريب")
    }

    fun remove(profile: TrainedVoiceProfile) {
        profile.file.delete()
        File(dir, "${profile.id}.properties").delete()
    }

    fun importProfile(uri: Uri): TrainedVoiceProfile {
        val id = UUID.randomUUID().toString().replace("-", "")
        val target = File(dir, "$id.vsptrain")
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "تعذر فتح ملف النموذج" }
                target.outputStream().use { out -> input.copyTo(out, 256 * 1024) }
            }
            require(target.length() in 100L..(8L * 1024L * 1024L)) { "حجم نموذج VSPTRAIN غير صالح" }
            require(NativeDsp.validateVoiceProfile(target.absolutePath) == 0) { "ملف VSPTRAIN غير مدعوم أو تالف" }
            val meta = Properties().apply {
                setProperty("name", "نموذج مستورد")
                setProperty("createdAt", System.currentTimeMillis().toString())
                setProperty("sourceSeconds", "0")
                setProperty("format", "VSPTRAIN")
            }
            File(dir, "$id.properties").outputStream().use { meta.store(it, "VocalStudioPro imported trained voice profile") }
            return readProfile(target) ?: error("تعذر تسجيل النموذج المستورد")
        } catch (t: Throwable) {
            target.delete()
            File(dir, "$id.properties").delete()
            throw t
        }
    }

    fun exportProfile(profile: TrainedVoiceProfile, uri: Uri) {
        context.contentResolver.openOutputStream(uri, "w").use { out ->
            requireNotNull(out) { "تعذر فتح مكان حفظ النموذج" }
            profile.file.inputStream().use { it.copyTo(out, 256 * 1024) }
        }
    }

    private fun readProfile(file: File): TrainedVoiceProfile? {
        if (NativeDsp.validateVoiceProfile(file.absolutePath) != 0) return null
        val id = file.nameWithoutExtension
        val metaFile = File(dir, "$id.properties")
        val p = Properties()
        if (metaFile.isFile) runCatching { metaFile.inputStream().use(p::load) }
        return TrainedVoiceProfile(
            id = id,
            name = p.getProperty("name")?.takeIf { it.isNotBlank() } ?: "نموذج صوتي مدرب",
            file = file,
            createdAt = p.getProperty("createdAt")?.toLongOrNull() ?: file.lastModified(),
            sourceSeconds = p.getProperty("sourceSeconds")?.toFloatOrNull() ?: 0f
        )
    }
}

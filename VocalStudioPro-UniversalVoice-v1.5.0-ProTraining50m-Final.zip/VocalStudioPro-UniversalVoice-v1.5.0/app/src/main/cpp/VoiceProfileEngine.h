#pragma once
#include <string>

class VoiceProfileEngine {
public:
    static int train(const std::string& inputPath, const std::string& profilePath, std::string& error);
    static int apply(const std::string& inputPath, const std::string& outputPath,
                     const std::string& profilePath, float strength, std::string& error);
    static int validate(const std::string& profilePath, std::string& error);
};

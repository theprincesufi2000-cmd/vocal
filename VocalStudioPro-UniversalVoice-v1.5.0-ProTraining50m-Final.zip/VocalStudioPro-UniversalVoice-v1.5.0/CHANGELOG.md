# Changelog

## 1.5.0 — Pro Training 50m

- Replaced the simple 64-band VSPTRAIN1 trainer with backward-compatible **VSPTRAIN3**.
- Added streaming training for source recordings up to **50 minutes** without loading the full file into RAM.
- Added 96-band normalized vocal-envelope learning.
- Added voiced/unvoiced separation and four pitch-register models.
- Added 30 adaptive target-envelope prototypes using online clustering.
- Added input noise-floor, clipping and clean-voice analysis.
- Added pronunciation protection for consonant/unvoiced frames during application.
- Added bounded temporal/frequency smoothing and dry articulation preservation.
- VSPTRAIN1 files remain importable/applicable.
- Updated UI copy and long-training status messages.
- Version bumped to `1.5.0` / `versionCode 11`.

## 1.4.0 — Saved Voice Training

- Added reusable local `.vsptrain` profiles and import/export.

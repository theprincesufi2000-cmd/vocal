# Vocal Studio Pro 1.5.0 — Verification

- versionName: 1.5.0
- versionCode: 11
- C++/JNI strict compile: tested with `-Wall -Wextra -Werror`.
- VSPTRAIN3 train/validate/apply: tested end-to-end.
- Training source test: 90 s / 48 kHz / PCM16.
- Output: 48 kHz / PCM24 with source frame count preserved.
- Profile size in synthetic test: ~15 KB.
- Max RSS in synthetic train+apply test: ~73 MB.
- 50-minute hard limit: verified via header/duration validation; 50:01 is rejected before processing.
- Existing RVC/Applio adaptive-frame engine retained.

A full Android `assembleRelease` is delegated to the included GitHub Actions workflow when the local environment does not contain the Android SDK/Maven dependency set.

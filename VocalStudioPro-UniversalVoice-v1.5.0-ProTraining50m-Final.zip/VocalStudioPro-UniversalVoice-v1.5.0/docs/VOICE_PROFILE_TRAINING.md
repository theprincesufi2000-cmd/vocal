# Pro Voice Training 50m (.vsptrain)

VocalStudioPro 1.5.0 upgrades the reusable local trainer to **VSPTRAIN3**.

## What it is

This is an offline, on-device **speaker-timbre adaptation model**, optimized for Android and long recordings. It is deliberately content-preserving: it does not rewrite phoneme timing or force a new pitch contour. The learned model is applied as a bounded dynamic spectral-envelope transfer stage, with consonant/unvoiced protection.

It is not a full RVC/VITS generator training run. Full RVC training remains a GPU-oriented workflow that uses pretrained neural checkpoints. RVC/Applio ONNX models can still be imported and used by the app, and VSPTRAIN3 can optionally be layered with them.

## Training duration

- Technical minimum: 5 seconds.
- Recommended for useful results: 3-10 minutes of isolated clean voice.
- Recommended for maximum local-profile stability: 10-50 minutes.
- Hard maximum: 50 minutes.

The trainer reads WAV data in blocks and never loads the entire training file into RAM. This is important for 30-50 minute recordings.

## Learned representation

VSPTRAIN3 stores:

- 96 log-spaced vocal spectral bands (65 Hz to 16 kHz).
- Global mean and variance of the normalized vocal envelope.
- Separate statistics for unvoiced/consonant-rich frames and four pitch registers.
- 6 adaptive prototypes per register (30 total) learned by bounded online clustering.
- Voice activity, median F0, voiced ratio, spectral centroid, noise floor and clipping metrics.

The profile is typically only tens of kilobytes, regardless of whether the source was seconds or tens of minutes.

## Pronunciation protection

During application the engine:

1. Keeps the source timing and F0 contour unchanged.
2. Reduces timbre forcing on unvoiced/consonant-rich frames.
3. Reduces processing in extreme low and air bands.
4. Smooths transfer over frequency and time.
5. Keeps a dry articulation component in the final blend.

This design reduces metallic consonants and intelligibility loss compared with forcing every frame to a single average spectral target.

## Best training data

Use isolated, dry vocal audio with minimal room echo, music, clipping or heavy denoising. Consistent microphone position and timbre help. A single clean 15-minute source is normally more useful than 50 minutes of mixed-quality audio.

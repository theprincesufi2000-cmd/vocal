# Changelog

## 1.3.0 — Universal Voice Model Import

- Added one-picker universal importer for ZIP / VSPVOICE / ONNX / RVC PTH / INDEX.
- Added recursive ZIP discovery and automatic handling of an extra top-level folder.
- Added ONNX signature probing for RVC synthesizer/content/pitch roles.
- Added shared Content Encoder core installation and automatic completion of waiting models.
- Added honest RVC `.pth + .index` cataloguing with `CONVERSION_REQUIRED` state.
- Added optional pitch ONNX with native C++ F0 fallback.
- Added raw RMVPE salience detection so 360-bin outputs are not treated as Hz.
- Added model readiness/status UI and rights-confirmation gate.
- Increased secure importer limits for large voice-model ZIPs and reduced temporary duplication by moving staged files where possible.
- Kept StudioClean, Auto-Tune, 24-bit WAV, NNAPI/XNNPACK/CPU fallback, and long-file overlap processing.
- versionCode 5 / versionName 1.3.0.

## 1.2.0

- Added local ONNX voice-conversion packs and VSPVOICE format.

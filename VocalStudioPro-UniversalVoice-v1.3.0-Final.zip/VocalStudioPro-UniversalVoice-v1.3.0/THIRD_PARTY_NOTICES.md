# Third-party notices

The native DSP source under `app/src/main/cpp` is self-contained project code and does not embed FFmpegKit, SoundTouch, aubio, Autotalent, or Signalsmith Stretch.

The Android application references AndroidX / Jetpack Compose artifacts from Google's Maven repositories during build. Those components remain subject to their respective licenses.

The Android SDK, Android NDK, CMake, Gradle and Android Gradle Plugin are build tools and are not redistributed inside this source archive.

## ONNX Runtime Android
- Package: `com.microsoft.onnxruntime:onnxruntime-android:1.29.0`
- Project: Microsoft ONNX Runtime
- License: MIT
- Used for local ONNX model inference. Voice model weights are not bundled with this source release.

## RVC interface compatibility
The optional voice-conversion runtime implements the tensor interface used by the RVC ONNX exporter. No RVC pretrained voice weights or third-party speaker models are bundled in this repository.

package com.mustafa.vocalstudio.voice

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import com.mustafa.vocalstudio.dsp.NativeDsp
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.util.Random
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Offline RVC-style ONNX voice conversion runtime.
 *
 * Pack contract:
 *  - content_encoder.onnx: one float audio input -> phone/features tensor.
 *  - pitch.onnx: one float audio input -> F0 in Hz.
 *  - voice.onnx: official RVC ONNX inputs phone, phone_lengths, pitch, pitchf, ds, rnd.
 *
 * The app intentionally does not ship a person's voice model. Models are imported locally.
 */
class VoiceConversionEngine {
    data class Stats(
        val provider: String,
        val usedNnapi: Boolean,
        val chunks: Int,
        val sampleRate: Int,
        val durationSeconds: Double
    )

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()

    fun convert(
        inputWav: File,
        outputWav: File,
        model: VoiceModel,
        params: VoiceConversionParams,
        onProgress: (Float) -> Unit = {}
    ): Stats {
        model.validateReady()
        require(params.enabled) { "Voice Conversion غير مفعل" }

        val source = VoiceWavIO.readMonoFloat(inputWav)
        require(source.samples.size >= source.sampleRate / 3) { "الصوت أقصر من اللازم للتحويل" }

        val quality = qualityConfig(params.quality)
        val sessions = SessionBundle.open(env, model, quality.threads, params.preferNnapi)
        try {
            val totalOutSamples = ceil(source.samples.size.toDouble() * model.sampleRate / source.sampleRate).toInt()
            val mixAccum = FloatArray(totalOutSamples)
            val weightAccum = FloatArray(totalOutSamples)

            val chunkSamples = (quality.chunkSeconds * source.sampleRate).roundToInt().coerceAtLeast(source.sampleRate)
            val overlapSamples = (quality.overlapSeconds * source.sampleRate).roundToInt().coerceAtLeast(1)
            val step = (chunkSamples - overlapSamples).coerceAtLeast(source.sampleRate / 2)
            val starts = buildChunkStarts(source.samples.size, chunkSamples, step)

            starts.forEachIndexed { chunkIndex, start ->
                val end = minOf(source.samples.size, start + chunkSamples)
                val chunk = source.samples.copyOfRange(start, end)
                val chunkResult = convertChunk(chunk, source.sampleRate, model, params, sessions, chunkIndex)

                val expectedLen = ((end - start).toDouble() * model.sampleRate / source.sampleRate)
                    .roundToInt()
                    .coerceAtLeast(1)
                val exact = VoiceWavIO.resizeLinear(chunkResult.audio, expectedLen)
                val original = VoiceWavIO.resizeLinear(
                    if (source.sampleRate == model.sampleRate) chunk else VoiceWavIO.resampleSinc(chunk, source.sampleRate, model.sampleRate),
                    expectedLen
                )

                val blended = FloatArray(expectedLen)
                for (i in blended.indices) {
                    val f0Index = if (chunkResult.f0.isEmpty()) 0 else
                        ((i.toLong() * chunkResult.f0.size) / expectedLen.coerceAtLeast(1)).toInt().coerceIn(0, chunkResult.f0.lastIndex)
                    val unvoiced = chunkResult.f0.getOrElse(f0Index) { 0f } <= 20f
                    val protect = if (unvoiced) params.consonantProtect.coerceIn(0f, 1f) else 0f
                    val convertedShare = (params.mix.coerceIn(0f, 1f) * (1f - protect)).coerceIn(0f, 1f)
                    blended[i] = (exact[i] * convertedShare + original[i] * (1f - convertedShare)).coerceIn(-1.2f, 1.2f)
                }

                val outStart = (start.toDouble() * model.sampleRate / source.sampleRate).roundToInt()
                val overlapOut = (overlapSamples.toDouble() * model.sampleRate / source.sampleRate).roundToInt().coerceAtLeast(1)
                val hasLeft = start > 0
                val hasRight = end < source.samples.size

                for (i in blended.indices) {
                    val dst = outStart + i
                    if (dst !in mixAccum.indices) break
                    var w = 1f
                    if (hasLeft && i < overlapOut) w *= i.toFloat() / overlapOut.toFloat()
                    if (hasRight && i >= blended.size - overlapOut) {
                        w *= (blended.size - 1 - i).coerceAtLeast(0).toFloat() / overlapOut.toFloat()
                    }
                    w = w.coerceIn(0.001f, 1f)
                    mixAccum[dst] += blended[i] * w
                    weightAccum[dst] += w
                }

                onProgress((chunkIndex + 1f) / starts.size.coerceAtLeast(1))
            }

            for (i in mixAccum.indices) {
                val w = weightAccum[i]
                if (w > 1e-6f) mixAccum[i] /= w
            }

            VoiceWavIO.writeMono24(outputWav, mixAccum, model.sampleRate)
            return Stats(
                provider = sessions.provider,
                usedNnapi = sessions.provider == "NNAPI",
                chunks = starts.size,
                sampleRate = model.sampleRate,
                durationSeconds = source.samples.size.toDouble() / source.sampleRate.toDouble()
            )
        } finally {
            sessions.close()
        }
    }

    private data class ChunkResult(val audio: FloatArray, val f0: FloatArray)

    private fun convertChunk(
        sourceChunk: FloatArray,
        sourceRate: Int,
        model: VoiceModel,
        params: VoiceConversionParams,
        sessions: SessionBundle,
        chunkIndex: Int
    ): ChunkResult {
        val contentAudio = if (sourceRate == model.contentSampleRate) sourceChunk
            else VoiceWavIO.resampleSinc(sourceChunk, sourceRate, model.contentSampleRate)

        var features = runContent(sessions.content, model, contentAudio)
        if (model.featureUpsample > 1) {
            features = upsampleFeatures(features, model.featureUpsample)
        }

        var f0 = if (sessions.pitch != null) {
            runPitch(sessions.pitch, model, contentAudio)
        } else {
            NativeDsp.extractF0(
                samples = contentAudio,
                sampleRate = model.contentSampleRate,
                frameCount = features.frames,
                minHz = 50f,
                maxHz = 1_100f
            )
        }
        f0 = resampleF0(f0, features.frames)

        val transposeFactor = 2.0.pow(params.transposeSemitones.coerceIn(-24f, 24f) / 12.0).toFloat()
        for (i in f0.indices) {
            if (f0[i] > 20f) f0[i] = (f0[i] * transposeFactor).coerceIn(20f, 2_000f)
            else f0[i] = 0f
        }
        val coarse = coarsePitch(f0)

        val rnd = gaussianNoise(192 * features.frames, seed = 0x51A7L + chunkIndex)
        val inputs = linkedMapOf<String, OnnxTensor>()
        try {
            inputs[model.voicePhoneInput] = floatTensor(features.data, longArrayOf(1, features.frames.toLong(), features.channels.toLong()))
            inputs[model.voicePhoneLengthsInput] = longTensor(longArrayOf(features.frames.toLong()), longArrayOf(1))
            inputs[model.voicePitchInput] = longTensor(coarse, longArrayOf(1, features.frames.toLong()))
            inputs[model.voicePitchFInput] = floatTensor(f0, longArrayOf(1, features.frames.toLong()))
            inputs[model.voiceSpeakerInput] = longTensor(longArrayOf(model.speakerId), longArrayOf(1))
            inputs[model.voiceNoiseInput] = floatTensor(rnd, longArrayOf(1, 192, features.frames.toLong()))

            sessions.voice.run(inputs).use { result ->
                val value = result.get(model.voiceOutput).orElseThrow {
                    IllegalStateException("مخرج ${model.voiceOutput} غير موجود في voice.onnx")
                }
                require(value is OnnxTensor) { "مخرج voice.onnx ليس Tensor" }
                val audio = value.floatBuffer?.copyToArray()
                    ?: error("مخرج voice.onnx ليس Float tensor")
                return ChunkResult(audio, f0)
            }
        } finally {
            inputs.values.forEach { runCatching { it.close() } }
        }
    }

    private data class FeatureMatrix(val data: FloatArray, val frames: Int, val channels: Int)

    private fun runContent(session: OrtSession, model: VoiceModel, audio: FloatArray): FeatureMatrix {
        val shape = if (model.contentInputRank == 3) longArrayOf(1, 1, audio.size.toLong())
        else longArrayOf(1, audio.size.toLong())
        floatTensor(audio, shape).use { input ->
            session.run(mapOf(model.contentInput to input)).use { result ->
                val value = result.get(model.contentOutput).orElseThrow {
                    IllegalStateException("مخرج ${model.contentOutput} غير موجود في content_encoder.onnx")
                }
                require(value is OnnxTensor) { "مخرج content encoder ليس Tensor" }
                val info = value.info as TensorInfo
                val dims = info.shape
                val raw = value.floatBuffer?.copyToArray() ?: error("Content features ليست Float")

                val (frames, channels) = when (dims.size) {
                    3 -> if (model.contentOutputLayout == "BTC") dims[1].toInt() to dims[2].toInt()
                        else dims[2].toInt() to dims[1].toInt()
                    2 -> if (model.contentOutputLayout == "BTC") dims[0].toInt() to dims[1].toInt()
                        else dims[1].toInt() to dims[0].toInt()
                    else -> error("رتبة مخرج ContentVec غير مدعومة: ${dims.contentToString()}")
                }
                require(frames > 0 && channels > 0) { "Content features فارغة" }
                require(channels == model.featureChannels) {
                    "عدد قنوات features=$channels لا يطابق metadata=${model.featureChannels}"
                }

                if (model.contentOutputLayout == "BTC") {
                    require(raw.size >= frames * channels)
                    return FeatureMatrix(raw.copyOf(frames * channels), frames, channels)
                }

                // BCT/CT -> transpose into time-major BTC layout expected by official RVC ONNX.
                val transposed = FloatArray(frames * channels)
                for (c in 0 until channels) {
                    for (t in 0 until frames) {
                        transposed[t * channels + c] = raw[c * frames + t]
                    }
                }
                return FeatureMatrix(transposed, frames, channels)
            }
        }
    }

    private fun runPitch(session: OrtSession, model: VoiceModel, audio: FloatArray): FloatArray {
        val shape = if (model.pitchInputRank == 3) longArrayOf(1, 1, audio.size.toLong())
        else longArrayOf(1, audio.size.toLong())
        floatTensor(audio, shape).use { input ->
            session.run(mapOf(model.pitchInput to input)).use { result ->
                val value = result.get(model.pitchOutput).orElseThrow {
                    IllegalStateException("مخرج ${model.pitchOutput} غير موجود في pitch.onnx")
                }
                require(value is OnnxTensor) { "مخرج pitch ليس Tensor" }
                val raw = value.floatBuffer?.copyToArray() ?: error("Pitch output ليس Float")
                return raw.mapToFloatArray { v -> if (v.isFinite() && v in 20f..2_000f) v else 0f }
            }
        }
    }

    private fun upsampleFeatures(input: FeatureMatrix, factor: Int): FeatureMatrix {
        if (factor <= 1) return input
        val outFrames = input.frames * factor
        val out = FloatArray(outFrames * input.channels)
        for (t in 0 until outFrames) {
            val p = t.toDouble() / factor.toDouble()
            val a = floor(p).toInt().coerceIn(0, input.frames - 1)
            val b = (a + 1).coerceAtMost(input.frames - 1)
            val mix = (p - a).toFloat()
            for (c in 0 until input.channels) {
                val av = input.data[a * input.channels + c]
                val bv = input.data[b * input.channels + c]
                out[t * input.channels + c] = av * (1f - mix) + bv * mix
            }
        }
        return FeatureMatrix(out, outFrames, input.channels)
    }

    private fun resampleF0(input: FloatArray, frames: Int): FloatArray {
        if (frames <= 0) return FloatArray(0)
        if (input.isEmpty()) return FloatArray(frames)
        if (input.size == frames) return input.copyOf()
        if (frames == 1) return floatArrayOf(input.first())
        val out = FloatArray(frames)
        val scale = (input.size - 1).toDouble() / (frames - 1).toDouble()
        for (i in out.indices) {
            val p = i * scale
            val a = floor(p).toInt().coerceIn(input.indices)
            val b = (a + 1).coerceAtMost(input.lastIndex)
            val t = (p - a).toFloat()
            val av = input[a]
            val bv = input[b]
            out[i] = when {
                av <= 20f && bv <= 20f -> 0f
                av <= 20f -> if (t > 0.65f) bv else 0f
                bv <= 20f -> if (t < 0.35f) av else 0f
                else -> av * (1f - t) + bv * t
            }
        }
        return out
    }

    private fun coarsePitch(f0: FloatArray): LongArray {
        val f0Min = 50.0
        val f0Max = 1100.0
        val melMin = 1127.0 * ln(1.0 + f0Min / 700.0)
        val melMax = 1127.0 * ln(1.0 + f0Max / 700.0)
        return LongArray(f0.size) { i ->
            val hz = f0[i].toDouble()
            var mel = if (hz > 0.0) 1127.0 * ln(1.0 + hz / 700.0) else 0.0
            if (mel > 0.0) mel = (mel - melMin) * 254.0 / (melMax - melMin) + 1.0
            mel.roundToInt().coerceIn(1, 255).toLong()
        }
    }

    private fun gaussianNoise(size: Int, seed: Long): FloatArray {
        val random = Random(seed)
        val out = FloatArray(size)
        var i = 0
        while (i < size) {
            val u1 = (random.nextDouble().coerceAtLeast(1e-12))
            val u2 = random.nextDouble()
            val mag = sqrt(-2.0 * ln(u1))
            val z0 = mag * kotlin.math.cos(2.0 * Math.PI * u2)
            val z1 = mag * kotlin.math.sin(2.0 * Math.PI * u2)
            out[i++] = z0.toFloat()
            if (i < size) out[i++] = z1.toFloat()
        }
        return out
    }

    private fun floatTensor(data: FloatArray, shape: LongArray): OnnxTensor =
        OnnxTensor.createTensor(env, directFloatBuffer(data), shape)

    private fun longTensor(data: LongArray, shape: LongArray): OnnxTensor =
        OnnxTensor.createTensor(env, directLongBuffer(data), shape)

    private fun directFloatBuffer(data: FloatArray): FloatBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buffer.put(data)
        buffer.rewind()
        return buffer
    }

    private fun directLongBuffer(data: LongArray): LongBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 8).order(ByteOrder.nativeOrder()).asLongBuffer()
        buffer.put(data)
        buffer.rewind()
        return buffer
    }

    private fun FloatBuffer.copyToArray(): FloatArray {
        val dup = duplicate()
        dup.rewind()
        return FloatArray(dup.remaining()).also { dup.get(it) }
    }

    private inline fun FloatArray.mapToFloatArray(transform: (Float) -> Float): FloatArray =
        FloatArray(size) { i -> transform(this[i]) }

    private fun buildChunkStarts(totalSamples: Int, chunkSamples: Int, step: Int): List<Int> {
        if (totalSamples <= chunkSamples) return listOf(0)
        val starts = ArrayList<Int>()
        var start = 0
        while (start + chunkSamples < totalSamples) {
            starts += start
            start += step
        }
        val finalStart = (totalSamples - chunkSamples).coerceAtLeast(0)
        if (starts.isEmpty() || starts.last() != finalStart) starts += finalStart
        return starts.distinct()
    }

    private data class QualityConfig(val chunkSeconds: Double, val overlapSeconds: Double, val threads: Int)

    private fun qualityConfig(q: VoiceQuality): QualityConfig {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
        return when (q) {
            VoiceQuality.FAST -> QualityConfig(4.0, 0.20, minOf(2, cores))
            VoiceQuality.BALANCED -> QualityConfig(6.0, 0.30, minOf(4, cores))
            VoiceQuality.ULTRA -> QualityConfig(8.0, 0.40, minOf(6, cores))
        }
    }

    private data class SessionBundle(
        val content: OrtSession,
        val pitch: OrtSession?,
        val voice: OrtSession,
        val provider: String
    ) : AutoCloseable {
        override fun close() {
            runCatching { content.close() }
            pitch?.let { runCatching { it.close() } }
            runCatching { voice.close() }
        }

        companion object {
            private enum class Provider { NNAPI, XNNPACK, CPU }

            fun open(env: OrtEnvironment, model: VoiceModel, threads: Int, preferNnapi: Boolean): SessionBundle {
                if (preferNnapi) {
                    openWithProvider(env, model, threads, Provider.NNAPI)?.let { return it }
                }
                openWithProvider(env, model, threads, Provider.XNNPACK)?.let { return it }
                return openWithProvider(env, model, threads, Provider.CPU)
                    ?: error("تعذر فتح نماذج ONNX على NNAPI/XNNPACK/CPU")
            }

            private fun openWithProvider(
                env: OrtEnvironment,
                model: VoiceModel,
                threads: Int,
                provider: Provider
            ): SessionBundle? = runCatching {
                val c = create(env, model.contentModel, threads, provider)
                try {
                    val p = if (model.hasPitchModel) create(env, model.pitchModel, threads, provider) else null
                    try {
                        val v = create(env, model.voiceModel, threads, provider)
                        SessionBundle(c, p, v, provider.name)
                    } catch (t: Throwable) {
                        p?.close()
                        throw t
                    }
                } catch (t: Throwable) {
                    c.close()
                    throw t
                }
            }.getOrNull()

            private fun create(
                env: OrtEnvironment,
                file: File,
                threads: Int,
                provider: Provider
            ): OrtSession {
                val options = OrtSession.SessionOptions()
                try {
                    options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                    options.setInterOpNumThreads(1)
                    options.setMemoryPatternOptimization(true)
                    when (provider) {
                        Provider.NNAPI -> {
                            options.setIntraOpNumThreads(threads.coerceAtLeast(1))
                            options.addNnapi()
                        }
                        Provider.XNNPACK -> {
                            // XNNPACK owns its worker pool; keep ORT's CPU pool minimal.
                            options.setIntraOpNumThreads(1)
                            options.addXnnpack(
                                mapOf("intra_op_num_threads" to threads.coerceAtLeast(1).toString())
                            )
                        }
                        Provider.CPU -> options.setIntraOpNumThreads(threads.coerceAtLeast(1))
                    }
                    return env.createSession(file.absolutePath, options)
                } finally {
                    options.close()
                }
            }
        }
    }
}

package com.mustafa.vocalstudio.voice

import org.json.JSONObject
import java.io.File

enum class VoiceModelState {
    READY,
    CONVERSION_REQUIRED,
    MISSING_CORE,
    INCOMPLETE
}

enum class VoiceSourceFormat {
    VSPVOICE,
    RVC_ONNX,
    RVC_PYTORCH,
    ONNX_GENERIC,
    UNKNOWN
}

/**
 * Installed local voice model descriptor.
 *
 * READY models are directly executable by the Android ONNX runtime path.
 * PyTorch RVC checkpoints (.pth) can be imported and catalogued, but a raw
 * state-dict checkpoint is not directly executable by ONNX Runtime. Such
 * models are marked CONVERSION_REQUIRED instead of failing or pretending that
 * they can run.
 */
data class VoiceModel(
    val id: String,
    val name: String,
    val author: String,
    val engine: String,
    val sampleRate: Int,
    val contentSampleRate: Int,
    val featureChannels: Int,
    val contentInput: String,
    val contentOutput: String,
    val contentInputRank: Int,
    val contentOutputLayout: String,
    val featureUpsample: Int,
    val pitchInput: String,
    val pitchOutput: String,
    val pitchInputRank: Int,
    val voicePhoneInput: String,
    val voicePhoneLengthsInput: String,
    val voicePitchInput: String,
    val voicePitchFInput: String,
    val voiceSpeakerInput: String,
    val voiceNoiseInput: String,
    val voiceOutput: String,
    val speakerId: Long,
    val authorized: Boolean,
    val licenseLabel: String,
    val sourceFormat: VoiceSourceFormat,
    val state: VoiceModelState,
    val statusDetail: String,
    val contentModelName: String,
    val pitchModelName: String,
    val voiceModelName: String,
    val checkpointName: String,
    val indexName: String,
    val directory: File
) {
    private fun localFile(name: String): File {
        if (name.isBlank()) return File(directory, ".missing")
        val base = directory.canonicalFile
        val file = File(directory, name).canonicalFile
        require(file.path.startsWith(base.path + File.separator)) { "مسار ملف غير آمن داخل metadata" }
        return file
    }

    val contentModel: File get() = localFile(contentModelName)
    val pitchModel: File get() = localFile(pitchModelName)
    val voiceModel: File get() = localFile(voiceModelName)
    val checkpointFile: File get() = localFile(checkpointName)
    val indexFile: File get() = localFile(indexName)
    val coverFile: File get() = localFile("cover.png")

    val isReady: Boolean get() = state == VoiceModelState.READY
    val hasPitchModel: Boolean get() = pitchModelName.isNotBlank() && pitchModel.isFile && pitchModel.length() > 1024
    val hasIndex: Boolean get() = indexName.isNotBlank() && indexFile.isFile && indexFile.length() > 0

    fun validateInstalled() {
        require(authorized) { "لم يتم تأكيد حق استخدام النموذج" }
        require(sampleRate in 16_000..96_000) { "Sample rate غير صالح" }
        require(contentSampleRate in 8_000..48_000) { "Content sample rate غير صالح" }
        require(featureChannels in setOf(256, 768, 1024)) { "Feature channels غير مدعومة" }

        when (state) {
            VoiceModelState.READY -> validateReady()
            VoiceModelState.CONVERSION_REQUIRED -> {
                require(checkpointName.isNotBlank() && checkpointFile.isFile && checkpointFile.length() > 1024) {
                    "ملف checkpoint غير موجود"
                }
            }
            VoiceModelState.MISSING_CORE -> {
                require(voiceModelName.isNotBlank() && voiceModel.isFile && voiceModel.length() > 1024) {
                    "voice.onnx غير موجود"
                }
            }
            VoiceModelState.INCOMPLETE -> Unit
        }
    }

    fun validateReady() {
        require(authorized) { "لم يتم تأكيد حق استخدام النموذج" }
        require(state == VoiceModelState.READY) { statusDetail.ifBlank { "النموذج غير جاهز للتشغيل" } }
        require(engine == "rvc-onnx-v2" || engine == "rvc-onnx-v1" || engine == "rvc-onnx-auto") {
            "محرك نموذج غير مدعوم: $engine"
        }
        require(contentInputRank == 2 || contentInputRank == 3) { "contentInputRank يجب أن يكون 2 أو 3" }
        require(contentOutputLayout == "BTC" || contentOutputLayout == "BCT") { "contentOutputLayout يجب أن يكون BTC أو BCT" }
        require(featureUpsample in 1..4) { "featureUpsample غير صالح" }
        require(pitchInputRank == 2 || pitchInputRank == 3) { "pitchInputRank يجب أن يكون 2 أو 3" }
        require(contentModelName.isNotBlank() && contentModel.isFile && contentModel.length() > 1024) {
            "Content encoder ONNX مفقود"
        }
        require(voiceModelName.isNotBlank() && voiceModel.isFile && voiceModel.length() > 1024) {
            "Voice/RVC ONNX مفقود"
        }
        // pitch.onnx is optional in v1.3.0. Native YIN F0 is used automatically when absent.
    }

    fun formatLabel(): String = when (sourceFormat) {
        VoiceSourceFormat.VSPVOICE -> "VSPVOICE"
        VoiceSourceFormat.RVC_ONNX -> "RVC ONNX"
        VoiceSourceFormat.RVC_PYTORCH -> "RVC PTH"
        VoiceSourceFormat.ONNX_GENERIC -> "ONNX"
        VoiceSourceFormat.UNKNOWN -> "Unknown"
    }

    fun stateLabel(): String = when (state) {
        VoiceModelState.READY -> "جاهز"
        VoiceModelState.CONVERSION_REQUIRED -> "يحتاج تحويل ONNX"
        VoiceModelState.MISSING_CORE -> "يحتاج Content Encoder"
        VoiceModelState.INCOMPLETE -> "غير مكتمل"
    }

    companion object {
        fun fromDirectory(dir: File): VoiceModel {
            val metadata = File(dir, "metadata.json")
            require(metadata.isFile) { "metadata.json مفقود" }
            val json = JSONObject(metadata.readText(Charsets.UTF_8))
            val format = json.optString("format", "")
            require(format == "VSPVOICE" || format == "VSPVOICE-AUTO") { "صيغة النموذج غير مدعومة" }
            val formatVersion = json.optInt("formatVersion", 1)
            require(formatVersion in 1..2) { "إصدار حزمة الصوت غير مدعوم" }

            fun str(name: String, fallback: String, max: Int = 256): String =
                json.optString(name, fallback).ifBlank { fallback }.trim().take(max)

            val engine = str("engine", "rvc-onnx-v2")
            val sourceFormat = runCatching {
                VoiceSourceFormat.valueOf(str("sourceFormat", if (format == "VSPVOICE") "VSPVOICE" else "ONNX_GENERIC"))
            }.getOrDefault(VoiceSourceFormat.UNKNOWN)
            val state = runCatching {
                VoiceModelState.valueOf(str("state", "READY"))
            }.getOrDefault(VoiceModelState.INCOMPLETE)

            val contentName = str("contentModel", "content_encoder.onnx")
            val pitchName = str("pitchModel", "pitch.onnx")
            val voiceName = str("voiceModel", "voice.onnx")
            val checkpointName = str("checkpoint", "model.pth")
            val indexName = str("index", "model.index")

            return VoiceModel(
                id = str("id", dir.name, 96),
                name = str("name", dir.name, 128),
                author = str("author", "Local model", 128),
                engine = engine,
                sampleRate = json.optInt("sampleRate", 40_000),
                contentSampleRate = json.optInt("contentSampleRate", 16_000),
                featureChannels = json.optInt(
                    "featureChannels",
                    if (engine.endsWith("v1")) 256 else 768
                ),
                contentInput = str("contentInput", "audio"),
                contentOutput = str("contentOutput", "features"),
                contentInputRank = json.optInt("contentInputRank", 2),
                contentOutputLayout = str("contentOutputLayout", "BTC").uppercase(),
                featureUpsample = json.optInt("featureUpsample", 2).coerceIn(1, 4),
                pitchInput = str("pitchInput", "audio"),
                pitchOutput = str("pitchOutput", "f0"),
                pitchInputRank = json.optInt("pitchInputRank", 2),
                voicePhoneInput = str("voicePhoneInput", "phone"),
                voicePhoneLengthsInput = str("voicePhoneLengthsInput", "phone_lengths"),
                voicePitchInput = str("voicePitchInput", "pitch"),
                voicePitchFInput = str("voicePitchFInput", "pitchf"),
                voiceSpeakerInput = str("voiceSpeakerInput", "ds"),
                voiceNoiseInput = str("voiceNoiseInput", "rnd"),
                voiceOutput = str("voiceOutput", "audio"),
                speakerId = json.optLong("speakerId", 0L),
                authorized = json.optBoolean("authorized", false),
                licenseLabel = str("license", "User supplied / authorized", 256),
                sourceFormat = sourceFormat,
                state = state,
                statusDetail = str("statusDetail", ""),
                contentModelName = contentName,
                pitchModelName = pitchName,
                voiceModelName = voiceName,
                checkpointName = checkpointName,
                indexName = indexName,
                directory = dir
            ).also { it.validateInstalled() }
        }
    }
}

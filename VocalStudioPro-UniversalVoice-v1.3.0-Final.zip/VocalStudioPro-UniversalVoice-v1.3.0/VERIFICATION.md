# Vocal Studio Pro 1.3.0 — Verification

Verification performed before packaging the final source archive.

## Native C++ / JNI

All files under `app/src/main/cpp/*.cpp`, including `native_bridge.cpp`, were compiled on the host with:

```text
-std=c++17 -O2 -Wall -Wextra -Werror -fPIC
```

Result: **PASS**.

The new native F0 path was tested on a synthetic 220 Hz sine at 8 kHz after the same decimation regime used by the JNI tracker:

```text
estimated F0 = 220.047 Hz
confidence   = 0.998
```

## DSP split pipeline

A two-second synthetic vocal-like WAV was processed through:

```text
prepareForVoiceModel → masterOnly
```

Result:

```text
VocalDSP 1.3.0 · Universal Model Import + Voice Conversion + Studio Clean
48,000 Hz
96,000 samples
mono PCM 24-bit WAV
```

Duration and sample count were preserved.

## Kotlin compile checks

The following production Kotlin layers were compiled with host-side Android/ONNX API stubs to detect Kotlin syntax, type, nullable, and method-signature errors:

- `VoiceModel.kt`
- `OnnxModelProbe.kt`
- `VoiceModelManager.kt`
- `VoiceConversionEngine.kt`
- `VoiceWavIO.kt`
- `VoiceConversionParams.kt`
- `NativeDsp.kt`
- `StudioViewModel.kt`
- `StudioScreen.kt`

Result: **PASS**.

The stubs mirror the ONNX Runtime APIs used by the project (`OrtSession.inputNames`, `outputNames`, `inputInfo`, `outputInfo`, SessionOptions, TensorInfo, tensor creation and result access). The previous v1.2 runtime path already used the same inference API family; v1.3 adds model probing and optional native F0.

## Voice pack tool

`tools/create_voice_pack.py` was checked with `python -m py_compile`, then executed against dummy Content/Voice/Pitch/Index/Checkpoint files. The generated VSPVOICE v2 ZIP passed `unzip -t` and its metadata parsed as valid JSON.

Result: **PASS**.

## Workflow / resources

- `BUILD_FROM_ZIP.yml`: YAML parse PASS
- `.github/workflows/build.yml`: YAML parse PASS
- Android resource XML files: XML parse PASS
- source ZIP: tested with `unzip -t`

## Dependency/toolchain selections

```text
compileSdk / targetSdk: 37
AGP: 9.4.0
Gradle: 9.6.0
Build Tools: 36.0.0
JDK: 17
NDK: 28.2.13676358
CMake: 3.22.1
Compose BOM: 2026.08.00
Lifecycle: 2.11.0
ONNX Runtime Android: 1.29.0
```

## Build limitation of this verification environment

A complete Android `assembleDebug/assembleRelease` was not executed locally because this container does not have the Android SDK or cached Google/Maven dependencies. The included GitHub Actions workflow performs that complete Android build with the declared toolchain.

## Important format boundary

The universal importer accepts and stores RVC `.pth + .index` bundles, including large ZIPs. A standard RVC `.pth` checkpoint is not directly executed because it is not an ONNX graph. It is marked `CONVERSION_REQUIRED`. Ready ONNX/VSPVOICE models are executed locally by ONNX Runtime.

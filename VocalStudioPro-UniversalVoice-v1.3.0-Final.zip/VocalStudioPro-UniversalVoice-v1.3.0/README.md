# Vocal Studio Pro v1.3.0 — Universal Voice Model Import

Native Android vocal processing and voice-conversion studio written in Kotlin/Jetpack Compose with a C++17 NDK DSP engine and ONNX Runtime.

## Core pipeline

`Record / import audio → spectral clean → key-aware Auto-Tune → optional voice conversion → studio master → 48 kHz / 24-bit WAV`

## Universal model importer

The app has one **Import any model** picker. It securely opens a standalone file or ZIP and detects the contents automatically.

### Directly runnable

- `.vspvoice` packs (ZIP based)
- `.zip` containing an RVC-compatible `voice.onnx` + `content_encoder.onnx`
- optional direct-F0 `pitch.onnx`
- standalone RVC `voice.onnx` when a shared Content Encoder has already been imported
- ZIPs with one extra directory level are detected automatically

The importer probes ONNX input/output signatures. Official-style RVC synthesizer inputs such as `phone`, `phone_lengths`, `pitch`, `pitchf`, `ds`, and `rnd` are mapped automatically. If `pitch.onnx` is absent, the app falls back to the native C++ F0 detector.

### Accepted and catalogued

- RVC `.pth`
- RVC `.index`
- ZIP containing `.pth + .index`

The `.index` file is preserved with the imported model for compatibility/export, but the current Android inference path does not run FAISS retrieval from that index.

A regular RVC `.pth` checkpoint is a PyTorch checkpoint/state dictionary, not an executable ONNX graph. Android ONNX Runtime cannot execute it directly. v1.3.0 therefore imports and preserves the files, identifies the model as **RVC PTH**, and marks it **Needs ONNX conversion** instead of failing or pretending to run it.

This limitation is architectural, not a file-picker limitation: arbitrary RVC/SVC architectures cannot all be executed by one runtime merely because they share the `.pth` extension.

## Shared Core mode

A ZIP containing a ContentVec/HuBERT-style ONNX encoder without a voice synthesizer is installed as a shared Core. Any previously imported standalone `voice.onnx` models waiting for a Content Encoder are completed automatically.

A raw RMVPE salience ONNX (360-bin output) is not mistaken for a direct-F0 model. Direct-F0 ONNX is used when compatible; otherwise Native F0 is selected automatically.

## Voice controls

- Voice Mix
- Pitch compensation ±24 semitones
- Consonant/breath protection
- Fast / Balanced / Ultra inference
- NNAPI → XNNPACK → CPU fallback
- chunked inference with overlap/crossfade for long recordings

## Studio DSP

- adaptive spectral denoise
- hum/DC cleanup
- key/scale Auto-Tune
- vocal leveling
- multiband dynamics
- split-band de-esser
- clarity/warmth/air EQ
- subtle saturation
- studio plate
- final true-peak-oriented limiter

## Android toolchain

- `compileSdk = 37`
- `targetSdk = 37`
- `minSdk = 26`
- AGP `9.4.0`
- Gradle `9.6.0`
- Kotlin Compose plugin `2.3.21`
- Lifecycle `2.11.0`
- ONNX Runtime Android `1.29.0`
- NDK `28.2.13676358`
- CMake `3.22.1`
- Java 17

## Build from a ZIP in GitHub

The repository can contain only:

```text
VocalStudioPro-UniversalVoice-v1.3.0-Final.zip
.github/workflows/build.yml
```

Use `BUILD_FROM_ZIP.yml` as `.github/workflows/build.yml`. The workflow extracts the project, verifies the expected versions, installs Android API 37.0 / NDK / CMake, builds Debug + Release, and uploads the APKs.

## Rights confirmation

Before model import the UI requires the user to confirm that they have the right to use the voice model. The project contains no third-party person's voice weights.

## Model pack utility

`tools/create_voice_pack.py` packages already-compatible ONNX files into VSPVOICE v2. `--pitch` is optional because v1.3.0 has Native F0 fallback.

Example:

```bash
python tools/create_voice_pack.py \
  --content content_encoder.onnx \
  --voice voice.onnx \
  --name "My Voice" \
  --id my-voice \
  --author "Owner" \
  --confirm-authorized \
  --output MyVoice.vspvoice
```

#include "VoiceProfileEngine.h"

#include <iostream>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "usage: voice_profile_dataset_test <output.vsptrain> <input.wav> [input.wav ...]\n";
        return 2;
    }

    const std::string output = argv[1];
    std::vector<std::string> inputs;
    for (int index = 2; index < argc; ++index) inputs.emplace_back(argv[index]);

    std::string error;
    const int trained = VoiceProfileEngine::trainMany(inputs, output, error);
    if (trained != 0) {
        std::cerr << "TRAIN_FAIL code=" << trained << " error=" << error << '\n';
        return 3;
    }

    const int validated = VoiceProfileEngine::validate(output, error);
    if (validated != 0) {
        std::cerr << "VALIDATE_FAIL code=" << validated << " error=" << error << '\n';
        return 4;
    }

    VoiceProfileMetrics metrics{};
    const int inspected = VoiceProfileEngine::inspect(output, metrics, error);
    if (inspected != 0) {
        std::cerr << "INSPECT_FAIL code=" << inspected << " error=" << error << '\n';
        return 5;
    }

    std::cout << "PASS version=" << metrics.version
              << " source=" << metrics.sourceSeconds
              << " clean=" << metrics.cleanSeconds
              << " quality=" << metrics.qualityScore
              << " clips=" << inputs.size() << '\n';
    return 0;
}

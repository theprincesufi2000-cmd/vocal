# Changelog

## 1.6.1 — Dataset Training and Real-World Profile Validation

- Fixed valid VSPTRAIN3 profiles being rejected when real recordings produced normalized boundary-band values below `-8`.
- Replaced the narrow check with complete bounded validation of headers, metrics, envelopes, clusters, prototypes, PCA data and counts.
- Added direct VSPDATASET1 import, per-clip SHA-256 verification and automatic local VSPTRAIN3 training.
- Added archive structure, duration, WAV format, sample-rate, channel-count and extracted-size validation.
- Added real-dataset C++ regression testing through `tools/voice_profile_dataset_test.cpp`.
- Raised only the Dataset-capable import limit while retaining strict limits for trained model payloads.
- Clarified the Android UI so Dataset packages are not presented as already-trained models.
- Version bumped to `1.6.1` / `versionCode 13`.

## 1.6.0 — Pro Training Suite

- Added native multi-recording training for up to 64 clips / 50 minutes.
- Added independent noise-floor and voice-activity gating for every source recording.
- Fixed clean-duration accounting across datasets with different sample rates.
- Added JNI profile inspection and measured quality reporting in the UI.
- Added native progress reporting and safe cancellation for long training sessions.
- Added training presets and a multi-document Android picker.
- Added `.vspmodel` VSPMODEL2 import/export with metadata and SHA-256 verification.
- Added `.vspdataset` export for lossless hand-off to GPU RVC training.
- Added self-contained `.vspvoice` export with shared ContentVec/RMVPE core embedding.
- Added per-payload SHA-256 verification for portable VSPVOICE imports.
- Added `tools/vsp_package_tool.py` and a native multi-clip smoke test.
- Version bumped to `1.6.0` / `versionCode 12`.

## 1.5.0 — Pro Training 50m

- Replaced the simple 64-band VSPTRAIN1 trainer with backward-compatible **VSPTRAIN3**.
- Added streaming training for source recordings up to **50 minutes** without loading the full file into RAM.
- Added 96-band normalized vocal-envelope learning.
- Added voiced/unvoiced separation and four pitch-register models.
- Added 30 adaptive target-envelope prototypes using online clustering.
- Added input noise-floor, clipping and clean-voice analysis.
- Added pronunciation protection for consonant/unvoiced frames during application.
- Added bounded temporal/frequency smoothing and dry articulation preservation.
- VSPTRAIN1 files remain importable/applicable.
- Updated UI copy and long-training status messages.
- Version bumped to `1.5.0` / `versionCode 11`.

## 1.4.0 — Saved Voice Training

- Added reusable local `.vsptrain` profiles and import/export.

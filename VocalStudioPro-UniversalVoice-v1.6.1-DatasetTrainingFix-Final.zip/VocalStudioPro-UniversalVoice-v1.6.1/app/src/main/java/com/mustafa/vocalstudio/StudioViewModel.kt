package com.mustafa.vocalstudio

import android.app.Application
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.mustafa.vocalstudio.audio.AudioDecoder
import com.mustafa.vocalstudio.audio.AudioRecorder
import com.mustafa.vocalstudio.audio.WavPlayer
import com.mustafa.vocalstudio.dsp.NativeDsp
import com.mustafa.vocalstudio.dsp.ProcessingParams
import com.mustafa.vocalstudio.util.WavUtils
import com.mustafa.vocalstudio.voice.VoiceConversionEngine
import com.mustafa.vocalstudio.voice.VoiceConversionParams
import com.mustafa.vocalstudio.voice.VoiceModel
import com.mustafa.vocalstudio.voice.VoiceModelManager
import com.mustafa.vocalstudio.voice.VoiceModelState
import com.mustafa.vocalstudio.voice.TrainedVoiceProfile
import com.mustafa.vocalstudio.voice.TrainingAudioItem
import com.mustafa.vocalstudio.voice.TrainingPreset
import com.mustafa.vocalstudio.voice.VoiceProfileManager
import com.mustafa.vocalstudio.voice.VoiceQuality
import java.io.File
import java.util.concurrent.Executors


data class StudioUiState(
    val sourceFile: File? = null,
    val sourceName: String = "لا يوجد تسجيل",
    val processedFile: File? = null,
    val sourceWaveform: List<Float> = emptyList(),
    val processedWaveform: List<Float> = emptyList(),
    val params: ProcessingParams = ProcessingParams(),
    val voiceParams: VoiceConversionParams = VoiceConversionParams(),
    val voiceModels: List<VoiceModel> = emptyList(),
    val selectedVoiceId: String? = null,
    val trainedProfiles: List<TrainedVoiceProfile> = emptyList(),
    val selectedTrainedProfileId: String? = null,
    val trainedProfileEnabled: Boolean = false,
    val trainedProfileStrength: Float = 0.78f,
    val trainingName: String = "نموذج صوتي محلي",
    val trainingFiles: List<TrainingAudioItem> = emptyList(),
    val trainingPreset: TrainingPreset = TrainingPreset.STUDIO,
    val trainingProgress: Float = 0f,
    val voiceProgress: Float = 0f,
    val coreProgress: Float = 0f,
    val modelRightsConfirmed: Boolean = false,
    val isRecording: Boolean = false,
    val isTraining: Boolean = false,
    val isBusy: Boolean = false,
    val isPlayingSource: Boolean = false,
    val isPlayingProcessed: Boolean = false,
    val status: String = "جاهز",
    val engineVersion: String = "Native DSP"
) {
    val selectedVoice: VoiceModel?
        get() = voiceModels.firstOrNull { it.id == selectedVoiceId }
    val selectedTrainedProfile: TrainedVoiceProfile?
        get() = trainedProfiles.firstOrNull { it.id == selectedTrainedProfileId }
    val trainingDurationSeconds: Float
        get() = trainingFiles.sumOf { it.durationSeconds.toDouble() }.toFloat()
}

class StudioViewModel(app: Application) : AndroidViewModel(app) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val recorder = AudioRecorder(app)
    private val player = WavPlayer()
    private val voiceManager = VoiceModelManager(app)
    private val voiceEngine = VoiceConversionEngine()
    private val profileManager = VoiceProfileManager(app)
    private var recordingFile: File? = null
    private var trainingPollGeneration = 0L

    var uiState by mutableStateOf(
        StudioUiState(
            engineVersion = runCatching { NativeDsp.engineVersion() }.getOrDefault("Native DSP"),
            voiceModels = voiceManager.listModels(),
            trainedProfiles = profileManager.listProfiles()
        )
    )
        private set

    fun setRoot(root: Int) = updateParams { copy(rootPitchClass = root.coerceIn(0, 11)) }
    fun setScaleMode(mode: Int) = updateParams { copy(scaleMode = mode.coerceIn(0, 1)) }
    fun setStrength(value: Float) = updateParams { copy(strength = value.coerceIn(0f, 1f)) }
    fun setRetune(value: Float) = updateParams { copy(retuneMs = value.coerceIn(2f, 140f)) }
    fun setHumanize(value: Float) = updateParams { copy(humanize = value.coerceIn(0f, 1f)) }
    fun setNoise(value: Float) = updateParams { copy(noiseReduction = value.coerceIn(0f, 1f)) }
    fun setClarity(value: Float) = updateParams { copy(clarity = value.coerceIn(0f, 1f)) }
    fun setWarmth(value: Float) = updateParams { copy(warmth = value.coerceIn(0f, 1f)) }
    fun setAir(value: Float) = updateParams { copy(air = value.coerceIn(0f, 1f)) }
    fun setDeEsser(value: Float) = updateParams { copy(deEsser = value.coerceIn(0f, 1f)) }
    fun setCompression(value: Float) = updateParams { copy(compression = value.coerceIn(0f, 1f)) }
    fun setLeveling(value: Float) = updateParams { copy(leveling = value.coerceIn(0f, 1f)) }
    fun setReverb(value: Float) = updateParams { copy(reverb = value.coerceIn(0f, 0.45f)) }

    fun setVoiceEnabled(enabled: Boolean) = updateVoiceParams {
        copy(enabled = enabled && uiState.selectedVoice?.isReady == true)
    }

    fun setModelRightsConfirmed(value: Boolean) {
        uiState = uiState.copy(modelRightsConfirmed = value)
    }
    fun setVoiceMix(value: Float) = updateVoiceParams { copy(mix = value.coerceIn(0f, 1f)) }
    fun setVoiceTranspose(value: Float) = updateVoiceParams { copy(transposeSemitones = value.coerceIn(-24f, 24f)) }
    fun setConsonantProtect(value: Float) = updateVoiceParams { copy(consonantProtect = value.coerceIn(0f, 1f)) }
    fun setVoiceQuality(value: VoiceQuality) = updateVoiceParams { copy(quality = value) }
    fun setPreferNnapi(value: Boolean) = updateVoiceParams { copy(preferNnapi = value) }

    fun setTrainingName(value: String) {
        uiState = uiState.copy(trainingName = value.take(80))
    }

    fun setTrainingPreset(value: TrainingPreset) {
        uiState = uiState.copy(trainingPreset = value, status = "وضع التدريب: ${value.title}")
    }

    fun setTrainedProfileEnabled(value: Boolean) {
        uiState = uiState.copy(
            trainedProfileEnabled = value && uiState.selectedTrainedProfile != null,
            status = if (value && uiState.selectedTrainedProfile != null) "تم تفعيل النموذج المحلي المدرب" else "تم إيقاف النموذج المحلي"
        )
    }

    fun setTrainedProfileStrength(value: Float) {
        uiState = uiState.copy(trainedProfileStrength = value.coerceIn(0f, 1f))
    }

    fun selectTrainedProfile(id: String?) {
        val profile = id?.let { target -> uiState.trainedProfiles.firstOrNull { it.id == target } }
        uiState = uiState.copy(
            selectedTrainedProfileId = profile?.id,
            trainedProfileEnabled = profile != null && uiState.trainedProfileEnabled,
            status = if (profile != null) "تم اختيار النموذج المحلي: ${profile.name}" else "تم إلغاء اختيار النموذج المحلي"
        )
    }

    fun trainProfileFromCurrentSource() {
        if (!uiState.modelRightsConfirmed) {
            uiState = uiState.copy(status = "أكد أن لديك حق استخدام صوت التدريب أولًا")
            return
        }
        val selectedDataset = uiState.trainingFiles.map { it.file }.filter { it.isFile }
        val inputs = selectedDataset.ifEmpty { listOfNotNull(uiState.sourceFile) }
        if (inputs.isEmpty()) {
            uiState = uiState.copy(status = "اختر مجموعة تدريب أو سجّل مقطعًا أولًا")
            return
        }
        if (uiState.isBusy || uiState.isRecording) return
        val preset = uiState.trainingPreset
        val totalSeconds = if (selectedDataset.isNotEmpty()) uiState.trainingDurationSeconds else {
            runCatching {
                val info = WavUtils.readInfo(inputs.first())
                val frameBytes = (info.bitsPerSample / 8).coerceAtLeast(1) * info.channels.coerceAtLeast(1)
                (info.dataSize.toDouble() / frameBytes / info.sampleRate.coerceAtLeast(1)).toFloat()
            }.getOrDefault(0f)
        }
        uiState = uiState.copy(
            isBusy = true,
            isTraining = true,
            trainingProgress = 0.08f,
            status = "فحص ${inputs.size} مقطع · ${(totalSeconds / 60f).coerceAtLeast(0f).let { String.format("%.1f", it) }} دقيقة…"
        )
        startTrainingProgressPolling()
        executor.execute {
            val wakeLock = runCatching {
                getApplication<Application>().getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VocalStudioPro:ProVoiceTraining")
                    .apply { setReferenceCounted(false); acquire(2L * 60L * 60L * 1000L) }
            }.getOrNull()
            try {
                main.post {
                    uiState = uiState.copy(
                        trainingProgress = 0.22f,
                        status = "تحليل الضوضاء والقصّ لكل مقطع بصورة مستقلة…"
                    )
                }
                val trained = profileManager.trainFromWavs(inputs, uiState.trainingName, preset)
                val profiles = profileManager.listProfiles()
                main.post {
                    uiState = uiState.copy(
                        trainedProfiles = profiles,
                        selectedTrainedProfileId = trained.id,
                        trainedProfileEnabled = true,
                        trainingProgress = 1f,
                        isTraining = false,
                        isBusy = false,
                        status = "اكتمل ${trained.name} · جودة ${trained.qualityScore.toInt()}% (${trained.qualityLabel}) · ${trained.sourceCount} مقطع"
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    val cancelled = t.message?.contains("code=90") == true
                    uiState = uiState.copy(
                        isBusy = false,
                        isTraining = false,
                        trainingProgress = 0f,
                        status = if (cancelled) "تم إلغاء التدريب بأمان" else "فشل تدريب النموذج: ${t.message}"
                    )
                }
            } finally {
                if (wakeLock?.isHeld == true) runCatching { wakeLock.release() }
            }
        }
    }

    fun cancelTraining() {
        if (!uiState.isTraining) return
        runCatching { NativeDsp.cancelVoiceProfileTraining() }
        uiState = uiState.copy(status = "جاري إيقاف التدريب وحفظ سلامة الملفات…")
    }

    fun removeSelectedTrainedProfile() {
        val profile = uiState.selectedTrainedProfile ?: return
        if (uiState.isBusy) return
        runCatching { profileManager.remove(profile) }
        uiState = uiState.copy(
            trainedProfiles = profileManager.listProfiles(),
            selectedTrainedProfileId = null,
            trainedProfileEnabled = false,
            status = "تم حذف النموذج المحلي المدرب"
        )
    }

    fun importTrainedProfile(uri: Uri) {
        if (uiState.isBusy || uiState.isRecording) return
        if (!uiState.modelRightsConfirmed) {
            uiState = uiState.copy(status = "أكد أن لديك حق استخدام الصوت أو النموذج أولًا")
            return
        }
        uiState = uiState.copy(
            isBusy = true,
            trainingProgress = 0f,
            status = "جاري اكتشاف VSPMODEL / VSPTRAIN / VSPDATASET والتحقق منه…"
        )
        executor.execute {
            try {
                val result = profileManager.importProfile(uri) { dataset ->
                    main.post {
                        uiState = uiState.copy(
                            isTraining = true,
                            trainingProgress = 0.01f,
                            trainingName = dataset.name,
                            status = "تم التحقق من Dataset · تدريب ${dataset.clipCount} مقطع (${String.format("%.1f", dataset.totalSeconds / 60f)} دقيقة) إلى VSPTRAIN3…"
                        )
                        startTrainingProgressPolling()
                    }
                }
                val profile = result.profile
                val profiles = profileManager.listProfiles()
                main.post {
                    uiState = uiState.copy(
                        trainedProfiles = profiles,
                        selectedTrainedProfileId = profile.id,
                        trainedProfileEnabled = true,
                        isBusy = false,
                        isTraining = false,
                        trainingProgress = if (result.trainedFromDataset) 1f else 0f,
                        status = if (result.trainedFromDataset) {
                            "تم تحويل VSPDATASET إلى ${profile.format} فعلي · جودة ${profile.qualityScore.toInt()}% (${profile.qualityLabel})"
                        } else {
                            "تم استيراد ${result.sourceFormat} والتحقق من سلامة النموذج"
                        }
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    val cancelled = t.message?.contains("code=90") == true
                    uiState = uiState.copy(
                        isBusy = false,
                        isTraining = false,
                        trainingProgress = 0f,
                        status = if (cancelled) "تم إلغاء تدريب Dataset بأمان" else "فشل استيراد/تدريب الملف: ${t.message}"
                    )
                }
            }
        }
    }

    fun exportSelectedTrainedProfile(uri: Uri) {
        val profile = uiState.selectedTrainedProfile ?: return
        if (uiState.isBusy) return
        uiState = uiState.copy(isBusy = true, status = "جاري حفظ النموذج المدرب…")
        executor.execute {
            try {
                profileManager.exportProfile(profile, uri)
                main.post { uiState = uiState.copy(isBusy = false, status = "تم حفظ حزمة VSPMODEL المتحققة بنجاح") }
            } catch (t: Throwable) {
                main.post { uiState = uiState.copy(isBusy = false, status = "فشل حفظ النموذج: ${t.message}") }
            }
        }
    }

    fun suggestedTrainedProfileName(): String {
        val base = uiState.selectedTrainedProfile?.name ?: uiState.trainingName.ifBlank { "trained_voice" }
        val safe = base.replace(Regex("[^\\p{L}\\p{N}._-]+"), "_").take(48)
        return "${safe.ifBlank { "trained_voice" }}.vspmodel"
    }

    fun exportTrainingDataset(uri: Uri) {
        val items = uiState.trainingFiles
        if (items.isEmpty() || uiState.isBusy) return
        uiState = uiState.copy(isBusy = true, trainingProgress = 0.05f, status = "جاري إنشاء حزمة VSPDATASET للتدريب العصبي…")
        executor.execute {
            try {
                profileManager.exportTrainingDataset(items, uiState.trainingName, uri)
                main.post {
                    uiState = uiState.copy(
                        isBusy = false,
                        trainingProgress = 0f,
                        status = "تم تصدير مجموعة التدريب كاملة مع SHA-256 · جاهزة لمسار RVC GPU"
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(isBusy = false, trainingProgress = 0f, status = "فشل تصدير مجموعة التدريب: ${t.message}")
                }
            }
        }
    }

    fun suggestedTrainingDatasetName(): String {
        val safe = uiState.trainingName.replace(Regex("[^\\p{L}\\p{N}._-]+"), "_").take(48)
        return "${safe.ifBlank { "voice_dataset" }}.vspdataset"
    }

    fun exportSelectedVoiceModel(uri: Uri) {
        val model = uiState.selectedVoice ?: return
        if (uiState.isBusy) return
        uiState = uiState.copy(isBusy = true, status = "جاري إنشاء حزمة VSPVOICE كاملة والتحقق منها…")
        executor.execute {
            try {
                voiceManager.exportPortable(model, uri)
                main.post { uiState = uiState.copy(isBusy = false, status = "تم تصدير ${model.name} كحزمة VSPVOICE محمولة") }
            } catch (t: Throwable) {
                main.post { uiState = uiState.copy(isBusy = false, status = "فشل تصدير النموذج: ${t.message}") }
            }
        }
    }

    fun suggestedVoiceModelName(): String {
        val base = uiState.selectedVoice?.name ?: "voice_model"
        val safe = base.replace(Regex("[^\\p{L}\\p{N}._-]+"), "_").take(48)
        return "${safe.ifBlank { "voice_model" }}.vspvoice"
    }

    fun selectVoiceModel(id: String?) {
        val model = id?.let { target -> uiState.voiceModels.firstOrNull { it.id == target } }
        uiState = uiState.copy(
            selectedVoiceId = model?.id,
            voiceParams = uiState.voiceParams.copy(enabled = model?.isReady == true && uiState.voiceParams.enabled),
            status = when {
                model == null -> "تم إلغاء اختيار النموذج"
                model.isReady -> "تم اختيار ${model.name} · جاهز"
                else -> "${model.name} · ${model.stateLabel()}: ${model.statusDetail}"
            }
        )
    }

    fun importVoiceModel(uri: Uri) {
        if (uiState.isBusy || uiState.isRecording) return
        if (!uiState.modelRightsConfirmed) {
            uiState = uiState.copy(status = "أكد حق استخدام النموذج قبل الاستيراد")
            return
        }
        uiState = uiState.copy(isBusy = true, status = "جاري اكتشاف نوع النموذج وفك الحزمة…")
        executor.execute {
            try {
                val result = voiceManager.importAny(uri, uiState.modelRightsConfirmed)
                val models = voiceManager.listModels()
                main.post {
                    val model = result.model
                    uiState = uiState.copy(
                        voiceModels = models,
                        selectedVoiceId = model?.id ?: uiState.selectedVoiceId,
                        voiceParams = uiState.voiceParams.copy(enabled = model?.isReady == true),
                        isBusy = false,
                        status = result.message
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(isBusy = false, status = "فشل استيراد النموذج: ${t.message}")
                }
            }
        }
    }

    fun downloadRvcV2Core() {
        val selected = uiState.selectedVoice ?: return
        if (uiState.isBusy || uiState.isRecording) return
        if (selected.state != VoiceModelState.MISSING_CORE || selected.featureChannels != 768) {
            uiState = uiState.copy(status = "هذا النموذج لا يحتاج RVC v2 Core أو يحتاج Core مختلف")
            return
        }
        uiState = uiState.copy(isBusy = true, coreProgress = 0f, status = "جاري تنزيل RVC v2 Core…")
        executor.execute {
            try {
                val message = voiceManager.downloadSharedRvcV2Core { progress ->
                    main.post {
                        if (uiState.isBusy) uiState = uiState.copy(
                            coreProgress = progress.coerceIn(0f, 1f),
                            status = "تنزيل RVC Core ${(progress * 100).toInt().coerceIn(0, 100)}%"
                        )
                    }
                }
                val models = voiceManager.listModels()
                main.post {
                    val selectedId = uiState.selectedVoiceId
                    val refreshed = models.firstOrNull { it.id == selectedId }
                    uiState = uiState.copy(
                        voiceModels = models,
                        selectedVoiceId = refreshed?.id ?: selectedId,
                        voiceParams = uiState.voiceParams.copy(enabled = refreshed?.isReady == true),
                        coreProgress = 1f,
                        isBusy = false,
                        status = message
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(
                        isBusy = false,
                        coreProgress = 0f,
                        status = "فشل تنزيل RVC Core: ${t.message}"
                    )
                }
            }
        }
    }

    fun removeSelectedVoiceModel() {
        val model = uiState.selectedVoice ?: return
        if (uiState.isBusy) return
        runCatching { voiceManager.remove(model) }
        uiState = uiState.copy(
            voiceModels = voiceManager.listModels(),
            selectedVoiceId = null,
            voiceParams = uiState.voiceParams.copy(enabled = false),
            status = "تم حذف النموذج الصوتي"
        )
    }

    fun applyPreset(name: String) {
        val current = uiState.params
        val p = when (name) {
            "Natural" -> current.copy(
                strength = 0.78f, retuneMs = 72f, humanize = 0.72f,
                noiseReduction = 0.48f, clarity = 0.46f, warmth = 0.42f, air = 0.38f,
                deEsser = 0.38f, compression = 0.46f, leveling = 0.52f, reverb = 0.11f
            )
            "Hard" -> current.copy(
                strength = 1.0f, retuneMs = 5f, humanize = 0f,
                noiseReduction = 0.66f, clarity = 0.72f, warmth = 0.26f, air = 0.58f,
                deEsser = 0.62f, compression = 0.78f, leveling = 0.80f, reverb = 0.16f
            )
            "Studio" -> current.copy(
                strength = 0.92f, retuneMs = 24f, humanize = 0.34f,
                noiseReduction = 0.72f, clarity = 0.78f, warmth = 0.38f, air = 0.62f,
                deEsser = 0.60f, compression = 0.72f, leveling = 0.82f, reverb = 0.12f
            )
            else -> current.copy(
                strength = 0.95f, retuneMs = 20f, humanize = 0.25f,
                noiseReduction = 0.62f, clarity = 0.66f, warmth = 0.34f, air = 0.52f,
                deEsser = 0.52f, compression = 0.68f, leveling = 0.72f, reverb = 0.14f
            )
        }
        uiState = uiState.copy(params = p, status = "تم تطبيق إعداد $name")
    }

    fun startRecording() {
        if (uiState.isBusy || uiState.isRecording) return
        val dir = getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            ?: getApplication<Application>().filesDir
        val file = File(dir, "raw_vocal_${System.currentTimeMillis()}.wav")
        runCatching {
            player.stop()
            recordingFile = file
            recorder.start(file)
            uiState = uiState.copy(
                isRecording = true,
                status = "جاري التسجيل الخام 48 kHz…",
                processedFile = null,
                processedWaveform = emptyList()
            )
        }.onFailure {
            recordingFile = null
            uiState = uiState.copy(status = "فشل بدء التسجيل: ${it.message}")
        }
    }

    fun stopRecording() {
        if (!uiState.isRecording) return
        val file = recordingFile
        recorder.stop()
        recordingFile = null
        if (file != null && file.exists() && file.length() > 44) setSource(file, "تسجيل جديد")
        else uiState = uiState.copy(isRecording = false, status = "لم يتم إنشاء تسجيل صالح")
    }

    fun importTrainingAudios(uris: List<Uri>) {
        if (uiState.isBusy || uiState.isRecording) return
        val selected = uris.distinct().take(64)
        if (selected.isEmpty()) {
            uiState = uiState.copy(status = "لم يتم اختيار مقاطع للتدريب")
            return
        }
        val app = getApplication<Application>()
        val sessionDir = File(app.cacheDir, "training-dataset/${System.currentTimeMillis()}").apply { mkdirs() }
        val oldParents = uiState.trainingFiles.mapNotNull { it.file.parentFile }.distinct()
        uiState = uiState.copy(isBusy = true, trainingProgress = 0f, status = "تجهيز مجموعة التدريب…")
        executor.execute {
            try {
                val items = ArrayList<TrainingAudioItem>(selected.size)
                var totalSeconds = 0f
                selected.forEachIndexed { index, uri ->
                    val output = File(sessionDir, "clip-${index.toString().padStart(3, '0')}.wav")
                    AudioDecoder.toWav(app, uri, output)
                    val info = WavUtils.readInfo(output)
                    val frameBytes = (info.bitsPerSample / 8).coerceAtLeast(1) * info.channels.coerceAtLeast(1)
                    val duration = (info.dataSize.toDouble() / frameBytes / info.sampleRate.coerceAtLeast(1)).toFloat()
                    require(duration >= 1f) { "${queryName(uri) ?: "مقطع"}: أقصر من ثانية" }
                    totalSeconds += duration
                    require(totalSeconds <= 50f * 60f + 0.5f) { "إجمالي مجموعة التدريب يتجاوز 50 دقيقة" }
                    items += TrainingAudioItem(
                        id = "${System.nanoTime()}-$index",
                        displayName = queryName(uri) ?: "مقطع ${index + 1}",
                        file = output,
                        durationSeconds = duration,
                        sampleRate = info.sampleRate,
                        channels = info.channels
                    )
                    val progress = (index + 1f) / selected.size.toFloat()
                    main.post {
                        if (uiState.isBusy) uiState = uiState.copy(
                            trainingProgress = progress,
                            status = "تجهيز المقاطع ${index + 1}/${selected.size}"
                        )
                    }
                }
                main.post {
                    oldParents.forEach { if (it.name != sessionDir.name) runCatching { it.deleteRecursively() } }
                    uiState = uiState.copy(
                        trainingFiles = items,
                        trainingProgress = 0f,
                        isBusy = false,
                        status = "مجموعة التدريب جاهزة · ${items.size} مقطع · ${String.format("%.1f", totalSeconds / 60f)} دقيقة"
                    )
                }
            } catch (t: Throwable) {
                sessionDir.deleteRecursively()
                main.post {
                    uiState = uiState.copy(isBusy = false, trainingProgress = 0f, status = "فشل تجهيز مجموعة التدريب: ${t.message}")
                }
            }
        }
    }

    fun removeTrainingItem(id: String) {
        if (uiState.isBusy) return
        val item = uiState.trainingFiles.firstOrNull { it.id == id } ?: return
        runCatching { item.file.delete() }
        val remaining = uiState.trainingFiles.filterNot { it.id == id }
        uiState = uiState.copy(
            trainingFiles = remaining,
            status = if (remaining.isEmpty()) "تم تفريغ مجموعة التدريب" else "تم حذف المقطع · بقي ${remaining.size}"
        )
    }

    fun clearTrainingDataset() {
        if (uiState.isBusy) return
        uiState.trainingFiles.mapNotNull { it.file.parentFile }.distinct().forEach { runCatching { it.deleteRecursively() } }
        uiState = uiState.copy(trainingFiles = emptyList(), trainingProgress = 0f, status = "تم تفريغ مجموعة التدريب")
    }

    fun importAudio(uri: Uri) {
        if (uiState.isBusy || uiState.isRecording) return
        val app = getApplication<Application>()
        val displayName = queryName(uri) ?: "ملف صوت"
        uiState = uiState.copy(isBusy = true, status = "جاري فك الصوت وتحضيره…")
        executor.execute {
            try {
                val out = File(app.cacheDir, "import_${System.currentTimeMillis()}.wav")
                AudioDecoder.toWav(app, uri, out)
                val peaks = WavUtils.waveform(out)
                main.post {
                    player.stop()
                    uiState = uiState.copy(
                        sourceFile = out, sourceName = displayName, processedFile = null,
                        sourceWaveform = peaks, processedWaveform = emptyList(),
                        isBusy = false, status = "تم تجهيز الصوت للمعالجة"
                    )
                }
            } catch (t: Throwable) {
                main.post { uiState = uiState.copy(isBusy = false, status = "فشل استيراد الصوت: ${t.message}") }
            }
        }
    }

    fun process() {
        val input = uiState.sourceFile ?: run {
            uiState = uiState.copy(status = "سجّل أو اختر ملفًا صوتيًا أولًا")
            return
        }
        if (uiState.isBusy || uiState.isRecording) return
        val app = getApplication<Application>()
        val dir = app.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: app.filesDir
        val output = File(dir, "studio_master_${System.currentTimeMillis()}.wav")
        val p = uiState.params
        val vp = uiState.voiceParams
        val voice = uiState.selectedVoice
        val trainedProfile = uiState.selectedTrainedProfile
        val useTrainedProfile = uiState.trainedProfileEnabled && trainedProfile != null

        if (vp.enabled && voice == null) {
            uiState = uiState.copy(status = "اختر نموذجًا صوتيًا أولًا")
            return
        }
        if (vp.enabled && voice?.isReady != true) {
            uiState = uiState.copy(status = voice?.statusDetail ?: "النموذج غير جاهز للتشغيل")
            return
        }
        if (uiState.trainedProfileEnabled && trainedProfile == null) {
            uiState = uiState.copy(status = "اختر نموذج VSPTRAIN مدربًا أولًا")
            return
        }

        player.stop()
        val pipelineStatus = when {
            vp.enabled && useTrainedProfile -> "Clean + Auto‑Tune → RVC → Trained Profile → Studio Master…"
            vp.enabled -> "Clean + Auto‑Tune → Voice Model → Studio Master…"
            useTrainedProfile -> "Clean + Auto‑Tune → Trained Profile → Studio Master…"
            else -> "تنظيف طيفي → Auto‑Tune → Studio Master…"
        }
        uiState = uiState.copy(
            isBusy = true,
            voiceProgress = 0f,
            processedFile = null,
            processedWaveform = emptyList(),
            isPlayingSource = false,
            isPlayingProcessed = false,
            status = pipelineStatus
        )

        executor.execute {
            val pretuned = File(app.cacheDir, "pretuned_${System.nanoTime()}.wav")
            val converted = File(app.cacheDir, "converted_${System.nanoTime()}.wav")
            val profiled = File(app.cacheDir, "profiled_${System.nanoTime()}.wav")
            try {
                if (vp.enabled || useTrainedProfile) {
                    val prepCode = NativeDsp.prepareForVoiceModel(
                        input.absolutePath, pretuned.absolutePath,
                        p.rootPitchClass, p.scaleMode, p.strength, p.retuneMs, p.humanize, p.noiseReduction
                    )
                    if (prepCode != 0 || !pretuned.isFile || pretuned.length() <= 44) {
                        error("Native pre-processing error $prepCode")
                    }

                    var stageInput = pretuned
                    var voiceRate: Int? = null
                    var voiceProvider: String? = null

                    if (vp.enabled && voice != null) {
                        main.post { uiState = uiState.copy(status = "جاري تحويل الخامة الصوتية: ${voice.name}…") }
                        val stats = voiceEngine.convert(stageInput, converted, voice, vp) { progress ->
                            main.post {
                                if (uiState.isBusy) uiState = uiState.copy(
                                    voiceProgress = progress,
                                    status = "Voice Conversion ${(progress * 100).toInt().coerceIn(0, 100)}% · ${voice.name}"
                                )
                            }
                        }
                        if (!converted.isFile || converted.length() <= 44) error("Voice model produced no audio")
                        stageInput = converted
                        voiceRate = stats.sampleRate
                        voiceProvider = stats.provider
                        if (!voice.sampleRateKnown || voice.sampleRate != stats.sampleRate) {
                            voiceManager.updateDetectedSampleRate(voice, stats.sampleRate)
                        }
                    }

                    if (useTrainedProfile && trainedProfile != null) {
                        main.post { uiState = uiState.copy(status = "تطبيق النموذج المحلي المدرب: ${trainedProfile.name}…") }
                        val profileCode = NativeDsp.applyVoiceProfile(
                            stageInput.absolutePath,
                            profiled.absolutePath,
                            trainedProfile.file.absolutePath,
                            uiState.trainedProfileStrength
                        )
                        if (profileCode != 0 || !profiled.isFile || profiled.length() <= 44) {
                            error("Trained profile DSP error $profileCode")
                        }
                        stageInput = profiled
                    }

                    val masterCode = NativeDsp.masterOnly(
                        stageInput.absolutePath, output.absolutePath,
                        p.clarity, p.warmth, p.air, p.deEsser, p.compression, p.leveling, p.reverb
                    )
                    if (masterCode != 0 || !output.isFile || output.length() <= 44) error("Native master error $masterCode")

                    val models = voiceManager.listModels()
                    val peaks = WavUtils.waveform(output)
                    main.post {
                        val extra = when {
                            voiceRate != null -> {
                                val rate = if (voiceRate!! % 1000 == 0) "${voiceRate!! / 1000} kHz" else "${voiceRate} Hz"
                                " · Model $rate · ${voiceProvider ?: "ORT"}"
                            }
                            useTrainedProfile -> " · VSPTRAIN"
                            else -> ""
                        }
                        uiState = uiState.copy(
                            voiceModels = models,
                            selectedVoiceId = voice?.id ?: uiState.selectedVoiceId,
                            processedFile = output,
                            processedWaveform = peaks,
                            isBusy = false,
                            voiceProgress = if (vp.enabled) 1f else 0f,
                            status = "اكتملت المعالجة$extra → WAV 24-bit/48 kHz"
                        )
                    }
                } else {
                    val code = NativeDsp.processWav(
                        input.absolutePath, output.absolutePath,
                        p.rootPitchClass, p.scaleMode, p.strength, p.retuneMs, p.humanize,
                        p.noiseReduction, p.clarity, p.warmth, p.air, p.deEsser,
                        p.compression, p.leveling, p.reverb
                    )
                    if (code != 0 || !output.exists() || output.length() <= 44) error("Native DSP error $code")
                    val peaks = WavUtils.waveform(output)
                    main.post {
                        uiState = uiState.copy(
                            processedFile = output, processedWaveform = peaks,
                            isBusy = false, voiceProgress = 0f,
                            status = "اكتملت المعالجة — WAV 24-bit / 48 kHz"
                        )
                    }
                }
            } catch (t: Throwable) {
                output.delete()
                main.post {
                    uiState = uiState.copy(
                        processedFile = null,
                        processedWaveform = emptyList(),
                        isBusy = false,
                        voiceProgress = 0f,
                        isPlayingProcessed = false,
                        status = "فشلت المعالجة: ${t.message}"
                    )
                }
            } finally {
                pretuned.delete()
                converted.delete()
                profiled.delete()
            }
        }
    }

    fun playSource() {
        val file = uiState.sourceFile ?: return
        if (uiState.isPlayingSource) {
            player.stop(); uiState = uiState.copy(isPlayingSource = false); return
        }
        player.stop()
        uiState = uiState.copy(isPlayingSource = true, isPlayingProcessed = false)
        player.play(file) { main.post { uiState = uiState.copy(isPlayingSource = false) } }
    }

    fun playProcessed() {
        val file = uiState.processedFile ?: return
        if (uiState.isPlayingProcessed) {
            player.stop(); uiState = uiState.copy(isPlayingProcessed = false); return
        }
        player.stop()
        uiState = uiState.copy(isPlayingProcessed = true, isPlayingSource = false)
        player.play(file) { main.post { uiState = uiState.copy(isPlayingProcessed = false) } }
    }

    fun exportTo(uri: Uri) {
        val source = uiState.processedFile ?: return
        uiState = uiState.copy(isBusy = true, status = "جاري حفظ WAV…")
        executor.execute {
            try {
                getApplication<Application>().contentResolver.openOutputStream(uri, "w").use { out ->
                    requireNotNull(out) { "Cannot open export destination" }
                    source.inputStream().use { it.copyTo(out, 256 * 1024) }
                }
                main.post { uiState = uiState.copy(isBusy = false, status = "تم حفظ ملف WAV بنجاح") }
            } catch (t: Throwable) {
                main.post { uiState = uiState.copy(isBusy = false, status = "فشل الحفظ: ${t.message}") }
            }
        }
    }

    fun suggestedExportName(): String = "VocalStudio_${System.currentTimeMillis()}.wav"

    private fun setSource(file: File, name: String) {
        val peaks = runCatching { WavUtils.waveform(file) }.getOrDefault(emptyList())
        uiState = uiState.copy(
            sourceFile = file, sourceName = name, sourceWaveform = peaks,
            processedFile = null, processedWaveform = emptyList(),
            isRecording = false, status = "تم حفظ التسجيل الخام"
        )
    }

    private fun queryName(uri: Uri): String? {
        val resolver = getApplication<Application>().contentResolver
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    private inline fun updateParams(block: ProcessingParams.() -> ProcessingParams) {
        uiState = uiState.copy(params = uiState.params.block())
    }

    private inline fun updateVoiceParams(block: VoiceConversionParams.() -> VoiceConversionParams) {
        uiState = uiState.copy(voiceParams = uiState.voiceParams.block())
    }

    private fun startTrainingProgressPolling() {
        val generation = ++trainingPollGeneration
        val poll = object : Runnable {
            override fun run() {
                if (generation != trainingPollGeneration || !uiState.isTraining) return
                val nativeProgress = runCatching { NativeDsp.voiceProfileTrainingProgress() }.getOrDefault(0f)
                if (nativeProgress.isFinite()) {
                    uiState = uiState.copy(trainingProgress = nativeProgress.coerceIn(0f, 0.99f))
                }
                main.postDelayed(this, 350L)
            }
        }
        main.postDelayed(poll, 500L)
    }

    override fun onCleared() {
        trainingPollGeneration++
        if (uiState.isTraining) runCatching { NativeDsp.cancelVoiceProfileTraining() }
        runCatching { recorder.stop() }
        recordingFile = null
        player.stop()
        executor.shutdownNow()
        super.onCleared()
    }
}

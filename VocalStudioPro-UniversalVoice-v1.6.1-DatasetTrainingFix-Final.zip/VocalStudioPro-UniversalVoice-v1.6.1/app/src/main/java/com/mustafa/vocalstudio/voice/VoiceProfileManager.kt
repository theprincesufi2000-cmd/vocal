package com.mustafa.vocalstudio.voice

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.mustafa.vocalstudio.dsp.NativeDsp
import com.mustafa.vocalstudio.util.WavUtils
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.Properties
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class DatasetTrainingInfo(
    val name: String,
    val clipCount: Int,
    val totalSeconds: Float
)

data class ProfileImportResult(
    val profile: TrainedVoiceProfile,
    val sourceFormat: String,
    val trainedFromDataset: Boolean
)

/**
 * Owns local VSPTRAIN profiles and the portable VSPMODEL2 exchange container.
 *
 * A raw .vsptrain remains supported for backwards compatibility. New exports use a ZIP-based
 * .vspmodel with human metadata and a SHA-256 digest, so names and quality measurements survive
 * transfer between devices and corrupt/truncated profiles are rejected before installation.
 */
class VoiceProfileManager(private val context: Context) {
    private val dir = File(context.filesDir, "trained_voice_profiles").apply { mkdirs() }

    fun listProfiles(): List<TrainedVoiceProfile> = dir.listFiles { file ->
        file.isFile && file.extension.equals("vsptrain", true)
    }?.mapNotNull(::readProfile)?.sortedByDescending { it.createdAt } ?: emptyList()

    fun trainFromWav(input: File, requestedName: String): TrainedVoiceProfile =
        trainFromWavs(listOf(input), requestedName, TrainingPreset.STUDIO)

    fun trainFromWavs(
        inputs: List<File>,
        requestedName: String,
        preset: TrainingPreset
    ): TrainedVoiceProfile {
        require(inputs.isNotEmpty()) { "مجموعة التدريب فارغة" }
        require(inputs.size <= 64) { "الحد الأقصى 64 مقطعًا في جلسة التدريب" }

        var totalSeconds = 0f
        inputs.forEach { input ->
            require(input.isFile && input.length() > 44) { "أحد ملفات التدريب غير موجود أو فارغ" }
            val info = WavUtils.readInfo(input)
            require(info.audioFormat in setOf(1, 3)) { "صيغة WAV غير مدعومة في التدريب" }
            val bytesPerFrame = (info.bitsPerSample / 8).coerceAtLeast(1) * info.channels.coerceAtLeast(1)
            val seconds = (info.dataSize.toDouble() / bytesPerFrame / info.sampleRate.coerceAtLeast(1)).toFloat()
            require(seconds >= 1f) { "كل مقطع تدريب يجب أن يبلغ ثانية واحدة على الأقل" }
            totalSeconds += seconds
        }
        require(totalSeconds >= 5f) { "إجمالي التدريب قصير جدًا؛ الحد الأدنى التقني 5 ثوانٍ" }
        require(totalSeconds <= 50f * 60f + 0.5f) { "الحد الأقصى لجلسة التدريب هو 50 دقيقة" }
        require(totalSeconds >= preset.minimumRecommendedSeconds) {
            "وضع ${preset.title} يتطلب ${formatDuration(preset.minimumRecommendedSeconds)} على الأقل؛ اختر وضعًا أخف أو أضف تسجيلات"
        }

        val name = requestedName.trim().ifBlank { "نموذج صوتي ${System.currentTimeMillis()}" }.take(80)
        val id = newId()
        val target = File(dir, "$id.vsptrain")
        val code = NativeDsp.trainVoiceProfileSet(inputs.map { it.absolutePath }.toTypedArray(), target.absolutePath)
        if (code != 0 || !target.isFile || target.length() < 100) {
            target.delete()
            error("فشل تدريب النموذج المحلي (code=$code)")
        }

        val metrics = inspect(target)
        val createdAt = System.currentTimeMillis()
        writeMetadata(
            id = id,
            name = name,
            createdAt = createdAt,
            sourceCount = inputs.size,
            preset = preset,
            metrics = metrics,
            digest = sha256(target)
        )
        return readProfile(target) ?: error("تعذر قراءة النموذج بعد التدريب")
    }

    fun remove(profile: TrainedVoiceProfile) {
        profile.file.delete()
        metadataFile(profile.id).delete()
    }

    fun importProfile(
        uri: Uri,
        onDatasetTrainingStarted: (DatasetTrainingInfo) -> Unit = {}
    ): ProfileImportResult {
        val id = newId()
        val target = File(dir, "$id.vsptrain")
        val staging = File(context.cacheDir, "profile-import-${System.nanoTime()}.bin")
        try {
            copyUriLimited(uri, staging, MAX_IMPORT_ARCHIVE_BYTES)
            var sourceFormat = "VSPTRAIN"
            var trainedFromDataset = false
            val imported = if (isZip(staging)) {
                sourceFormat = detectPackageFormat(staging)
                when (sourceFormat) {
                    "VSPMODEL2" -> importPortable(staging, target)
                    "VSPDATASET1" -> {
                        trainedFromDataset = true
                        importDatasetAndTrain(staging, target, onDatasetTrainingStarted)
                    }
                    else -> error("نوع الحزمة $sourceFormat غير مدعوم؛ اختر VSPMODEL2 أو VSPDATASET1")
                }
            } else {
                staging.inputStream().buffered(256 * 1024).use { input ->
                    target.outputStream().buffered(256 * 1024).use { output -> input.copyTo(output, 256 * 1024) }
                }
                ImportedMetadata(
                    name = queryDisplayName(uri)?.substringBeforeLast('.')?.take(80).orEmpty().ifBlank { "نموذج مستورد" },
                    createdAt = System.currentTimeMillis(),
                    sourceCount = 1,
                    preset = TrainingPreset.STUDIO,
                    expectedSha256 = ""
                )
            }

            require(target.length() in 100L..MAX_PROFILE_BYTES) { "حجم نموذج VSPTRAIN غير صالح" }
            require(NativeDsp.validateVoiceProfile(target.absolutePath) == 0) { "ملف VSPTRAIN غير مدعوم أو تالف" }
            val digest = sha256(target)
            if (imported.expectedSha256.isNotBlank()) {
                require(digest.equals(imported.expectedSha256, true)) { "فشل تحقق SHA-256 لحزمة النموذج" }
            }
            val metrics = inspect(target)
            writeMetadata(
                id = id,
                name = imported.name,
                createdAt = imported.createdAt,
                sourceCount = imported.sourceCount,
                preset = imported.preset,
                metrics = metrics,
                digest = digest
            )
            val profile = readProfile(target) ?: error("تعذر تسجيل النموذج المستورد")
            return ProfileImportResult(
                profile = profile,
                sourceFormat = sourceFormat,
                trainedFromDataset = trainedFromDataset
            )
        } catch (t: Throwable) {
            target.delete()
            metadataFile(id).delete()
            throw t
        } finally {
            staging.delete()
        }
    }

    fun exportProfile(profile: TrainedVoiceProfile, uri: Uri) {
        require(profile.file.isFile && NativeDsp.validateVoiceProfile(profile.file.absolutePath) == 0) {
            "النموذج المحدد مفقود أو تالف"
        }
        val digest = sha256(profile.file)
        val manifest = JSONObject()
            .put("format", "VSPMODEL2")
            .put("formatVersion", 2)
            .put("name", profile.name)
            .put("createdAt", profile.createdAt)
            .put("sourceCount", profile.sourceCount)
            .put("sourceSeconds", profile.sourceSeconds)
            .put("cleanSeconds", profile.cleanSeconds)
            .put("qualityScore", profile.qualityScore)
            .put("noiseFloorDb", profile.noiseFloorDb)
            .put("clippingRatio", profile.clippingRatio)
            .put("voicedRatio", profile.voicedRatio)
            .put("medianF0", profile.medianF0)
            .put("profileFormat", profile.format)
            .put("profileFile", "profile.vsptrain")
            .put("sha256", digest)

        context.contentResolver.openOutputStream(uri, "w").use { raw ->
            requireNotNull(raw) { "تعذر فتح مكان حفظ النموذج" }
            ZipOutputStream(BufferedOutputStream(raw, 256 * 1024)).use { zip ->
                zip.setLevel(6)
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("profile.vsptrain"))
                profile.file.inputStream().buffered(256 * 1024).use { it.copyTo(zip, 256 * 1024) }
                zip.closeEntry()
            }
        }
    }

    /** Exports lossless decoded WAV clips for a real GPU RVC training workflow. */
    fun exportTrainingDataset(items: List<TrainingAudioItem>, requestedName: String, uri: Uri) {
        require(items.isNotEmpty()) { "مجموعة التدريب فارغة" }
        require(items.size <= 64) { "الحد الأقصى 64 مقطعًا" }
        val totalSeconds = items.sumOf { it.durationSeconds.toDouble() }
        require(totalSeconds in 5.0..(50.0 * 60.0 + 0.5)) { "مدة مجموعة التدريب غير صالحة" }
        items.forEach { require(it.file.isFile && it.file.length() > 44) { "أحد مقاطع التدريب مفقود" } }

        val clips = JSONArray()
        val names = ArrayList<String>(items.size)
        items.forEachIndexed { index, item ->
            val entryName = "audio/clip-${(index + 1).toString().padStart(3, '0')}.wav"
            names += entryName
            clips.put(
                JSONObject()
                    .put("file", entryName)
                    .put("originalName", item.displayName)
                    .put("durationSeconds", item.durationSeconds)
                    .put("sampleRate", item.sampleRate)
                    .put("channels", item.channels)
                    .put("sha256", sha256(item.file))
            )
        }
        val manifest = JSONObject()
            .put("format", "VSPDATASET1")
            .put("formatVersion", 1)
            .put("name", requestedName.trim().take(80).ifBlank { "Voice Dataset" })
            .put("createdAt", System.currentTimeMillis())
            .put("clipCount", items.size)
            .put("totalSeconds", totalSeconds)
            .put("audio", clips)
            .put("recommendedTrainer", "RVC v2 48k + RMVPE + ContentVec + FAISS")

        context.contentResolver.openOutputStream(uri, "w").use { raw ->
            requireNotNull(raw) { "تعذر فتح مكان حفظ مجموعة التدريب" }
            ZipOutputStream(BufferedOutputStream(raw, 512 * 1024)).use { zip ->
                zip.setLevel(3)
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                items.forEachIndexed { index, item ->
                    zip.putNextEntry(ZipEntry(names[index]))
                    item.file.inputStream().buffered(512 * 1024).use { it.copyTo(zip, 512 * 1024) }
                    zip.closeEntry()
                }
            }
        }
    }

    private fun importPortable(packageFile: File, target: File): ImportedMetadata {
        var manifestText: String? = null
        var profileWritten = false
        var total = 0L
        ZipInputStream(BufferedInputStream(packageFile.inputStream(), 256 * 1024)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                require(!entry.isDirectory) { "حزمة النموذج تحتوي مجلدًا غير متوقع" }
                require(entry.name == "manifest.json" || entry.name == "profile.vsptrain") {
                    "ملف غير متوقع داخل حزمة VSPMODEL"
                }
                when (entry.name) {
                    "manifest.json" -> {
                        require(manifestText == null) { "manifest.json مكرر" }
                        val bytes = zip.readBytesLimited(256 * 1024)
                        total += bytes.size
                        manifestText = bytes.toString(Charsets.UTF_8)
                    }
                    "profile.vsptrain" -> {
                        require(!profileWritten) { "profile.vsptrain مكرر" }
                        FileOutputStream(target).buffered(256 * 1024).use { output ->
                            val buffer = ByteArray(256 * 1024)
                            var entryBytes = 0L
                            while (true) {
                                val count = zip.read(buffer)
                                if (count <= 0) break
                                entryBytes += count
                                total += count
                                require(entryBytes <= MAX_PROFILE_BYTES && total <= MAX_MODEL_PACKAGE_BYTES) {
                                    "حزمة النموذج أكبر من الحد المسموح"
                                }
                                output.write(buffer, 0, count)
                            }
                        }
                        profileWritten = true
                    }
                }
                zip.closeEntry()
            }
        }
        require(profileWritten && !manifestText.isNullOrBlank()) { "حزمة VSPMODEL غير مكتملة" }
        val json = JSONObject(requireNotNull(manifestText))
        require(json.optString("format") == "VSPMODEL2" && json.optInt("formatVersion") == 2) {
            "إصدار حزمة VSPMODEL غير مدعوم"
        }
        require(json.optString("profileFile") == "profile.vsptrain") { "مرجع ملف النموذج غير صالح" }
        val digest = json.optString("sha256")
        require(digest.matches(Regex("[0-9a-fA-F]{64}"))) { "SHA-256 مفقود أو غير صالح" }
        val preset = runCatching { TrainingPreset.valueOf(json.optString("preset", "STUDIO")) }
            .getOrDefault(TrainingPreset.STUDIO)
        return ImportedMetadata(
            name = json.optString("name", "نموذج مستورد").trim().take(80).ifBlank { "نموذج مستورد" },
            createdAt = json.optLong("createdAt", System.currentTimeMillis()).coerceAtLeast(0L),
            sourceCount = json.optInt("sourceCount", 1).coerceIn(1, 64),
            preset = preset,
            expectedSha256 = digest
        )
    }

    private fun detectPackageFormat(packageFile: File): String = ZipFile(packageFile).use { archive ->
        var manifest: ZipEntry? = null
        val entries = archive.entries()
        while (entries.hasMoreElements()) {
            val entry = entries.nextElement()
            if (entry.name == "manifest.json") {
                require(manifest == null) { "manifest.json مكرر داخل الحزمة" }
                require(!entry.isDirectory) { "manifest.json غير صالح" }
                manifest = entry
            }
        }
        val entry = requireNotNull(manifest) { "الحزمة لا تحتوي manifest.json" }
        val text = archive.getInputStream(entry).buffered().use {
            it.readBytesLimited(MAX_MANIFEST_BYTES).toString(Charsets.UTF_8)
        }
        JSONObject(text).optString("format").trim().ifBlank { "UNKNOWN" }
    }

    /**
     * Imports a verified VSPDATASET1 package and immediately turns its lossless WAV payloads into
     * a real on-device VSPTRAIN3 profile. Dataset archives are never passed to the profile parser.
     */
    private fun importDatasetAndTrain(
        packageFile: File,
        target: File,
        onDatasetTrainingStarted: (DatasetTrainingInfo) -> Unit
    ): ImportedMetadata {
        val extractionDir = File(context.cacheDir, "dataset-train-${System.nanoTime()}").apply {
            require(mkdirs()) { "تعذر إنشاء مساحة مؤقتة لتدريب Dataset" }
        }
        try {
            return ZipFile(packageFile).use { archive ->
                val entriesByName = linkedMapOf<String, ZipEntry>()
                val enumeration = archive.entries()
                while (enumeration.hasMoreElements()) {
                    val entry = enumeration.nextElement()
                    if (entry.isDirectory && entry.name == "audio/") continue
                    require(!entry.isDirectory) { "مجلد غير متوقع داخل VSPDATASET" }
                    require(entriesByName.put(entry.name, entry) == null) { "ملف مكرر داخل VSPDATASET: ${entry.name}" }
                }

                val manifestEntry = requireNotNull(entriesByName["manifest.json"]) {
                    "حزمة VSPDATASET لا تحتوي manifest.json"
                }
                val manifestText = archive.getInputStream(manifestEntry).buffered().use {
                    it.readBytesLimited(MAX_MANIFEST_BYTES).toString(Charsets.UTF_8)
                }
                val manifest = JSONObject(manifestText)
                require(manifest.optString("format") == "VSPDATASET1" && manifest.optInt("formatVersion") == 1) {
                    "إصدار VSPDATASET غير مدعوم"
                }

                val audio = manifest.optJSONArray("audio") ?: error("قائمة الصوت مفقودة من VSPDATASET")
                require(audio.length() in 1..64) { "يجب أن تحتوي VSPDATASET من 1 إلى 64 مقطعًا" }
                require(manifest.optInt("clipCount", audio.length()) == audio.length()) {
                    "عدد المقاطع لا يطابق manifest.json"
                }

                val expectedNames = linkedSetOf<String>()
                for (index in 0 until audio.length()) {
                    val relative = audio.getJSONObject(index).getString("file")
                    require(isSafeDatasetAudioPath(relative)) { "مسار صوت غير آمن داخل VSPDATASET" }
                    require(expectedNames.add(relative)) { "مسار صوت مكرر داخل VSPDATASET" }
                }
                require(entriesByName.keys == linkedSetOf("manifest.json").apply { addAll(expectedNames) }) {
                    "تحتوي VSPDATASET ملفات غير معلنة في manifest.json"
                }

                val extracted = ArrayList<File>(audio.length())
                var extractedBytes = 0L
                var actualTotalSeconds = 0f
                for (index in 0 until audio.length()) {
                    val item = audio.getJSONObject(index)
                    val relative = item.getString("file")
                    val expectedDigest = item.optString("sha256")
                    require(expectedDigest.matches(Regex("[0-9a-fA-F]{64}"))) {
                        "SHA-256 مفقود للمقطع ${index + 1}"
                    }
                    val entry = requireNotNull(entriesByName[relative]) { "المقطع ${index + 1} مفقود" }
                    if (entry.size >= 0L) {
                        require(entry.size <= MAX_DATASET_AUDIO_BYTES - extractedBytes) {
                            "حجم الصوت المفكوك في VSPDATASET أكبر من الحد المسموح"
                        }
                    }

                    val output = File(extractionDir, "clip-${(index + 1).toString().padStart(3, '0')}.wav")
                    val digest = MessageDigest.getInstance("SHA-256")
                    var clipBytes = 0L
                    archive.getInputStream(entry).buffered(512 * 1024).use { input ->
                        FileOutputStream(output).buffered(512 * 1024).use { sink ->
                            val buffer = ByteArray(512 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count <= 0) break
                                clipBytes += count
                                extractedBytes += count
                                require(extractedBytes <= MAX_DATASET_AUDIO_BYTES) {
                                    "حجم الصوت المفكوك في VSPDATASET أكبر من الحد المسموح"
                                }
                                digest.update(buffer, 0, count)
                                sink.write(buffer, 0, count)
                            }
                        }
                    }
                    require(clipBytes > 44L) { "المقطع ${index + 1} فارغ" }
                    val actualDigest = digest.digest().joinToString("") { "%02x".format(it) }
                    require(actualDigest.equals(expectedDigest, true)) {
                        "فشل تحقق SHA-256 للمقطع ${index + 1}"
                    }

                    val info = WavUtils.readInfo(output)
                    require(info.audioFormat in setOf(1, 3) && info.channels in 1..8 && info.sampleRate in 12_000..192_000) {
                        "تنسيق WAV غير مدعوم في المقطع ${index + 1}"
                    }
                    val frameBytes = (info.bitsPerSample / 8).coerceAtLeast(1) * info.channels
                    val seconds = (info.dataSize.toDouble() / frameBytes / info.sampleRate).toFloat()
                    require(seconds >= 1f) { "المقطع ${index + 1} أقصر من ثانية" }
                    val declaredSeconds = item.optDouble("durationSeconds", seconds.toDouble()).toFloat()
                    require(kotlin.math.abs(seconds - declaredSeconds) <= maxOf(0.25f, seconds * 0.005f)) {
                        "مدة المقطع ${index + 1} لا تطابق manifest.json"
                    }
                    if (item.has("sampleRate")) require(item.optInt("sampleRate") == info.sampleRate) {
                        "معدل العينة للمقطع ${index + 1} لا يطابق manifest.json"
                    }
                    if (item.has("channels")) require(item.optInt("channels") == info.channels) {
                        "عدد القنوات للمقطع ${index + 1} لا يطابق manifest.json"
                    }
                    actualTotalSeconds += seconds
                    extracted += output
                }

                require(actualTotalSeconds in 5f..(50f * 60f + 0.5f)) { "مدة VSPDATASET خارج نطاق التدريب" }
                val declaredTotal = manifest.optDouble("totalSeconds", actualTotalSeconds.toDouble()).toFloat()
                require(kotlin.math.abs(actualTotalSeconds - declaredTotal) <= maxOf(0.5f, actualTotalSeconds * 0.005f)) {
                    "المدة الإجمالية لا تطابق manifest.json"
                }
                val preset = when {
                    actualTotalSeconds >= TrainingPreset.ULTRA.minimumRecommendedSeconds -> TrainingPreset.ULTRA
                    actualTotalSeconds >= TrainingPreset.STUDIO.minimumRecommendedSeconds -> TrainingPreset.STUDIO
                    else -> TrainingPreset.QUICK
                }
                val name = manifest.optString("name", "نموذج Dataset").trim().take(80).ifBlank { "نموذج Dataset" }
                onDatasetTrainingStarted(DatasetTrainingInfo(name, extracted.size, actualTotalSeconds))

                val code = NativeDsp.trainVoiceProfileSet(
                    extracted.map { it.absolutePath }.toTypedArray(),
                    target.absolutePath
                )
                if (code != 0 || !target.isFile || target.length() < 100L) {
                    target.delete()
                    error("فشل تحويل VSPDATASET إلى VSPTRAIN3 (code=$code)")
                }
                require(NativeDsp.validateVoiceProfile(target.absolutePath) == 0) {
                    "اكتمل التدريب لكن ملف VSPTRAIN3 الناتج لم يجتز التحقق"
                }
                ImportedMetadata(
                    name = name,
                    createdAt = System.currentTimeMillis(),
                    sourceCount = extracted.size,
                    preset = preset,
                    expectedSha256 = ""
                )
            }
        } finally {
            extractionDir.deleteRecursively()
        }
    }

    private fun isSafeDatasetAudioPath(path: String): Boolean =
        path.startsWith("audio/") &&
            path.count { it == '/' } == 1 &&
            !path.contains('\\') &&
            !path.contains("..") &&
            path.substringAfter("audio/").matches(Regex("[A-Za-z0-9._-]+\\.wav", RegexOption.IGNORE_CASE))

    private fun readProfile(file: File): TrainedVoiceProfile? {
        val metrics = runCatching { inspect(file) }.getOrNull() ?: return null
        val id = file.nameWithoutExtension
        val properties = Properties()
        val meta = metadataFile(id)
        if (meta.isFile) runCatching { meta.inputStream().use(properties::load) }
        val digest = properties.getProperty("sha256")?.takeIf { it.matches(Regex("[0-9a-fA-F]{64}")) }
            ?: runCatching { sha256(file) }.getOrDefault("")
        return TrainedVoiceProfile(
            id = id,
            name = properties.getProperty("name")?.takeIf { it.isNotBlank() } ?: "نموذج صوتي مدرب",
            file = file,
            createdAt = properties.getProperty("createdAt")?.toLongOrNull() ?: file.lastModified(),
            sourceSeconds = metrics.sourceSeconds,
            sourceCount = properties.getProperty("sourceCount")?.toIntOrNull()?.coerceIn(1, 64) ?: 1,
            format = "VSPTRAIN${metrics.version}",
            cleanSeconds = metrics.cleanSeconds,
            qualityScore = metrics.qualityScore,
            clippingRatio = metrics.clippingRatio,
            noiseFloorDb = metrics.noiseFloorDb,
            medianF0 = metrics.medianF0,
            voicedRatio = metrics.voicedRatio,
            spectralCentroid = metrics.spectralCentroid,
            sha256 = digest
        )
    }

    private fun inspect(file: File): ProfileMetrics {
        require(NativeDsp.validateVoiceProfile(file.absolutePath) == 0) { "نموذج VSPTRAIN غير صالح" }
        val values = NativeDsp.inspectVoiceProfile(file.absolutePath)
        require(values.size >= 10 && values[0] >= 1f) { "تعذر قراءة قياسات نموذج VSPTRAIN" }
        return ProfileMetrics(
            version = values[0].toInt(),
            sourceSeconds = values[1].coerceAtLeast(0f),
            cleanSeconds = values[2].coerceAtLeast(0f),
            qualityScore = values[3].coerceIn(0f, 100f),
            clippingRatio = values[4].coerceAtLeast(0f),
            noiseFloorDb = values[5].coerceIn(-120f, 0f),
            medianF0 = values[6].coerceAtLeast(0f),
            voicedRatio = values[7].coerceIn(0f, 1f),
            spectralCentroid = values[8].coerceAtLeast(0f)
        )
    }

    private fun writeMetadata(
        id: String,
        name: String,
        createdAt: Long,
        sourceCount: Int,
        preset: TrainingPreset,
        metrics: ProfileMetrics,
        digest: String
    ) {
        val properties = Properties().apply {
            setProperty("name", name)
            setProperty("createdAt", createdAt.toString())
            setProperty("sourceCount", sourceCount.toString())
            setProperty("sourceSeconds", metrics.sourceSeconds.toString())
            setProperty("cleanSeconds", metrics.cleanSeconds.toString())
            setProperty("qualityScore", metrics.qualityScore.toString())
            setProperty("noiseFloorDb", metrics.noiseFloorDb.toString())
            setProperty("clippingRatio", metrics.clippingRatio.toString())
            setProperty("preset", preset.name)
            setProperty("format", "VSPTRAIN${metrics.version}")
            setProperty("sha256", digest)
        }
        metadataFile(id).outputStream().use { properties.store(it, "VocalStudioPro portable trained voice profile") }
    }

    private fun copyUriLimited(uri: Uri, target: File, limit: Long) {
        val source = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح ملف الاستيراد")
        source.buffered(256 * 1024).use { input ->
            target.outputStream().buffered(256 * 1024).use { output ->
                val buffer = ByteArray(256 * 1024)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    total += count
                require(total <= limit) { "ملف الاستيراد أكبر من الحد المسموح" }
                    output.write(buffer, 0, count)
                }
            }
        }
        require(target.length() > 0) { "ملف الاستيراد فارغ" }
    }

    private fun InputStream.readBytesLimited(limit: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val count = read(buffer)
            if (count <= 0) break
            require(output.size() + count <= limit) { "manifest.json أكبر من الحد المسموح" }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun ZipInputStream.readBytesLimited(limit: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val count = read(buffer)
            if (count <= 0) break
            require(output.size() + count <= limit) { "manifest.json أكبر من الحد المسموح" }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun isZip(file: File): Boolean = file.inputStream().use { input ->
        val header = ByteArray(4)
        input.read(header) == 4 && header[0] == 0x50.toByte() && header[1] == 0x4b.toByte() &&
            header[2] in listOf(0x03.toByte(), 0x05.toByte(), 0x07.toByte())
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull()

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(256 * 1024).use { input ->
            val buffer = ByteArray(256 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun metadataFile(id: String) = File(dir, "$id.properties")
    private fun newId(): String = UUID.randomUUID().toString().replace("-", "")
    private fun formatDuration(seconds: Float): String = if (seconds < 60f) {
        "${seconds.toInt()} ثوانٍ"
    } else {
        "${(seconds / 60f).toInt()} دقائق"
    }

    private data class ProfileMetrics(
        val version: Int,
        val sourceSeconds: Float,
        val cleanSeconds: Float,
        val qualityScore: Float,
        val clippingRatio: Float,
        val noiseFloorDb: Float,
        val medianF0: Float,
        val voicedRatio: Float,
        val spectralCentroid: Float
    )

    private data class ImportedMetadata(
        val name: String,
        val createdAt: Long,
        val sourceCount: Int,
        val preset: TrainingPreset,
        val expectedSha256: String
    )

    companion object {
        private const val MAX_PROFILE_BYTES = 8L * 1024L * 1024L
        private const val MAX_MODEL_PACKAGE_BYTES = 16L * 1024L * 1024L
        private const val MAX_IMPORT_ARCHIVE_BYTES = 768L * 1024L * 1024L
        private const val MAX_DATASET_AUDIO_BYTES = 1024L * 1024L * 1024L
        private const val MAX_MANIFEST_BYTES = 256 * 1024
    }
}

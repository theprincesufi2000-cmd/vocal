# Vocal Studio Pro 1.6.1 — Verification

- versionName: 1.6.1
- versionCode: 13
- C++/JNI strict compile: tested with `-Wall -Wextra -Werror`.
- VSPTRAIN3 multi-clip train/inspect/validate/apply: tested end-to-end on the host toolchain.
- Training source smoke test: two independent 4 s / 48 kHz / PCM24 clips.
- Output: 48 kHz / PCM24 with source frame count preserved.
- Profile size in synthetic test: ~19 KB.
- 50-minute hard limit: verified via header/duration validation; 50:01 is rejected before processing.
- Existing RVC/Applio adaptive-frame engine retained.
- User dataset regression: 180.168 s / 48 kHz / stereo PCM16 trained, validated and inspected as VSPTRAIN3.
- VSPDATASET1 import verifies manifest structure, WAV metadata and each payload SHA-256 before training.

A full Android `assembleRelease` is delegated to the included GitHub Actions workflow when the local environment does not contain the Android SDK/Maven dependency set.

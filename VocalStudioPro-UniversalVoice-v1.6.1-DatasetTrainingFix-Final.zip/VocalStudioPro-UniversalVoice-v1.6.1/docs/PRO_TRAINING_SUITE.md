# Pro Training Suite 1.6.1

VocalStudioPro now separates two technically different training paths so the UI never describes
a lightweight mobile profile as a neural RVC checkpoint.

## 1. On-device VSPTRAIN3

This path runs entirely on Android. Select up to 64 recordings with a combined maximum of 50
minutes. The native engine performs two streaming passes:

1. Measure the noise floor, clipping and activity threshold independently for each recording.
2. Fit one shared 96-band speaker envelope, voiced/unvoiced statistics, four pitch registers,
   30 adaptive prototypes and a 12-component PCA articulation manifold.

The UI polls progress from the native engine. Cancellation is checked between streamed blocks and
never installs a partial profile.

The result is small and fast. It preserves the original words, timing and pitch contour. It is a
speaker-timbre adaptation profile, not a neural generator checkpoint.

New exports use `.vspmodel` (VSPMODEL2), containing:

```text
manifest.json
profile.vsptrain
```

The manifest preserves the model name, training duration, source count and quality metrics. A
SHA-256 digest is verified before import. Legacy raw `.vsptrain` files are still accepted.

## 2. Neural RVC training dataset

Use **تصدير Dataset** to create a `.vspdataset` package from the selected recordings. It preserves
the decoded WAV clips and includes a manifest plus an individual SHA-256 digest for every clip.
This is the hand-off format for a GPU RVC workflow.

Version 1.6.1 can also import this package in the local-training section. It verifies the manifest,
every declared WAV property and every SHA-256 digest, then trains those recordings into a real
VSPTRAIN3 profile. The original Dataset remains a collection of training audio; only the generated
VSPTRAIN3/VSPMODEL2 output is an applicable local model.

For full neural conversion, train RVC v2 at 48 kHz with RMVPE, ContentVec and a FAISS retrieval
index on a GPU machine or notebook. The official RVC project recommends at least ten minutes of
low-noise speech. After training, export the synthesizer to ONNX and put `voice.onnx` together with
the compatible ContentVec encoder and optional pitch model in one ZIP. VocalStudioPro discovers
the graph I/O at import time.

The Android application deliberately does not run PyTorch backpropagation: a full RVC/VITS run
requires pretrained checkpoints, several gigabytes of dependencies and sustained GPU memory. The
phone performs dataset preparation, integrity-preserving exchange and ONNX inference instead.

## Portable RVC model export

**تصدير كامل** creates a self-contained `.vspvoice`. If the selected model references the shared
RVC core, that core is embedded and metadata is rewritten to local package paths. Each payload is
hashed. Import verifies the hash table before installing the model.

## Command-line verification

```bash
python tools/vsp_package_tool.py verify MyVoice.vspmodel
python tools/vsp_package_tool.py verify MyVoice.vspvoice
python tools/vsp_package_tool.py verify MyVoice.vspdataset
python tools/vsp_package_tool.py extract MyVoice.vspdataset output-directory
```

Only train or apply a voice when the speaker has consented or you otherwise have the necessary
rights.

# Vocal Studio Pro 1.2.0 — Voice Models

Native Android vocal production app built with **Kotlin + Jetpack Compose + C++17/NDK/JNI + ONNX Runtime Android**. It records/imports vocals, performs high-quality cleanup and key-aware pitch correction, optionally applies a locally imported authorized voice-conversion model, then produces a 24-bit/48 kHz studio master.

## Processing pipeline

```text
Recorded / imported vocal
        ↓
48 kHz float conversion
        ↓
Spectral noise cleanup + hum removal
        ↓
YIN F0 + scale quantization + dynamic Auto-Tune
        ↓
(optional) Authorized ONNX Voice Model
  Content encoder → F0 model → RVC ONNX synthesizer
        ↓
Consonant / breath protection + original/converted mix
        ↓
Vocal leveling + multiband compression
        ↓
Dynamic EQ + split-band de-esser
        ↓
Warmth / Clarity / Air + saturation
        ↓
Plate reverb
        ↓
True-peak lookahead limiter
        ↓
WAV PCM 24-bit / 48 kHz
```

## Voice Model system

The application does **not** bundle a singer/celebrity voice. It imports `.vspvoice` packages locally. Use voices you own, your own voice, or voices for which you have explicit permission/license.

A package contains:

```text
metadata.json
content_encoder.onnx
pitch.onnx
voice.onnx
cover.png       (optional)
license.txt     (recommended)
```

The synthesizer contract follows the official RVC ONNX interface (`phone`, `phone_lengths`, `pitch`, `pitchf`, `ds`, `rnd` → `audio`). See `docs/VOICE_MODEL_FORMAT.md`.

### Quality controls

- **Voice Mix**: controls how much converted timbre is blended into the source.
- **Pitch compensation**: ±24 semitones before the voice synthesizer.
- **Consonant protection**: uses unvoiced F0 regions to preserve consonants, breaths, and attacks from the original.
- **Fast / Balanced / Ultra**: controls chunk size and inference thread count.
- **NNAPI**: attempted first when enabled. If a graph cannot run there, the runtime tries **XNNPACK** and finally optimized ONNX Runtime CPU.
- Long audio is processed in overlapped chunks with crossfades to avoid large single-pass memory spikes and hard seams.

## Studio Clean / Auto-Tune

- Adaptive STFT/Wiener-style noise reduction.
- Noise profile from quiet frames.
- 50/60 Hz hum-family removal.
- Soft downward expansion instead of a hard noise gate.
- YIN pitch detection and octave-error stabilization.
- Key-aware Major/Natural Minor quantization.
- Dynamic phase-vocoder pitch correction with Strength / Retune / Humanize.
- Vocal leveling, 3-band dynamics, de-essing, tone enhancement, plate, and true-peak limiting.

## Audio input/output

- Recording: mono WAV at 48 kHz with system AGC/AEC/NS disabled where the device allows it.
- Import: WAV or formats supported by the device MediaCodec stack (commonly MP3/M4A/AAC/FLAC/OGG).
- Final export: mono PCM WAV, 24-bit, 48 kHz.

## Build toolchain

- JDK 17
- Android SDK Platform 37.0 (`compileSdk=37`, `targetSdk=37`)
- Android NDK `28.2.13676358`
- CMake `3.22.1`
- Gradle `9.6.0` (the included launcher pins this version)
- Android Gradle Plugin `9.4.0`
- Kotlin/Compose plugin `2.3.21`
- Compose BOM `2026.08.00`
- AndroidX Lifecycle `2.11.0`
- ONNX Runtime Android `1.29.0`

## Build

```bash
chmod +x gradlew
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

The source project includes `.github/workflows/build.yml` for repositories that store the extracted source. If your GitHub repository stores this project as a ZIP, use the separate `build-v1.2.0.yml` supplied with the release.

## Creating a `.vspvoice` package

`tools/create_voice_pack.py` packages **already compatible and authorized** ONNX models. It does not train a voice.

```bash
python tools/create_voice_pack.py \
  --content content_encoder.onnx \
  --pitch pitch.onnx \
  --voice voice.onnx \
  --name "My Authorized Voice" \
  --id my-authorized-voice-v1 \
  --author "Owner" \
  --confirm-authorized \
  --output MyVoice.vspvoice
```

Model-export details are in `docs/VOICE_MODEL_FORMAT.md`.

## Performance notes

- Native cleanup/Auto-Tune/master remains C++ compiled with `-O3 -ffast-math`.
- ONNX Runtime graph optimizations are enabled for all voice graphs.
- Execution-provider order: NNAPI → XNNPACK → CPU, with automatic fallback.
- The app uses direct native-order buffers for ONNX tensors to reduce copies.
- Imported voice models remain outside the APK, so the application package stays relatively small.
- ARM64 is recommended for demanding `Ultra` voice conversion.

## Limitations

Quality depends heavily on the imported model and its matching content/F0 encoder. Generic `.pth`, `.index`, stock HuBERT/ContentVec, or stock RMVPE ONNX files are not automatically compatible with the Android pack contract; compatible adapter/export graphs are required. See `docs/VOICE_MODEL_FORMAT.md`. A model trained poorly or with strong backing music/reverb cannot be made studio-quality solely by inference. Dry solo vocals are the best source for conversion.

## License

Application source: MIT. Android SDK/AndroidX/Gradle and ONNX Runtime retain their respective licenses. Imported voice models retain the rights and restrictions granted by their owners.

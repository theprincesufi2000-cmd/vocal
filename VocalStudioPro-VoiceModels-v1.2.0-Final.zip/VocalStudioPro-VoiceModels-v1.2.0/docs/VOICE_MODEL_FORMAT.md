# VSPVOICE v1 — Authorized ONNX Voice Pack

Vocal Studio Pro 1.2.0 does not bundle a person's identity or voice. A voice is installed as a local `.vspvoice` ZIP package. Package only models you own or have explicit permission/license to use.

## Required files

```text
MyVoice.vspvoice
├── metadata.json
├── content_encoder.onnx
├── pitch.onnx
├── voice.onnx
├── cover.png          # optional
└── license.txt        # recommended
```

The three ONNX graphs are separate so Android can optimize and cache each inference stage independently. External-data sidecar files referenced by an ONNX graph may also be included in the ZIP; they must stay at the relative paths expected by that graph.

## Important compatibility rule

A `.pth`, `.index`, generic HuBERT/ContentVec export, or stock `rmvpe.onnx` file is **not automatically a VSPVOICE pack**.

VSPVOICE deliberately uses Android-friendly adapter contracts:

- `content_encoder.onnx` must accept raw mono Float32 waveform and directly output the final RVC phone/content features.
- `pitch.onnx` must accept raw mono Float32 waveform and directly output F0 values in Hz.
- `voice.onnx` must expose the RVC synthesizer tensors described below.

The stock RVC RMVPE ONNX path normally receives a 128-bin mel representation and produces salience that still requires cents/F0 decoding, so it needs to be wrapped/exported with that preprocessing and decoding before it can be used as this package's `pitch.onnx`. Likewise, a generic content encoder that requires extra inputs or returns an intermediate hidden state must be exported/wrapped to the single-input contract below.

All graph inputs and outputs described below are Float32 unless explicitly stated Int64.

### `content_encoder.onnx`

Contract: one mono Float32 waveform input and one Float32 features output.

- input shape: `[1,samples]` when `contentInputRank=2`, or `[1,1,samples]` when rank=3.
- default input name: `audio`.
- output layout: `BTC` (`[1,time,channels]`) or `BCT` (`[1,channels,time]`). Rank-2 equivalents are also accepted.
- output must already be the representation expected by the RVC synthesizer: commonly 256 channels for RVC v1 or 768 for RVC v2.
- use `featureUpsample=2` when an exported encoder produces 50 fps features that must be interpolated to 100 fps for the synthesizer.

### `pitch.onnx`

Contract: one mono Float32 waveform input and one Float32 F0 output **in Hz**.

- default input name: `audio`.
- default output name: `f0`.
- unvoiced frames must be `0`.
- the application aligns the F0 sequence to the content-feature frame count, applies optional semitone compensation, and builds the RVC coarse-pitch Int64 tensor.

### `voice.onnx`

The default tensor names match the RVC ONNX synthesizer exporter:

- `phone`: Float32 `[1,T,C]`
- `phone_lengths`: Int64 `[1]`
- `pitch`: Int64 `[1,T]`
- `pitchf`: Float32 `[1,T]`
- `ds`: Int64 `[1]`
- `rnd`: Float32 `[1,192,T]`
- output `audio`: Float32 audio tensor

The names are configurable in `metadata.json` for compatible custom exports.

## `metadata.json` example

```json
{
  "format": "VSPVOICE",
  "formatVersion": 1,
  "id": "my-authorized-voice-v1",
  "name": "My Authorized Voice",
  "author": "Owner Name",
  "license": "Private authorized use",
  "authorized": true,
  "engine": "rvc-onnx-v2",
  "sampleRate": 40000,
  "contentSampleRate": 16000,
  "featureChannels": 768,
  "contentInput": "audio",
  "contentOutput": "features",
  "contentInputRank": 2,
  "contentOutputLayout": "BTC",
  "featureUpsample": 2,
  "pitchInput": "audio",
  "pitchOutput": "f0",
  "pitchInputRank": 2,
  "voicePhoneInput": "phone",
  "voicePhoneLengthsInput": "phone_lengths",
  "voicePitchInput": "pitch",
  "voicePitchFInput": "pitchf",
  "voiceSpeakerInput": "ds",
  "voiceNoiseInput": "rnd",
  "voiceOutput": "audio",
  "speakerId": 0
}
```

`authorized=true` is mandatory. It records the pack creator's confirmation; it does not replace the real permission/license from the voice owner.

## Performance and long recordings

- Voice inference is chunked instead of loading an entire long song into one graph call.
- Adjacent chunks overlap and are crossfaded to avoid hard seams.
- The final chunk is anchored to the end of the recording so a tiny trailing chunk is not sent to the model.
- `Fast`, `Balanced`, and `Ultra` select chunk length and worker count.
- If enabled, the runtime tries NNAPI first, then XNNPACK, then optimized ONNX Runtime CPU.
- Direct native-order tensor buffers are used to reduce avoidable Java-array copies.
- ARM64 is recommended for demanding models.

## Creating a pack

The included packer only packages **already-compatible ONNX graphs**. It does not train or clone a voice.

```bash
python tools/create_voice_pack.py \
  --content content_encoder.onnx \
  --pitch pitch.onnx \
  --voice voice.onnx \
  --name "My Authorized Voice" \
  --id my-authorized-voice-v1 \
  --author "Owner" \
  --confirm-authorized \
  --output MyVoice.vspvoice
```

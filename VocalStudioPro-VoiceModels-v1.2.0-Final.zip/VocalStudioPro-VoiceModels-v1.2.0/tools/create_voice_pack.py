#!/usr/bin/env python3
"""Package already-compatible, authorized ONNX graphs into a .vspvoice file.

This utility does not train, clone, scrape, or download a person's voice. It only
packages model files that the operator already has permission to use.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import zipfile


def existing_model(value: str) -> pathlib.Path:
    path = pathlib.Path(value)
    if not path.is_file() or path.stat().st_size < 1024:
        raise argparse.ArgumentTypeError(f"Missing/invalid ONNX model: {path}")
    return path


def main() -> None:
    ap = argparse.ArgumentParser(description="Create an authorized VSPVOICE package")
    ap.add_argument("--content", required=True, type=existing_model)
    ap.add_argument("--pitch", required=True, type=existing_model)
    ap.add_argument("--voice", required=True, type=existing_model)
    ap.add_argument("--name", required=True)
    ap.add_argument("--id", required=True)
    ap.add_argument("--author", required=True)
    ap.add_argument("--license", default="Private authorized use")
    ap.add_argument("--license-file", type=pathlib.Path)
    ap.add_argument("--cover", type=pathlib.Path)
    ap.add_argument("--sample-rate", type=int, choices=range(16000, 96001), default=40000)
    ap.add_argument("--feature-channels", type=int, choices=(256, 768, 1024), default=768)
    ap.add_argument("--feature-upsample", type=int, choices=(1, 2, 3, 4), default=2)
    ap.add_argument("--speaker-id", type=int, default=0)
    ap.add_argument("--output", required=True, type=pathlib.Path)
    ap.add_argument(
        "--confirm-authorized",
        action="store_true",
        help="Required confirmation that you own or are authorized to use the packaged voice model.",
    )
    args = ap.parse_args()

    if not args.confirm_authorized:
        raise SystemExit("Refusing to package: pass --confirm-authorized only when you have permission to use this voice model.")
    if args.cover is not None and not args.cover.is_file():
        raise SystemExit(f"Cover file not found: {args.cover}")
    if args.license_file is not None and not args.license_file.is_file():
        raise SystemExit(f"License file not found: {args.license_file}")

    model_id = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in args.id.strip().lower()).strip("-")
    if not model_id:
        raise SystemExit("--id must contain at least one letter or number")

    meta = {
        "format": "VSPVOICE",
        "formatVersion": 1,
        "id": model_id[:64],
        "name": args.name.strip()[:128],
        "author": args.author.strip()[:128],
        "license": args.license.strip()[:256],
        "authorized": True,
        "engine": "rvc-onnx-v2" if args.feature_channels != 256 else "rvc-onnx-v1",
        "sampleRate": args.sample_rate,
        "contentSampleRate": 16000,
        "featureChannels": args.feature_channels,
        "contentInput": "audio",
        "contentOutput": "features",
        "contentInputRank": 2,
        "contentOutputLayout": "BTC",
        "featureUpsample": args.feature_upsample,
        "pitchInput": "audio",
        "pitchOutput": "f0",
        "pitchInputRank": 2,
        "voicePhoneInput": "phone",
        "voicePhoneLengthsInput": "phone_lengths",
        "voicePitchInput": "pitch",
        "voicePitchFInput": "pitchf",
        "voiceSpeakerInput": "ds",
        "voiceNoiseInput": "rnd",
        "voiceOutput": "audio",
        "speakerId": args.speaker_id,
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        z.writestr("metadata.json", json.dumps(meta, ensure_ascii=False, indent=2))
        z.write(args.content, "content_encoder.onnx")
        z.write(args.pitch, "pitch.onnx")
        z.write(args.voice, "voice.onnx")
        if args.cover is not None:
            z.write(args.cover, "cover.png")
        if args.license_file is not None:
            z.write(args.license_file, "license.txt")

    with zipfile.ZipFile(args.output, "r") as z:
        bad = z.testzip()
        if bad is not None:
            raise SystemExit(f"ZIP verification failed at {bad}")
    print(args.output)


if __name__ == "__main__":
    main()

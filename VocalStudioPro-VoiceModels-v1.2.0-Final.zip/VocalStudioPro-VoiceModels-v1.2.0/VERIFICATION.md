# Vocal Studio Pro 1.2.0 — Verification

Date: 2026-09-05

## Build configuration audited

- Android Gradle Plugin: 9.4.0
- Gradle: pinned to 9.6.0
- JDK: 17
- compileSdk / targetSdk: 37
- CI Android SDK package: platforms;android-37.0
- Build Tools: 36.0.0
- NDK: 28.2.13676358
- CMake: 3.22.1
- Compose BOM: 2026.08.00
- Activity Compose: 1.13.0
- Core: 1.19.0
- Lifecycle ViewModel Compose / Runtime Compose: 2.11.0
- Kotlin Compose plugin: 2.3.21
- ONNX Runtime Android: 1.29.0

## Native validation performed

All C++ DSP and JNI translation units were compiled locally with:

```text
-std=c++17 -O2 -Wall -Wextra -Werror
```

Result: PASS.

Validated sources: WavIO, YIN pitch detection, scale quantizer, phase vocoder, spectral denoiser, studio DSP, VocalEngine, and JNI bridge.

## Kotlin validation performed

- Compose StudioScreen compiled against API-compatible local stubs: PASS.
- VoiceConversionEngine, VoiceModel, VoiceWavIO and VoiceConversionParams compiled against ONNX-compatible API stubs: PASS.
- ONNX Runtime Java API signatures used by the project were checked against the current official SessionOptions documentation (NNAPI and XNNPACK).

## Voice pack validation performed

`tools/create_voice_pack.py` was executed end-to-end with test ONNX placeholder files to create a `.vspvoice` archive. ZIP integrity and metadata JSON validation passed.

## Native DSP functional checks

The inherited 1.1.x DSP path was previously validated with synthetic vocal-like WAV files for pitch correction, noise cleanup, 48 kHz / 24-bit output, duration preservation, and 44.1 kHz stereo to 48 kHz mono conversion. The 1.2.0 branch keeps that native engine and adds split pre-model/master entry points through JNI.

## Reliability / security checks

- Imported voice packs require `authorized=true` metadata.
- ZIP extraction blocks path traversal and enforces file-count / size ceilings.
- Failed model updates restore the previous installed model.
- Long voice conversion runs in overlapped chunks with crossfades.
- Execution-provider fallback order: NNAPI → XNNPACK → CPU.
- `ndk.dir` is not generated; the project uses `android.ndkVersion`.
- Gradle launcher is pinned to 9.6.0.
- No TODO/FIXME/placeholder implementation remains under `app/src`.

## Important limitation

A complete Android `assembleDebug` / `assembleRelease` was not executed in this local container because the Android SDK and Maven dependency cache are not installed here. The included GitHub Actions workflow performs that final Android build using the pinned toolchain.

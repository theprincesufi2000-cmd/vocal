#include <jni.h>
#include <string>
#include "VocalEngine.h"

namespace {
VocalParams paramsFrom(
    jint rootPitchClass, jint scaleMode,
    jfloat strength, jfloat retuneMs, jfloat humanize,
    jfloat noiseReduction, jfloat clarity, jfloat warmth, jfloat air,
    jfloat deEsser, jfloat compression, jfloat leveling, jfloat reverb) {
    VocalParams p;
    p.rootPitchClass = rootPitchClass;
    p.scaleMode = scaleMode;
    p.strength = strength;
    p.retuneMs = retuneMs;
    p.humanize = humanize;
    p.noiseReduction = noiseReduction;
    p.clarity = clarity;
    p.warmth = warmth;
    p.air = air;
    p.deEsser = deEsser;
    p.compression = compression;
    p.leveling = leveling;
    p.reverb = reverb;
    return p;
}

template <typename Fn>
jint withPaths(JNIEnv* env, jstring inputPath, jstring outputPath, Fn&& fn) {
    if (!inputPath || !outputPath) return 1;
    const char* in = env->GetStringUTFChars(inputPath, nullptr);
    const char* out = env->GetStringUTFChars(outputPath, nullptr);
    if (!in || !out) {
        if (in) env->ReleaseStringUTFChars(inputPath, in);
        if (out) env->ReleaseStringUTFChars(outputPath, out);
        return 2;
    }
    std::string error;
    const int result = fn(in, out, error);
    env->ReleaseStringUTFChars(inputPath, in);
    env->ReleaseStringUTFChars(outputPath, out);
    return result;
}
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_processWav(
    JNIEnv* env, jclass, jstring inputPath, jstring outputPath,
    jint rootPitchClass, jint scaleMode, jfloat strength, jfloat retuneMs, jfloat humanize,
    jfloat noiseReduction, jfloat clarity, jfloat warmth, jfloat air,
    jfloat deEsser, jfloat compression, jfloat leveling, jfloat reverb) {
    const VocalParams p = paramsFrom(rootPitchClass, scaleMode, strength, retuneMs, humanize,
                                     noiseReduction, clarity, warmth, air, deEsser,
                                     compression, leveling, reverb);
    return withPaths(env, inputPath, outputPath,
        [&](const char* in, const char* out, std::string& error) {
            return VocalEngine::processFile(in, out, p, error);
        });
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_prepareForVoiceModel(
    JNIEnv* env, jclass, jstring inputPath, jstring outputPath,
    jint rootPitchClass, jint scaleMode, jfloat strength, jfloat retuneMs, jfloat humanize,
    jfloat noiseReduction) {
    VocalParams p;
    p.rootPitchClass = rootPitchClass;
    p.scaleMode = scaleMode;
    p.strength = strength;
    p.retuneMs = retuneMs;
    p.humanize = humanize;
    p.noiseReduction = noiseReduction;
    return withPaths(env, inputPath, outputPath,
        [&](const char* in, const char* out, std::string& error) {
            return VocalEngine::prepareForVoiceModel(in, out, p, error);
        });
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_masterOnly(
    JNIEnv* env, jclass, jstring inputPath, jstring outputPath,
    jfloat clarity, jfloat warmth, jfloat air, jfloat deEsser,
    jfloat compression, jfloat leveling, jfloat reverb) {
    VocalParams p;
    p.clarity = clarity;
    p.warmth = warmth;
    p.air = air;
    p.deEsser = deEsser;
    p.compression = compression;
    p.leveling = leveling;
    p.reverb = reverb;
    return withPaths(env, inputPath, outputPath,
        [&](const char* in, const char* out, std::string& error) {
            return VocalEngine::masterOnly(in, out, p, error);
        });
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_engineVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF(VocalEngine::version());
}

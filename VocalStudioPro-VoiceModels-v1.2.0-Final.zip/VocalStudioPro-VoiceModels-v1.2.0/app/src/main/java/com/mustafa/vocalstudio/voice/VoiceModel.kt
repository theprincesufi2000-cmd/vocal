package com.mustafa.vocalstudio.voice

import org.json.JSONObject
import java.io.File

/**
 * A local, user-imported voice conversion pack.
 * The app only accepts packs that declare authorized=true in metadata.json.
 */
data class VoiceModel(
    val id: String,
    val name: String,
    val author: String,
    val engine: String,
    val sampleRate: Int,
    val contentSampleRate: Int,
    val featureChannels: Int,
    val contentInput: String,
    val contentOutput: String,
    val contentInputRank: Int,
    val contentOutputLayout: String,
    val featureUpsample: Int,
    val pitchInput: String,
    val pitchOutput: String,
    val pitchInputRank: Int,
    val voicePhoneInput: String,
    val voicePhoneLengthsInput: String,
    val voicePitchInput: String,
    val voicePitchFInput: String,
    val voiceSpeakerInput: String,
    val voiceNoiseInput: String,
    val voiceOutput: String,
    val speakerId: Long,
    val authorized: Boolean,
    val licenseLabel: String,
    val directory: File
) {
    val contentModel: File get() = File(directory, "content_encoder.onnx")
    val pitchModel: File get() = File(directory, "pitch.onnx")
    val voiceModel: File get() = File(directory, "voice.onnx")
    val coverFile: File get() = File(directory, "cover.png")

    fun validateFiles() {
        require(authorized) { "النموذج لا يصرّح بوجود تفويض لاستخدام الصوت" }
        require(engine == "rvc-onnx-v2" || engine == "rvc-onnx-v1") { "محرك نموذج غير مدعوم: $engine" }
        require(sampleRate in 16_000..96_000) { "Sample rate غير صالح" }
        require(contentSampleRate in 8_000..48_000) { "Content sample rate غير صالح" }
        require(featureChannels in setOf(256, 768, 1024)) { "Feature channels غير مدعومة" }
        require(contentInputRank == 2 || contentInputRank == 3) { "contentInputRank يجب أن يكون 2 أو 3" }
        require(contentOutputLayout == "BTC" || contentOutputLayout == "BCT") { "contentOutputLayout يجب أن يكون BTC أو BCT" }
        require(featureUpsample in 1..4) { "featureUpsample غير صالح" }
        require(pitchInputRank == 2 || pitchInputRank == 3) { "pitchInputRank يجب أن يكون 2 أو 3" }
        require(contentModel.isFile && contentModel.length() > 1024) { "content_encoder.onnx مفقود أو غير صالح" }
        require(pitchModel.isFile && pitchModel.length() > 1024) { "pitch.onnx مفقود أو غير صالح" }
        require(voiceModel.isFile && voiceModel.length() > 1024) { "voice.onnx مفقود أو غير صالح" }
    }

    companion object {
        fun fromDirectory(dir: File): VoiceModel {
            val metadata = File(dir, "metadata.json")
            require(metadata.isFile) { "metadata.json مفقود" }
            val json = JSONObject(metadata.readText(Charsets.UTF_8))
            val format = json.optString("format", "")
            require(format == "VSPVOICE") { "صيغة النموذج ليست VSPVOICE" }
            require(json.optInt("formatVersion", 0) == 1) { "إصدار حزمة الصوت غير مدعوم" }

            fun str(name: String, fallback: String, max: Int = 128): String =
                json.optString(name, fallback).ifBlank { fallback }.trim().take(max)

            return VoiceModel(
                id = str("id", dir.name),
                name = str("name", dir.name),
                author = str("author", "Unknown"),
                engine = str("engine", "rvc-onnx-v2"),
                sampleRate = json.optInt("sampleRate", 40_000),
                contentSampleRate = json.optInt("contentSampleRate", 16_000),
                featureChannels = json.optInt("featureChannels", if (str("engine", "rvc-onnx-v2").endsWith("v1")) 256 else 768),
                contentInput = str("contentInput", "audio"),
                contentOutput = str("contentOutput", "features"),
                contentInputRank = json.optInt("contentInputRank", 2),
                contentOutputLayout = str("contentOutputLayout", "BTC").uppercase(),
                featureUpsample = json.optInt("featureUpsample", 1).coerceIn(1, 4),
                pitchInput = str("pitchInput", "audio"),
                pitchOutput = str("pitchOutput", "f0"),
                pitchInputRank = json.optInt("pitchInputRank", 2),
                voicePhoneInput = str("voicePhoneInput", "phone"),
                voicePhoneLengthsInput = str("voicePhoneLengthsInput", "phone_lengths"),
                voicePitchInput = str("voicePitchInput", "pitch"),
                voicePitchFInput = str("voicePitchFInput", "pitchf"),
                voiceSpeakerInput = str("voiceSpeakerInput", "ds"),
                voiceNoiseInput = str("voiceNoiseInput", "rnd"),
                voiceOutput = str("voiceOutput", "audio"),
                speakerId = json.optLong("speakerId", 0L),
                authorized = json.optBoolean("authorized", false),
                licenseLabel = str("license", "Custom/Authorized", 256),
                directory = dir
            ).also { it.validateFiles() }
        }
    }
}

package com.mustafa.vocalstudio.voice

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

class VoiceModelManager(private val context: Context) {
    private val root = File(context.filesDir, "voice_models").apply { mkdirs() }

    fun listModels(): List<VoiceModel> = root.listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { runCatching { VoiceModel.fromDirectory(it) }.getOrNull() }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun importPack(uri: Uri): VoiceModel {
        val staging = File(root, ".import-${System.nanoTime()}").apply { mkdirs() }
        try {
            extractSecure(uri, staging)
            val metadata = File(staging, "metadata.json")
            require(metadata.isFile) { "الحزمة لا تحتوي metadata.json في جذرها" }
            require(metadata.length() in 2..1_048_576) { "metadata.json أكبر من الحد المسموح أو فارغ" }
            val parsed = VoiceModel.fromDirectory(staging)
            val safeId = sanitizeId(parsed.id.ifBlank { sha256(metadata).take(16) })
            val finalDir = File(root, safeId)
            val backup = File(root, ".backup-$safeId-${System.nanoTime()}")

            if (finalDir.exists()) {
                require(finalDir.renameTo(backup)) { "تعذر تجهيز تحديث النموذج الحالي" }
            }
            try {
                require(staging.renameTo(finalDir)) { "تعذر تثبيت النموذج في مساحة التطبيق" }
                backup.deleteRecursively()
            } catch (t: Throwable) {
                if (!finalDir.exists() && backup.exists()) backup.renameTo(finalDir)
                throw t
            }
            return VoiceModel.fromDirectory(finalDir)
        } catch (t: Throwable) {
            staging.deleteRecursively()
            throw t
        }
    }

    fun remove(model: VoiceModel) {
        if (model.directory.parentFile?.canonicalFile == root.canonicalFile) {
            model.directory.deleteRecursively()
        }
    }

    private fun extractSecure(uri: Uri, outDir: File) {
        val resolver = context.contentResolver
        val input = resolver.openInputStream(uri) ?: error("تعذر فتح ملف النموذج")
        val canonicalRoot = outDir.canonicalFile
        var total = 0L
        var entries = 0
        val maxTotal = 2_500_000_000L
        val maxEntry = 1_800_000_000L
        val maxEntries = 64

        ZipInputStream(BufferedInputStream(input, 128 * 1024)).use { zis ->
            val buffer = ByteArray(256 * 1024)
            while (true) {
                val entry = zis.nextEntry ?: break
                if (entry.isDirectory) {
                    zis.closeEntry()
                    continue
                }
                entries += 1
                require(entries <= maxEntries) { "حزمة النموذج تحتوي ملفات أكثر من الحد المسموح" }
                require(entry.name.isNotBlank() && entry.name.length <= 240) { "اسم ملف غير صالح داخل الحزمة" }
                val target = File(outDir, entry.name).canonicalFile
                require(target.path.startsWith(canonicalRoot.path + File.separator)) { "مسار ZIP غير آمن" }
                target.parentFile?.mkdirs()
                var entryBytes = 0L
                FileOutputStream(target).buffered(256 * 1024).use { out ->
                    while (true) {
                        val n = zis.read(buffer)
                        if (n <= 0) break
                        entryBytes += n
                        total += n
                        require(entryBytes <= maxEntry && total <= maxTotal) { "حزمة النموذج أكبر من الحد المسموح" }
                        out.write(buffer, 0, n)
                    }
                }
                zis.closeEntry()
            }
        }
    }

    private fun sanitizeId(value: String): String = value
        .lowercase()
        .replace(Regex("[^a-z0-9._-]+"), "-")
        .trim('-')
        .take(64)
        .ifBlank { "voice-${System.currentTimeMillis()}" }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}

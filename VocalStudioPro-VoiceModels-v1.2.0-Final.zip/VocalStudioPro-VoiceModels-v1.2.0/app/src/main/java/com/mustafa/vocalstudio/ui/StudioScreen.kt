package com.mustafa.vocalstudio.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.mustafa.vocalstudio.StudioViewModel
import com.mustafa.vocalstudio.voice.VoiceQuality
import java.io.File
import kotlin.math.roundToInt

private val NOTES = listOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")

@Composable
fun StudioScreen(vm: StudioViewModel) {
    val state = vm.uiState
    val context = LocalContext.current

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) vm.importAudio(uri) }

    val voiceModelLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.importVoiceModel(uri) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/wav")
    ) { uri -> if (uri != null) vm.exportTo(uri) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) vm.startRecording() }

    val startRecord: () -> Unit = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            vm.startRecording()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF070A12), Color(0xFF0C1020), Color(0xFF070A12))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Header(state.engineVersion)

            SourceCard(
                name = state.sourceName,
                waveform = state.sourceWaveform,
                recording = state.isRecording,
                playing = state.isPlayingSource,
                onRecord = if (state.isRecording) vm::stopRecording else startRecord,
                onImport = { importLauncher.launch("audio/*") },
                onPlay = vm::playSource
            )

            SectionCard(title = "Pitch Correction · Auto‑Tune") {
                Text("المقام", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NOTES.forEachIndexed { index, note ->
                        FilterChip(
                            selected = state.params.rootPitchClass == index,
                            onClick = { vm.setRoot(index) },
                            label = { Text(note) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(
                        selected = state.params.scaleMode == 0,
                        onClick = { vm.setScaleMode(0) },
                        label = { Text("Major") }
                    )
                    FilterChip(
                        selected = state.params.scaleMode == 1,
                        onClick = { vm.setScaleMode(1) },
                        label = { Text("Minor") }
                    )
                }

                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PresetButton("Natural", Modifier.weight(1f)) { vm.applyPreset("Natural") }
                    PresetButton("Modern", Modifier.weight(1f)) { vm.applyPreset("Modern") }
                }
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PresetButton("Studio", Modifier.weight(1f)) { vm.applyPreset("Studio") }
                    PresetButton("Hard Tune", Modifier.weight(1f)) { vm.applyPreset("Hard") }
                }

                ControlSlider(
                    "قوة التصحيح",
                    state.params.strength,
                    "${(state.params.strength * 100).roundToInt()}%",
                    0f..1f,
                    vm::setStrength
                )
                ControlSlider(
                    "Retune Speed",
                    state.params.retuneMs,
                    "${state.params.retuneMs.roundToInt()} ms",
                    2f..140f,
                    vm::setRetune
                )
                ControlSlider(
                    "Humanize",
                    state.params.humanize,
                    "${(state.params.humanize * 100).roundToInt()}%",
                    0f..1f,
                    vm::setHumanize
                )
            }

            SectionCard(title = "Voice Model · تحويل الخامة") {
                Text(
                    "استيراد نموذج ONNX مرخّص/مصرّح به وتطبيق خامته على تسجيلك محليًا",
                    color = Color(0xFF8F9BB5),
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(10.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            voiceModelLauncher.launch(
                                arrayOf("application/zip", "application/octet-stream", "*/*")
                            )
                        },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isBusy
                    ) { Text("إضافة .vspvoice") }
                    OutlinedButton(
                        onClick = vm::removeSelectedVoiceModel,
                        modifier = Modifier.weight(1f),
                        enabled = state.selectedVoice != null && !state.isBusy
                    ) { Text("حذف النموذج") }
                }

                if (state.voiceModels.isEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("لا توجد نماذج مثبتة", color = Color(0xFF9BA6C2), fontSize = 12.sp)
                } else {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.voiceModels.forEach { model ->
                            FilterChip(
                                selected = state.selectedVoiceId == model.id,
                                onClick = { vm.selectVoiceModel(model.id) },
                                label = { Text(model.name, maxLines = 1) }
                            )
                        }
                    }
                }

                state.selectedVoice?.let { model ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${model.name} · ${model.author} · ${model.sampleRate / 1000} kHz · ${model.licenseLabel}",
                        color = Color(0xFF4DE7B1),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(Modifier.height(8.dp))
                ToggleRow(
                    label = "تفعيل تحويل الخامة",
                    checked = state.voiceParams.enabled,
                    enabled = state.selectedVoice != null && !state.isBusy,
                    onChecked = vm::setVoiceEnabled
                )

                AnimatedVisibility(state.voiceParams.enabled && state.selectedVoice != null) {
                    Column {
                        ControlSlider(
                            "قوة النموذج · Voice Mix",
                            state.voiceParams.mix,
                            percent(state.voiceParams.mix),
                            0f..1f,
                            vm::setVoiceMix
                        )
                        ControlSlider(
                            "Pitch تعويض النموذج",
                            state.voiceParams.transposeSemitones,
                            "${if (state.voiceParams.transposeSemitones >= 0) "+" else ""}${String.format("%.1f", state.voiceParams.transposeSemitones)} st",
                            -24f..24f,
                            vm::setVoiceTranspose
                        )
                        ControlSlider(
                            "حماية الحروف والتنفس",
                            state.voiceParams.consonantProtect,
                            percent(state.voiceParams.consonantProtect),
                            0f..1f,
                            vm::setConsonantProtect
                        )

                        Text("جودة الاستدلال", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Spacer(Modifier.height(7.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = state.voiceParams.quality == VoiceQuality.FAST,
                                onClick = { vm.setVoiceQuality(VoiceQuality.FAST) },
                                label = { Text("Fast") }
                            )
                            FilterChip(
                                selected = state.voiceParams.quality == VoiceQuality.BALANCED,
                                onClick = { vm.setVoiceQuality(VoiceQuality.BALANCED) },
                                label = { Text("Balanced") }
                            )
                            FilterChip(
                                selected = state.voiceParams.quality == VoiceQuality.ULTRA,
                                onClick = { vm.setVoiceQuality(VoiceQuality.ULTRA) },
                                label = { Text("Ultra") }
                            )
                        }
                        ToggleRow(
                            label = "تسريع NNAPI مع رجوع تلقائي إلى CPU",
                            checked = state.voiceParams.preferNnapi,
                            enabled = !state.isBusy,
                            onChecked = vm::setPreferNnapi
                        )
                        if (state.isBusy && state.voiceProgress > 0f) {
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { state.voiceProgress.coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            SectionCard(title = "Studio Clean & Master") {
                Text(
                    "تنظيف طيفي متكيف + إزالة hum + ديناميكس متعددة النطاقات + True‑Peak",
                    color = Color(0xFF8F9BB5),
                    fontSize = 11.sp
                )
                ControlSlider("تنظيف الضوضاء الطيفي", state.params.noiseReduction, percent(state.params.noiseReduction), 0f..1f, vm::setNoise)
                ControlSlider("وضوح الصوت · Clarity", state.params.clarity, percent(state.params.clarity), 0f..1f, vm::setClarity)
                ControlSlider("دفء الصوت · Warmth", state.params.warmth, percent(state.params.warmth), 0f..1f, vm::setWarmth)
                ControlSlider("Air / High Detail", state.params.air, percent(state.params.air), 0f..1f, vm::setAir)
                ControlSlider("De‑Esser", state.params.deEsser, percent(state.params.deEsser), 0f..1f, vm::setDeEsser)
                ControlSlider("Multiband Compression", state.params.compression, percent(state.params.compression), 0f..1f, vm::setCompression)
                ControlSlider("Vocal Leveling", state.params.leveling, percent(state.params.leveling), 0f..1f, vm::setLeveling)
                ControlSlider("Studio Plate", state.params.reverb, percent(state.params.reverb), 0f..0.40f, vm::setReverb)
            }

            Button(
                onClick = vm::process,
                enabled = state.sourceFile != null && !state.isBusy && !state.isRecording,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                if (state.isBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                    Spacer(Modifier.width(10.dp))
                }
                Text("Studio Enhance · معالجة احترافية", fontWeight = FontWeight.Black, fontSize = 16.sp)
            }

            AnimatedVisibility(state.processedFile != null) {
                ResultCard(
                    file = state.processedFile,
                    waveform = state.processedWaveform,
                    playing = state.isPlayingProcessed,
                    onPlay = vm::playProcessed,
                    onExport = { exportLauncher.launch(vm.suggestedExportName()) }
                )
            }

            StatusCard(state.status, state.isBusy)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun Header(engine: String) {
    Column {
        Text(
            "VOCAL STUDIO PRO",
            fontSize = 25.sp,
            fontWeight = FontWeight.Black,
            color = Color.White
        )
        Text(
            "Native Auto‑Tune • $engine",
            color = Color(0xFF9BA6C2),
            fontSize = 12.sp
        )
    }
}

@Composable
private fun SourceCard(
    name: String,
    waveform: List<Float>,
    recording: Boolean,
    playing: Boolean,
    onRecord: () -> Unit,
    onImport: () -> Unit,
    onPlay: () -> Unit
) {
    SectionCard(title = "الصوت الخام") {
        Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Spacer(Modifier.height(12.dp))
        Waveform(waveform, recording)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onRecord,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (recording) Color(0xFFFF5B6E) else Color(0xFF252D43)
                )
            ) {
                Text(if (recording) "إيقاف" else "تسجيل")
            }
            OutlinedButton(onClick = onImport, modifier = Modifier.weight(1f)) { Text("اختيار ملف") }
            OutlinedButton(onClick = onPlay, modifier = Modifier.weight(1f), enabled = waveform.isNotEmpty()) {
                Text(if (playing) "إيقاف" else "استماع")
            }
        }
    }
}

@Composable
private fun ResultCard(
    file: File?,
    waveform: List<Float>,
    playing: Boolean,
    onPlay: () -> Unit,
    onExport: () -> Unit
) {
    SectionCard(title = "Studio Master") {
        Text("WAV • PCM 24-bit • 48 kHz", color = Color(0xFF4DE7B1), fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Waveform(waveform, false)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onPlay, modifier = Modifier.weight(1f)) {
                Text(if (playing) "إيقاف المعاينة" else "استماع للنتيجة")
            }
            Button(onClick = onExport, modifier = Modifier.weight(1f), enabled = file != null) {
                Text("تنزيل WAV", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xE6121725)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x332FD4E8))
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}


@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    enabled: Boolean,
    onChecked: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked, enabled = enabled)
    }
}

@Composable
private fun PresetButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier) { Text(text, fontSize = 12.sp) }
}

@Composable
private fun ControlSlider(
    label: String,
    value: Float,
    valueText: String,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(valueText, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
    Slider(value = value, onValueChange = onChange, valueRange = range)
}

@Composable
private fun Waveform(peaks: List<Float>, recording: Boolean) {
    val pulse by animateFloatAsState(if (recording) 1f else 0.72f, label = "recordingWave")
    Box(
        Modifier
            .fillMaxWidth()
            .height(86.dp)
            .background(Color(0xFF090D18), RoundedCornerShape(16.dp))
            .padding(horizontal = 10.dp, vertical = 12.dp)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val values = if (peaks.isEmpty()) List(64) { i -> 0.08f + ((i * 17) % 11) / 55f } else peaks
            val step = size.width / values.size.coerceAtLeast(1)
            values.forEachIndexed { i, p ->
                val h = size.height * p.coerceIn(0.04f, 1f) * pulse
                val x = step * i + step / 2
                drawLine(
                    brush = Brush.verticalGradient(listOf(Color(0xFF8B5CF6), Color(0xFF22D3EE))),
                    start = Offset(x, size.height / 2 - h / 2),
                    end = Offset(x, size.height / 2 + h / 2),
                    strokeWidth = (step * 0.42f).coerceAtLeast(2f),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
private fun StatusCard(status: String, busy: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F1421), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(9.dp)
                .background(if (busy) Color(0xFFFFB86B) else Color(0xFF4DE7B1), CircleShape)
        )
        Spacer(Modifier.width(10.dp))
        Text(status, color = Color(0xFFC8D0E5), fontSize = 12.sp, modifier = Modifier.weight(1f))
    }
}

private fun percent(v: Float) = "${(v * 100).roundToInt()}%"

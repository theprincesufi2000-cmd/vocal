package com.mustafa.vocalstudio.dsp

object NativeDsp {
    init { System.loadLibrary("vocal_dsp") }

    @JvmStatic external fun processWav(
        inputPath: String,
        outputPath: String,
        rootPitchClass: Int,
        scaleMode: Int,
        strength: Float,
        retuneMs: Float,
        humanize: Float,
        noiseReduction: Float,
        clarity: Float,
        warmth: Float,
        air: Float,
        deEsser: Float,
        compression: Float,
        leveling: Float,
        reverb: Float
    ): Int

    @JvmStatic external fun prepareForVoiceModel(
        inputPath: String,
        outputPath: String,
        rootPitchClass: Int,
        scaleMode: Int,
        strength: Float,
        retuneMs: Float,
        humanize: Float,
        noiseReduction: Float
    ): Int

    @JvmStatic external fun masterOnly(
        inputPath: String,
        outputPath: String,
        clarity: Float,
        warmth: Float,
        air: Float,
        deEsser: Float,
        compression: Float,
        leveling: Float,
        reverb: Float
    ): Int

    @JvmStatic external fun engineVersion(): String
}

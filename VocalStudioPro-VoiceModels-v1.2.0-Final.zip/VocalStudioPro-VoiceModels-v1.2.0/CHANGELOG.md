# Changelog

## 1.2.0
- Added local `.vspvoice` model manager with secure ZIP extraction and path traversal protection.
- Added ONNX Runtime Android 1.29.0 inference engine.
- Added 3-stage authorized voice conversion: content features + F0 + RVC-style synthesizer.
- Added overlapped chunk processing with crossfades for long recordings.
- Added Voice Mix, ±24 semitone compensation, consonant/breath protection, Fast/Balanced/Ultra quality, and NNAPI→CPU fallback.
- Split native DSP into Clean+Auto-Tune pre-model and Studio Master post-model stages.
- Added direct-buffer ONNX tensor feeds and graph optimization.
- Added `.vspvoice` packaging tool and format documentation.
- Bumped versionCode to 4 / versionName to 1.2.0.

## 1.1.1
- Fixed AndroidX Lifecycle dependency to 2.11.0.
- Pinned build Gradle to 9.6.0.
- Improved recording stop reliability and WAV preview/downmix handling.

## 1.1.0
- Added spectral denoise, hum removal, multiband dynamics, vocal leveling and studio master.

# Vocal Studio Pro 1.1.1 — Verification

Date: 2026-09-05

## Build configuration audited

- Android Gradle Plugin: 9.4.0
- Gradle: pinned to 9.6.0
- JDK: 17
- compileSdk / targetSdk: 37
- Android SDK package used by CI: platforms;android-37.0
- Build Tools: 36.0.0
- NDK: 28.2.13676358
- CMake: 3.22.1
- Compose BOM: 2026.08.00
- Activity Compose: 1.13.0
- Core: 1.19.0
- Lifecycle ViewModel Compose / Runtime Compose: 2.11.0
- Compose compiler plugin: 2.3.21

The invalid Lifecycle 2.12.0 dependency from 1.1.0 was removed.

## Native validation performed

All C++ DSP and JNI translation units were compiled with:

```text
-std=c++17 -O2 -Wall -Wextra -Werror
```

Result: PASS.

Validated source files include WavIO, YIN pitch detection, scale quantizer,
phase vocoder, spectral denoiser, master DSP, VocalEngine, and JNI bridge.

## Functional DSP tests performed

1. Synthetic vocal-like WAV at 48 kHz containing hiss + 50 Hz mains hum.
2. C-major pitch-correction test with an input fundamental around 285 Hz.
3. Output fundamental estimated around 293 Hz, moving toward D4 as expected.
4. Output format verified as mono PCM WAV, 48 kHz, 24-bit.
5. Output duration matched the input duration.
6. Stereo 44.1 kHz input was processed and resampled to mono 48 kHz while
   preserving duration.

## Kotlin validation performed

The modified Android audio layer was compiled against API-compatible local
stubs with the Kotlin compiler to catch syntax, nullable, and type errors in:

- AudioRecorder.kt
- AudioDecoder.kt
- WavPlayer.kt
- WavUtils.kt

StudioViewModel.kt was also independently compiled against local API stubs.

Result: PASS.

## Reliability fixes

- Gradle launcher no longer silently uses a different system Gradle version.
- `ndk.dir` is not generated; `android.ndkVersion` selects the NDK.
- AudioRecord blocking reads are stopped before joining the recording thread.
- Platform AGC / NoiseSuppressor / AEC handles are retained and released.
- The exact recording file is tracked instead of searching for the newest file.
- Multichannel WAV preview is safely downmixed when necessary.
- MediaCodec / MediaExtractor resources are released on decoder errors.
- No TODO/FIXME/placeholder code remains under `app/src`.

## CI

The included GitHub workflow uses Node-24-compatible action majors and installs
Android 17 / API 37.0, Build Tools 36.0.0, NDK r28c and CMake 3.22.1 before
building Debug and Release APKs.

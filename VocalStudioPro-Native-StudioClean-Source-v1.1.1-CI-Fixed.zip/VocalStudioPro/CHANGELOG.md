# Changelog

## 1.1.1 — Build & Reliability Fix

- Replaced invalid Lifecycle `2.12.0` dependencies with stable `2.11.0`.
- Pinned Gradle execution to exactly `9.6.0`; project scripts no longer silently use a newer system Gradle.
- Updated GitHub Actions to Node 24 based action majors (`checkout@v6`, `setup-java@v5`, `setup-android@v4`, `upload-artifact@v7`).
- GitHub build installs Android platform `37.0`, Build Tools `36.0.0`, NDK `28.2.13676358`, and CMake `3.22.1`.
- Removed deprecated `ndk.dir` generation; `android.ndkVersion` is the single NDK selector.
- Improved recorder shutdown so blocking `AudioRecord.read()` is released safely.
- Kept platform audio-effect handles alive while recording and release them deterministically.
- Removed native warnings found by strict `-Wall -Wextra -Werror` host compilation.
- Bumped application version to 1.1.1 / versionCode 3.

## 1.1.0 — Studio Clean

- Replaced gate-only cleanup with offline STFT/Wiener spectral denoising.
- Added automatic 50/60 Hz mains-family detection and harmonic notch removal.
- Added soft post-denoise downward expansion.
- Added Vocal Leveling.
- Added three-band vocal compression.
- Added split-band De-Esser.
- Added independent Clarity, Warmth and Air controls.
- Added parallel plate reverb pre-delay.
- Added cubic 4x inter-sample peak estimation and lookahead true-peak limiting.
- Added Studio preset.
- Updated JNI/Kotlin parameter pipeline and UI controls.
- Bumped application version to 1.1.0 / versionCode 2.

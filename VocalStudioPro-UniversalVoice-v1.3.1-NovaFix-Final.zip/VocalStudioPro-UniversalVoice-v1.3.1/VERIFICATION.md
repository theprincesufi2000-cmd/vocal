# Vocal Studio Pro 1.3.1 — Verification

Verified locally before packaging:

- XML parsing: OK
- GitHub Actions YAML parsing: OK
- Native C++17 + JNI compile with `-Wall -Wextra -Werror`: OK
- Kotlin compile-check for VoiceModel / OnnxModelProbe / VoiceModelManager / VoiceConversionEngine / StudioViewModel: OK
- Compose screen compile-check with test stubs: OK
- Standalone ONNX fallback import path: present and compile-checked
- Shared `@core/content_encoder.onnx` path support: present and compile-checked
- Optional RVC v2 ContentVec core downloader: present with redirect handling, size limits and ONNX validation
- Android INTERNET permission: present only for optional core download
- versionCode: 6
- versionName: 1.3.1
- compileSdk / targetSdk: 37 / 37
- NDK: 28.2.13676358
- CMake: 3.22.1
- ONNX Runtime Android: 1.29.0
- Gradle bootstrap: 9.6.0

Important runtime behavior:

- A standalone file such as `Nova_HD.onnx` is no longer rejected solely because its filename does not contain `voice`, `rvc`, `synth`, or `generator`.
- If the compatible RVC v2 ContentVec core is missing, the voice is installed as `MISSING_CORE` and the UI exposes a one-tap core download.
- The shared core is stored once and referenced by compatible models; it is not duplicated into each voice model directory.
- Output sample rate is estimated from the first synthesized chunk to avoid forcing an incorrect 40 kHz fallback on ONNX models whose filename does not reveal 32/40/48 kHz.

A full Android `assembleRelease` was not executed in this container because it does not have the full Android SDK/Maven environment. The included GitHub Actions workflow performs the real Android build.

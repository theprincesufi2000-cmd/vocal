package com.mustafa.vocalstudio.voice

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.File

internal object OnnxModelProbe {
    enum class Kind { VOICE, CONTENT, PITCH, UNKNOWN }

    data class Probe(
        val file: File,
        val kind: Kind,
        val inputs: List<String>,
        val outputs: List<String>,
        val inputRank: Int,
        val outputRank: Int,
        val featureChannels: Int?,
        val contentLayout: String?,
        val directF0: Boolean
    )

    private val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }

    fun inspect(file: File): Probe {
        val fileName = file.name.lowercase()
        OrtSession.SessionOptions().use { options ->
            options.setInterOpNumThreads(1)
            options.setIntraOpNumThreads(1)
            return env.createSession(file.absolutePath, options).use { session ->
                val inputs = session.inputNames.toList()
                val outputs = session.outputNames.toList()
                val lowerInputs = inputs.map { it.lowercase() }
                val lowerOutputs = outputs.map { it.lowercase() }

                val firstInput = inputs.firstOrNull()
                val firstOutput = outputs.firstOrNull()
                val firstInputInfo = firstInput?.let { session.inputInfo[it]?.info as? TensorInfo }
                val firstOutputInfo = firstOutput?.let { session.outputInfo[it]?.info as? TensorInfo }
                val firstInputShape = firstInputInfo?.shape ?: longArrayOf()
                val firstOutputShape = firstOutputInfo?.shape ?: longArrayOf()

                val phoneName = findName(inputs, "phone", "phones", "features", "feats")
                val hasRvcSignature = lowerInputs.any { it == "phone" || it.contains("phone") } &&
                    lowerInputs.any { it.contains("pitch") } &&
                    lowerInputs.any { it == "ds" || it.contains("speaker") || it.contains("sid") } &&
                    lowerInputs.any { it == "rnd" || it.contains("noise") }

                // Direct-F0 models should return one scalar Hz value per time frame. Raw RMVPE
                // salience exports commonly end in 360 bins and need a decoder, so they are not
                // treated as a direct pitch model here; Native F0 is used instead.
                val looksLikePitchByName = fileName.contains("pitch") || fileName.contains("f0") || fileName.contains("rmvpe")
                val outputLooksLikeF0 = lowerOutputs.any { it == "f0" || it.contains("pitch") || it.contains("frequency") }
                val salienceBins = firstOutputShape.lastOrNull()?.takeIf { it > 0 }
                val isRmvpeSalience = looksLikePitchByName && salienceBins == 360L
                val directF0 = !isRmvpeSalience && (outputLooksLikeF0 || looksLikePitchByName) &&
                    (firstOutputShape.size <= 2 || salienceBins == null || salienceBins <= 8L)

                val kind = when {
                    hasRvcSignature -> Kind.VOICE
                    directF0 -> Kind.PITCH
                    fileName.contains("hubert") || fileName.contains("content") || fileName.contains("vec") ||
                        fileName.contains("encoder") || fileName.contains("embed") -> Kind.CONTENT
                    // A single-input/single-output model is usually a content encoder only if it
                    // did not look like RMVPE salience above.
                    !isRmvpeSalience && inputs.size == 1 && outputs.size >= 1 -> Kind.CONTENT
                    else -> Kind.UNKNOWN
                }

                var channels: Int? = null
                var layout: String? = null
                var primaryInputShape = firstInputShape
                var primaryOutputShape = firstOutputShape

                if (kind == Kind.VOICE && phoneName != null) {
                    val info = session.inputInfo[phoneName]?.info as? TensorInfo
                    val shape = info?.shape ?: longArrayOf()
                    primaryInputShape = shape
                    channels = shape.lastOrNull()?.takeIf { it in setOf(256L, 768L, 1024L) }?.toInt()
                }

                if (kind == Kind.CONTENT) {
                    val shape = firstOutputShape
                    primaryOutputShape = shape
                    if (shape.size >= 2) {
                        val a = shape.getOrNull(shape.size - 2) ?: -1
                        val b = shape.getOrNull(shape.size - 1) ?: -1
                        when {
                            b in setOf(256L, 768L, 1024L) -> {
                                channels = b.toInt()
                                layout = "BTC"
                            }
                            a in setOf(256L, 768L, 1024L) -> {
                                channels = a.toInt()
                                layout = "BCT"
                            }
                        }
                    }
                }

                Probe(
                    file = file,
                    kind = kind,
                    inputs = inputs,
                    outputs = outputs,
                    inputRank = primaryInputShape.size.coerceAtLeast(2),
                    outputRank = primaryOutputShape.size,
                    featureChannels = channels,
                    contentLayout = layout,
                    directF0 = directF0
                )
            }
        }
    }

    fun guess(file: File): Probe {
        val n = file.name.lowercase()
        val kind = when {
            n.contains("voice") || n.contains("rvc") || n.contains("synth") || n.contains("generator") -> Kind.VOICE
            n.contains("pitch") || n.contains("f0") -> Kind.PITCH
            n.contains("hubert") || n.contains("content") || n.contains("vec") || n.contains("encoder") -> Kind.CONTENT
            else -> Kind.UNKNOWN
        }
        return Probe(
            file = file,
            kind = kind,
            inputs = emptyList(),
            outputs = emptyList(),
            inputRank = 2,
            outputRank = 0,
            featureChannels = null,
            contentLayout = null,
            directF0 = kind == Kind.PITCH
        )
    }

    fun findName(names: Collection<String>, vararg aliases: String): String? {
        val lower = names.associateBy { it.lowercase() }
        aliases.forEach { alias -> lower[alias.lowercase()]?.let { return it } }
        aliases.forEach { alias ->
            names.firstOrNull { it.lowercase().contains(alias.lowercase()) }?.let { return it }
        }
        return null
    }
}

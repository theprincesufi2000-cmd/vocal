package com.mustafa.vocalstudio

import android.app.Application
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.mustafa.vocalstudio.audio.AudioDecoder
import com.mustafa.vocalstudio.audio.AudioRecorder
import com.mustafa.vocalstudio.audio.WavPlayer
import com.mustafa.vocalstudio.dsp.NativeDsp
import com.mustafa.vocalstudio.dsp.ProcessingParams
import com.mustafa.vocalstudio.util.WavUtils
import com.mustafa.vocalstudio.voice.VoiceConversionEngine
import com.mustafa.vocalstudio.voice.VoiceConversionParams
import com.mustafa.vocalstudio.voice.VoiceModel
import com.mustafa.vocalstudio.voice.VoiceModelManager
import com.mustafa.vocalstudio.voice.VoiceModelState
import com.mustafa.vocalstudio.voice.VoiceQuality
import java.io.File
import java.util.concurrent.Executors


data class StudioUiState(
    val sourceFile: File? = null,
    val sourceName: String = "لا يوجد تسجيل",
    val processedFile: File? = null,
    val sourceWaveform: List<Float> = emptyList(),
    val processedWaveform: List<Float> = emptyList(),
    val params: ProcessingParams = ProcessingParams(),
    val voiceParams: VoiceConversionParams = VoiceConversionParams(),
    val voiceModels: List<VoiceModel> = emptyList(),
    val selectedVoiceId: String? = null,
    val voiceProgress: Float = 0f,
    val coreProgress: Float = 0f,
    val modelRightsConfirmed: Boolean = false,
    val isRecording: Boolean = false,
    val isBusy: Boolean = false,
    val isPlayingSource: Boolean = false,
    val isPlayingProcessed: Boolean = false,
    val status: String = "جاهز",
    val engineVersion: String = "Native DSP"
) {
    val selectedVoice: VoiceModel?
        get() = voiceModels.firstOrNull { it.id == selectedVoiceId }
}

class StudioViewModel(app: Application) : AndroidViewModel(app) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val recorder = AudioRecorder(app)
    private val player = WavPlayer()
    private val voiceManager = VoiceModelManager(app)
    private val voiceEngine = VoiceConversionEngine()
    private var recordingFile: File? = null

    var uiState by mutableStateOf(
        StudioUiState(
            engineVersion = runCatching { NativeDsp.engineVersion() }.getOrDefault("Native DSP"),
            voiceModels = voiceManager.listModels()
        )
    )
        private set

    fun setRoot(root: Int) = updateParams { copy(rootPitchClass = root.coerceIn(0, 11)) }
    fun setScaleMode(mode: Int) = updateParams { copy(scaleMode = mode.coerceIn(0, 1)) }
    fun setStrength(value: Float) = updateParams { copy(strength = value.coerceIn(0f, 1f)) }
    fun setRetune(value: Float) = updateParams { copy(retuneMs = value.coerceIn(2f, 140f)) }
    fun setHumanize(value: Float) = updateParams { copy(humanize = value.coerceIn(0f, 1f)) }
    fun setNoise(value: Float) = updateParams { copy(noiseReduction = value.coerceIn(0f, 1f)) }
    fun setClarity(value: Float) = updateParams { copy(clarity = value.coerceIn(0f, 1f)) }
    fun setWarmth(value: Float) = updateParams { copy(warmth = value.coerceIn(0f, 1f)) }
    fun setAir(value: Float) = updateParams { copy(air = value.coerceIn(0f, 1f)) }
    fun setDeEsser(value: Float) = updateParams { copy(deEsser = value.coerceIn(0f, 1f)) }
    fun setCompression(value: Float) = updateParams { copy(compression = value.coerceIn(0f, 1f)) }
    fun setLeveling(value: Float) = updateParams { copy(leveling = value.coerceIn(0f, 1f)) }
    fun setReverb(value: Float) = updateParams { copy(reverb = value.coerceIn(0f, 0.45f)) }

    fun setVoiceEnabled(enabled: Boolean) = updateVoiceParams {
        copy(enabled = enabled && uiState.selectedVoice?.isReady == true)
    }

    fun setModelRightsConfirmed(value: Boolean) {
        uiState = uiState.copy(modelRightsConfirmed = value)
    }
    fun setVoiceMix(value: Float) = updateVoiceParams { copy(mix = value.coerceIn(0f, 1f)) }
    fun setVoiceTranspose(value: Float) = updateVoiceParams { copy(transposeSemitones = value.coerceIn(-24f, 24f)) }
    fun setConsonantProtect(value: Float) = updateVoiceParams { copy(consonantProtect = value.coerceIn(0f, 1f)) }
    fun setVoiceQuality(value: VoiceQuality) = updateVoiceParams { copy(quality = value) }
    fun setPreferNnapi(value: Boolean) = updateVoiceParams { copy(preferNnapi = value) }

    fun selectVoiceModel(id: String?) {
        val model = id?.let { target -> uiState.voiceModels.firstOrNull { it.id == target } }
        uiState = uiState.copy(
            selectedVoiceId = model?.id,
            voiceParams = uiState.voiceParams.copy(enabled = model?.isReady == true && uiState.voiceParams.enabled),
            status = when {
                model == null -> "تم إلغاء اختيار النموذج"
                model.isReady -> "تم اختيار ${model.name} · جاهز"
                else -> "${model.name} · ${model.stateLabel()}: ${model.statusDetail}"
            }
        )
    }

    fun importVoiceModel(uri: Uri) {
        if (uiState.isBusy || uiState.isRecording) return
        if (!uiState.modelRightsConfirmed) {
            uiState = uiState.copy(status = "أكد حق استخدام النموذج قبل الاستيراد")
            return
        }
        uiState = uiState.copy(isBusy = true, status = "جاري اكتشاف نوع النموذج وفك الحزمة…")
        executor.execute {
            try {
                val result = voiceManager.importAny(uri, uiState.modelRightsConfirmed)
                val models = voiceManager.listModels()
                main.post {
                    val model = result.model
                    uiState = uiState.copy(
                        voiceModels = models,
                        selectedVoiceId = model?.id ?: uiState.selectedVoiceId,
                        voiceParams = uiState.voiceParams.copy(enabled = model?.isReady == true),
                        isBusy = false,
                        status = result.message
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(isBusy = false, status = "فشل استيراد النموذج: ${t.message}")
                }
            }
        }
    }

    fun downloadRvcV2Core() {
        val selected = uiState.selectedVoice ?: return
        if (uiState.isBusy || uiState.isRecording) return
        if (selected.state != VoiceModelState.MISSING_CORE || selected.featureChannels != 768) {
            uiState = uiState.copy(status = "هذا النموذج لا يحتاج RVC v2 Core أو يحتاج Core مختلف")
            return
        }
        uiState = uiState.copy(isBusy = true, coreProgress = 0f, status = "جاري تنزيل RVC v2 Core…")
        executor.execute {
            try {
                val message = voiceManager.downloadSharedRvcV2Core { progress ->
                    main.post {
                        if (uiState.isBusy) uiState = uiState.copy(
                            coreProgress = progress.coerceIn(0f, 1f),
                            status = "تنزيل RVC Core ${(progress * 100).toInt().coerceIn(0, 100)}%"
                        )
                    }
                }
                val models = voiceManager.listModels()
                main.post {
                    val selectedId = uiState.selectedVoiceId
                    val refreshed = models.firstOrNull { it.id == selectedId }
                    uiState = uiState.copy(
                        voiceModels = models,
                        selectedVoiceId = refreshed?.id ?: selectedId,
                        voiceParams = uiState.voiceParams.copy(enabled = refreshed?.isReady == true),
                        coreProgress = 1f,
                        isBusy = false,
                        status = message
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(
                        isBusy = false,
                        coreProgress = 0f,
                        status = "فشل تنزيل RVC Core: ${t.message}"
                    )
                }
            }
        }
    }

    fun removeSelectedVoiceModel() {
        val model = uiState.selectedVoice ?: return
        if (uiState.isBusy) return
        runCatching { voiceManager.remove(model) }
        uiState = uiState.copy(
            voiceModels = voiceManager.listModels(),
            selectedVoiceId = null,
            voiceParams = uiState.voiceParams.copy(enabled = false),
            status = "تم حذف النموذج الصوتي"
        )
    }

    fun applyPreset(name: String) {
        val current = uiState.params
        val p = when (name) {
            "Natural" -> current.copy(
                strength = 0.78f, retuneMs = 72f, humanize = 0.72f,
                noiseReduction = 0.48f, clarity = 0.46f, warmth = 0.42f, air = 0.38f,
                deEsser = 0.38f, compression = 0.46f, leveling = 0.52f, reverb = 0.11f
            )
            "Hard" -> current.copy(
                strength = 1.0f, retuneMs = 5f, humanize = 0f,
                noiseReduction = 0.66f, clarity = 0.72f, warmth = 0.26f, air = 0.58f,
                deEsser = 0.62f, compression = 0.78f, leveling = 0.80f, reverb = 0.16f
            )
            "Studio" -> current.copy(
                strength = 0.92f, retuneMs = 24f, humanize = 0.34f,
                noiseReduction = 0.72f, clarity = 0.78f, warmth = 0.38f, air = 0.62f,
                deEsser = 0.60f, compression = 0.72f, leveling = 0.82f, reverb = 0.12f
            )
            else -> current.copy(
                strength = 0.95f, retuneMs = 20f, humanize = 0.25f,
                noiseReduction = 0.62f, clarity = 0.66f, warmth = 0.34f, air = 0.52f,
                deEsser = 0.52f, compression = 0.68f, leveling = 0.72f, reverb = 0.14f
            )
        }
        uiState = uiState.copy(params = p, status = "تم تطبيق إعداد $name")
    }

    fun startRecording() {
        if (uiState.isBusy || uiState.isRecording) return
        val dir = getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            ?: getApplication<Application>().filesDir
        val file = File(dir, "raw_vocal_${System.currentTimeMillis()}.wav")
        runCatching {
            player.stop()
            recordingFile = file
            recorder.start(file)
            uiState = uiState.copy(
                isRecording = true,
                status = "جاري التسجيل الخام 48 kHz…",
                processedFile = null,
                processedWaveform = emptyList()
            )
        }.onFailure {
            recordingFile = null
            uiState = uiState.copy(status = "فشل بدء التسجيل: ${it.message}")
        }
    }

    fun stopRecording() {
        if (!uiState.isRecording) return
        val file = recordingFile
        recorder.stop()
        recordingFile = null
        if (file != null && file.exists() && file.length() > 44) setSource(file, "تسجيل جديد")
        else uiState = uiState.copy(isRecording = false, status = "لم يتم إنشاء تسجيل صالح")
    }

    fun importAudio(uri: Uri) {
        if (uiState.isBusy || uiState.isRecording) return
        val app = getApplication<Application>()
        val displayName = queryName(uri) ?: "ملف صوت"
        uiState = uiState.copy(isBusy = true, status = "جاري فك الصوت وتحضيره…")
        executor.execute {
            try {
                val out = File(app.cacheDir, "import_${System.currentTimeMillis()}.wav")
                AudioDecoder.toWav(app, uri, out)
                val peaks = WavUtils.waveform(out)
                main.post {
                    player.stop()
                    uiState = uiState.copy(
                        sourceFile = out, sourceName = displayName, processedFile = null,
                        sourceWaveform = peaks, processedWaveform = emptyList(),
                        isBusy = false, status = "تم تجهيز الصوت للمعالجة"
                    )
                }
            } catch (t: Throwable) {
                main.post { uiState = uiState.copy(isBusy = false, status = "فشل استيراد الصوت: ${t.message}") }
            }
        }
    }

    fun process() {
        val input = uiState.sourceFile ?: run {
            uiState = uiState.copy(status = "سجّل أو اختر ملفًا صوتيًا أولًا")
            return
        }
        if (uiState.isBusy || uiState.isRecording) return
        val app = getApplication<Application>()
        val dir = app.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: app.filesDir
        val output = File(dir, "studio_master_${System.currentTimeMillis()}.wav")
        val p = uiState.params
        val vp = uiState.voiceParams
        val voice = uiState.selectedVoice

        if (vp.enabled && voice == null) {
            uiState = uiState.copy(status = "اختر نموذجًا صوتيًا أولًا")
            return
        }
        if (vp.enabled && voice?.isReady != true) {
            uiState = uiState.copy(status = voice?.statusDetail ?: "النموذج غير جاهز للتشغيل")
            return
        }

        player.stop()
        uiState = uiState.copy(
            isBusy = true,
            voiceProgress = 0f,
            isPlayingSource = false,
            isPlayingProcessed = false,
            status = if (vp.enabled) "Clean + Auto‑Tune → Voice Model → Studio Master…"
            else "تنظيف طيفي → Auto‑Tune → Studio Master…"
        )

        executor.execute {
            val pretuned = File(app.cacheDir, "pretuned_${System.nanoTime()}.wav")
            val converted = File(app.cacheDir, "converted_${System.nanoTime()}.wav")
            try {
                if (vp.enabled && voice != null) {
                    val prepCode = NativeDsp.prepareForVoiceModel(
                        input.absolutePath, pretuned.absolutePath,
                        p.rootPitchClass, p.scaleMode, p.strength, p.retuneMs, p.humanize, p.noiseReduction
                    )
                    if (prepCode != 0 || !pretuned.isFile || pretuned.length() <= 44) {
                        error("Native pre-processing error $prepCode")
                    }

                    main.post { uiState = uiState.copy(status = "جاري تحويل الخامة الصوتية: ${voice.name}…") }
                    val stats = voiceEngine.convert(pretuned, converted, voice, vp) { progress ->
                        main.post {
                            if (uiState.isBusy) uiState = uiState.copy(
                                voiceProgress = progress,
                                status = "Voice Conversion ${(progress * 100).toInt().coerceIn(0, 100)}% · ${voice.name}"
                            )
                        }
                    }
                    if (!converted.isFile || converted.length() <= 44) error("Voice model produced no audio")

                    val masterCode = NativeDsp.masterOnly(
                        converted.absolutePath, output.absolutePath,
                        p.clarity, p.warmth, p.air, p.deEsser, p.compression, p.leveling, p.reverb
                    )
                    if (masterCode != 0) error("Native master error $masterCode")

                    val peaks = WavUtils.waveform(output)
                    main.post {
                        uiState = uiState.copy(
                            processedFile = output,
                            processedWaveform = peaks,
                            isBusy = false,
                            voiceProgress = 1f,
                            status = "اكتمل التحويل والماستر · ${stats.provider} · WAV 24-bit/48 kHz"
                        )
                    }
                } else {
                    val code = NativeDsp.processWav(
                        input.absolutePath, output.absolutePath,
                        p.rootPitchClass, p.scaleMode, p.strength, p.retuneMs, p.humanize,
                        p.noiseReduction, p.clarity, p.warmth, p.air, p.deEsser,
                        p.compression, p.leveling, p.reverb
                    )
                    if (code != 0 || !output.exists() || output.length() <= 44) error("Native DSP error $code")
                    val peaks = WavUtils.waveform(output)
                    main.post {
                        uiState = uiState.copy(
                            processedFile = output, processedWaveform = peaks,
                            isBusy = false, voiceProgress = 0f,
                            status = "اكتملت المعالجة — WAV 24-bit / 48 kHz"
                        )
                    }
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(isBusy = false, voiceProgress = 0f, status = "فشلت المعالجة: ${t.message}")
                }
            } finally {
                pretuned.delete()
                converted.delete()
            }
        }
    }

    fun playSource() {
        val file = uiState.sourceFile ?: return
        if (uiState.isPlayingSource) {
            player.stop(); uiState = uiState.copy(isPlayingSource = false); return
        }
        player.stop()
        uiState = uiState.copy(isPlayingSource = true, isPlayingProcessed = false)
        player.play(file) { main.post { uiState = uiState.copy(isPlayingSource = false) } }
    }

    fun playProcessed() {
        val file = uiState.processedFile ?: return
        if (uiState.isPlayingProcessed) {
            player.stop(); uiState = uiState.copy(isPlayingProcessed = false); return
        }
        player.stop()
        uiState = uiState.copy(isPlayingProcessed = true, isPlayingSource = false)
        player.play(file) { main.post { uiState = uiState.copy(isPlayingProcessed = false) } }
    }

    fun exportTo(uri: Uri) {
        val source = uiState.processedFile ?: return
        uiState = uiState.copy(isBusy = true, status = "جاري حفظ WAV…")
        executor.execute {
            try {
                getApplication<Application>().contentResolver.openOutputStream(uri, "w").use { out ->
                    requireNotNull(out) { "Cannot open export destination" }
                    source.inputStream().use { it.copyTo(out, 256 * 1024) }
                }
                main.post { uiState = uiState.copy(isBusy = false, status = "تم حفظ ملف WAV بنجاح") }
            } catch (t: Throwable) {
                main.post { uiState = uiState.copy(isBusy = false, status = "فشل الحفظ: ${t.message}") }
            }
        }
    }

    fun suggestedExportName(): String = "VocalStudio_${System.currentTimeMillis()}.wav"

    private fun setSource(file: File, name: String) {
        val peaks = runCatching { WavUtils.waveform(file) }.getOrDefault(emptyList())
        uiState = uiState.copy(
            sourceFile = file, sourceName = name, sourceWaveform = peaks,
            processedFile = null, processedWaveform = emptyList(),
            isRecording = false, status = "تم حفظ التسجيل الخام"
        )
    }

    private fun queryName(uri: Uri): String? {
        val resolver = getApplication<Application>().contentResolver
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    private inline fun updateParams(block: ProcessingParams.() -> ProcessingParams) {
        uiState = uiState.copy(params = uiState.params.block())
    }

    private inline fun updateVoiceParams(block: VoiceConversionParams.() -> VoiceConversionParams) {
        uiState = uiState.copy(voiceParams = uiState.voiceParams.block())
    }

    override fun onCleared() {
        runCatching { recorder.stop() }
        recordingFile = null
        player.stop()
        executor.shutdownNow()
        super.onCleared()
    }
}

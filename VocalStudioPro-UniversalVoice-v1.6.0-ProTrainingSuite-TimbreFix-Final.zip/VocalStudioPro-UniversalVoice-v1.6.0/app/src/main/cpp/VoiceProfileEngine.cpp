#include "VoiceProfileEngine.h"
#include "WavIO.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <complex>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <limits>
#include <numeric>
#include <vector>

namespace {
constexpr int OUT_SR = 48000;
constexpr int N = 2048;
constexpr int HOP = 512;
constexpr int HALF = N / 2;
constexpr int BANDS_V1 = 64;
constexpr int BANDS = 96;
constexpr int GROUPS = 5;      // unvoiced + four pitch registers
constexpr int PROTOS_PER_GROUP = 6;
constexpr int PROTOS = GROUPS * PROTOS_PER_GROUP;
constexpr int PCA_COMPONENTS = 12;
constexpr size_t PCA_RESERVOIR = 4096;
constexpr float TWO_PI = 6.28318530717958647692f;
constexpr float MAX_TRAIN_SECONDS = 50.0f * 60.0f;
constexpr char MAGIC_V1[8] = {'V','S','P','T','R','N','1','\0'};
constexpr char MAGIC_V3[8] = {'V','S','P','T','R','N','3','\0'};
std::atomic<float> gTrainingProgress{0.0f};
std::atomic<bool> gCancelTraining{false};
std::atomic<float> gLastEffectDb{0.0f};

struct HeaderV1 {
    char magic[8];
    uint32_t version;
    uint32_t sampleRate;
    uint32_t bandCount;
    float medianF0;
    float voicedRatio;
    float spectralCentroid;
    float reserved;
};

struct HeaderV3 {
    char magic[8];
    uint32_t version;
    uint32_t referenceSampleRate;
    uint32_t bandCount;
    uint32_t groupCount;
    uint32_t prototypeCount;
    uint32_t flags;
    uint64_t analyzedFrames;
    float sourceSeconds;
    float cleanSeconds;
    float medianF0;
    float voicedRatio;
    float spectralCentroid;
    float qualityScore;
    float clippingRatio;
    float noiseFloorDb;
};

struct ProfileV3 {
    HeaderV3 h{};
    std::array<float, BANDS> mean{};
    std::array<float, BANDS> stdev{};
    std::array<float, GROUPS * BANDS> groupMean{};
    std::array<uint32_t, GROUPS> groupCount{};
    std::array<float, PROTOS * BANDS> prototypes{};
    std::array<uint32_t, PROTOS> protoCount{};
    std::array<float, PCA_COMPONENTS * BANDS> pcaBasis{};
    std::array<float, PCA_COMPONENTS> pcaScale{};
};

uint16_t rd16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0] | (static_cast<uint16_t>(p[1]) << 8));
}
uint32_t rd32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) |
           (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) |
           (static_cast<uint32_t>(p[3]) << 24);
}

class WavStreamReader {
public:
    bool open(const std::string& path, std::string& error) {
        file.open(path, std::ios::binary);
        if (!file) { error = "Cannot open training WAV"; return false; }
        std::array<uint8_t, 12> head{};
        if (!file.read(reinterpret_cast<char*>(head.data()), static_cast<std::streamsize>(head.size()))) {
            error = "Training WAV header is truncated"; return false;
        }
        if (std::memcmp(head.data(), "RIFF", 4) != 0 || std::memcmp(head.data() + 8, "WAVE", 4) != 0) {
            error = "Training input is not RIFF/WAVE"; return false;
        }
        bool gotFmt = false, gotData = false;
        while (file && !(gotFmt && gotData)) {
            std::array<uint8_t, 8> ch{};
            if (!file.read(reinterpret_cast<char*>(ch.data()), static_cast<std::streamsize>(ch.size()))) break;
            const uint32_t size = rd32(ch.data() + 4);
            const std::streamoff payloadPos = file.tellg();
            if (std::memcmp(ch.data(), "fmt ", 4) == 0 && size >= 16) {
                std::vector<uint8_t> payload(size);
                if (!file.read(reinterpret_cast<char*>(payload.data()), static_cast<std::streamsize>(size))) break;
                format = rd16(payload.data());
                channels = rd16(payload.data() + 2);
                sampleRate = static_cast<int>(rd32(payload.data() + 4));
                bits = rd16(payload.data() + 14);
                if (format == 0xfffe && size >= 40) format = static_cast<uint16_t>(rd32(payload.data() + 24) & 0xffffu);
                gotFmt = true;
            } else if (std::memcmp(ch.data(), "data", 4) == 0) {
                dataOffset = payloadPos;
                dataBytes = size;
                file.seekg(static_cast<std::streamoff>(size), std::ios::cur);
                gotData = true;
            } else {
                file.seekg(static_cast<std::streamoff>(size), std::ios::cur);
            }
            if (size & 1u) file.seekg(1, std::ios::cur);
        }
        if (!gotFmt || !gotData || channels == 0 || sampleRate <= 0 || bits == 0) {
            error = "Incomplete training WAV"; return false;
        }
        if (format != 1 && format != 3) { error = "Unsupported training WAV encoding"; return false; }
        bytesPerSample = static_cast<int>(bits / 8);
        if (bytesPerSample <= 0 || (format == 3 && bits != 32)) { error = "Unsupported training bit depth"; return false; }
        frameBytes = static_cast<uint64_t>(bytesPerSample) * channels;
        if (frameBytes == 0) { error = "Invalid training channel count"; return false; }
        totalFrames = dataBytes / frameBytes;
        rewindData();
        return true;
    }

    void rewindData() {
        file.clear();
        file.seekg(dataOffset);
        framesRead = 0;
    }

    bool readMono(size_t maxFrames, std::vector<float>& out) {
        out.clear();
        if (!file || framesRead >= totalFrames || maxFrames == 0) return false;
        const uint64_t remain = totalFrames - framesRead;
        const size_t want = static_cast<size_t>(std::min<uint64_t>(remain, maxFrames));
        const size_t bytes = want * static_cast<size_t>(frameBytes);
        raw.resize(bytes);
        file.read(reinterpret_cast<char*>(raw.data()), static_cast<std::streamsize>(bytes));
        const size_t gotBytes = static_cast<size_t>(file.gcount());
        const size_t gotFrames = gotBytes / static_cast<size_t>(frameBytes);
        if (gotFrames == 0) return false;
        out.resize(gotFrames);
        for (size_t i = 0; i < gotFrames; ++i) {
            double s = 0.0;
            const uint8_t* frame = raw.data() + i * static_cast<size_t>(frameBytes);
            for (uint16_t c = 0; c < channels; ++c) s += decode(frame + static_cast<size_t>(c) * bytesPerSample);
            out[i] = static_cast<float>(s / channels);
        }
        framesRead += gotFrames;
        return true;
    }

    float durationSeconds() const {
        return sampleRate > 0 ? static_cast<float>(totalFrames) / static_cast<float>(sampleRate) : 0.0f;
    }

    int rate() const { return sampleRate; }
    float progress() const {
        return totalFrames > 0 ? static_cast<float>(framesRead) / static_cast<float>(totalFrames) : 0.0f;
    }

private:
    float decode(const uint8_t* p) const {
        if (format == 3 && bits == 32) {
            float v = 0.0f;
            std::memcpy(&v, p, sizeof(float));
            return std::clamp(v, -1.0f, 1.0f);
        }
        switch (bits) {
            case 8: return (static_cast<int>(*p) - 128) / 128.0f;
            case 16: return static_cast<int16_t>(rd16(p)) / 32768.0f;
            case 24: {
                int32_t v = static_cast<int32_t>(p[0]) |
                            (static_cast<int32_t>(p[1]) << 8) |
                            (static_cast<int32_t>(p[2]) << 16);
                if (v & 0x00800000) v |= static_cast<int32_t>(0xff000000);
                return v / 8388608.0f;
            }
            case 32: return static_cast<float>(static_cast<int32_t>(rd32(p)) / 2147483648.0);
            default: return 0.0f;
        }
    }

    std::ifstream file;
    uint16_t format = 0, channels = 0, bits = 0;
    int sampleRate = 0, bytesPerSample = 0;
    uint64_t frameBytes = 0, totalFrames = 0, framesRead = 0;
    std::streamoff dataOffset = 0;
    uint64_t dataBytes = 0;
    std::vector<uint8_t> raw;
};

void fft(std::vector<std::complex<float>>& a, bool inverse) {
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (size_t len = 2; len <= n; len <<= 1) {
        const float ang = TWO_PI / static_cast<float>(len) * (inverse ? 1.0f : -1.0f);
        const std::complex<float> wlen(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) {
            std::complex<float> w(1.0f, 0.0f);
            for (size_t j = 0; j < len / 2; ++j) {
                const auto u = a[i + j];
                const auto v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
    if (inverse) for (auto& v : a) v /= static_cast<float>(n);
}

std::vector<float> makeWindow() {
    std::vector<float> w(N);
    for (int i = 0; i < N; ++i) {
        const float hann = 0.5f - 0.5f * std::cos(TWO_PI * i / static_cast<float>(N));
        w[static_cast<size_t>(i)] = std::sqrt(std::max(0.0f, hann));
    }
    return w;
}

int bandForHz(float hz, int bands) {
    if (hz <= 65.0f) return 0;
    const float lo = std::log(65.0f);
    const float hi = std::log(16000.0f);
    const float x = (std::log(std::min(hz, 16000.0f)) - lo) / (hi - lo);
    return std::clamp(static_cast<int>(x * (bands - 1)), 0, bands - 1);
}

float bandPosition(float hz, int bands) {
    if (hz <= 65.0f) return 0.0f;
    const float lo = std::log(65.0f);
    const float hi = std::log(16000.0f);
    const float x = (std::log(std::min(hz, 16000.0f)) - lo) / (hi - lo);
    return std::clamp(x * (bands - 1), 0.0f, static_cast<float>(bands - 1));
}

float percentileFromHist(const std::array<uint64_t, 181>& hist, double q) {
    const uint64_t total = std::accumulate(hist.begin(), hist.end(), uint64_t{0});
    if (total == 0) return -60.0f;
    const uint64_t target = static_cast<uint64_t>(std::llround(q * static_cast<double>(total - 1)));
    uint64_t acc = 0;
    for (size_t i = 0; i < hist.size(); ++i) {
        acc += hist[i];
        if (acc > target) return static_cast<float>(static_cast<int>(i) - 180) * 0.5f;
    }
    return -20.0f;
}

float dbFromRms(float rms) { return 20.0f * std::log10(std::max(rms, 1e-8f)); }

struct FrameFeatures {
    std::array<float, BANDS> env{};
    float rms = 0.0f;
    float centroid = 0.0f;
    float highRatio = 0.0f;
    float flatness = 0.0f;
    float f0 = 0.0f;
    bool voiced = false;
    int group = 0;
};

float estimateF0(const std::vector<float>& mag, int sr) {
    const int minK = std::max(2, static_cast<int>(70.0f * N / sr));
    const int maxK = std::min(HALF / 3, static_cast<int>(700.0f * N / sr));
    if (maxK <= minK) return 0.0f;
    float best = -1e30f;
    int bestK = 0;
    double mean = 0.0;
    for (int k = minK; k <= maxK; ++k) {
        const float a = std::log(mag[static_cast<size_t>(k)] + 1e-8f);
        const float b = std::log(mag[static_cast<size_t>(2 * k)] + 1e-8f);
        const float c = std::log(mag[static_cast<size_t>(3 * k)] + 1e-8f);
        const float score = a + 0.62f * b + 0.38f * c;
        mean += score;
        if (score > best) { best = score; bestK = k; }
    }
    mean /= std::max(1, maxK - minK + 1);
    if (bestK == 0 || best - static_cast<float>(mean) < 1.1f) return 0.0f;
    return static_cast<float>(bestK) * sr / N;
}

FrameFeatures analyzeFrame(const float* x, int sr, const std::vector<float>& window,
                           std::vector<std::complex<float>>& spec, std::vector<float>& mag) {
    FrameFeatures ff{};
    double e = 0.0;
    for (int i = 0; i < N; ++i) {
        const float s = x[i];
        e += static_cast<double>(s) * s;
        spec[static_cast<size_t>(i)] = {s * window[static_cast<size_t>(i)], 0.0f};
    }
    ff.rms = std::sqrt(static_cast<float>(e / N));
    fft(spec, false);
    mag.resize(HALF + 1);
    std::array<double, BANDS> power{};
    double total = 0.0, high = 0.0, centroidNum = 0.0, logSum = 0.0;
    int flatCount = 0;
    for (int k = 1; k <= HALF; ++k) {
        const float hz = static_cast<float>(k) * sr / N;
        const float m = std::abs(spec[static_cast<size_t>(k)]);
        mag[static_cast<size_t>(k)] = m;
        const double p = static_cast<double>(m) * m + 1e-12;
        if (hz >= 65.0f && hz <= std::min(16000.0f, sr * 0.49f)) {
            power[static_cast<size_t>(bandForHz(hz, BANDS))] += p;
            total += p;
            centroidNum += hz * p;
            if (hz > 4500.0f) high += p;
            logSum += std::log(p);
            ++flatCount;
        }
    }
    double arith = 0.0;
    for (double p : power) arith += p;
    ff.centroid = total > 0.0 ? static_cast<float>(centroidNum / total) : 0.0f;
    ff.highRatio = total > 0.0 ? static_cast<float>(high / total) : 0.0f;
    if (flatCount > 0 && arith > 0.0) {
        const double geom = std::exp(logSum / flatCount);
        ff.flatness = static_cast<float>(std::clamp(geom / (arith / BANDS + 1e-12), 0.0, 1.0));
    }
    for (int b = 0; b < BANDS; ++b) ff.env[static_cast<size_t>(b)] = 0.5f * std::log(static_cast<float>(power[static_cast<size_t>(b)] + 1e-10));
    const float mean = std::accumulate(ff.env.begin() + 5, ff.env.end() - 8, 0.0f) / static_cast<float>(BANDS - 13);
    for (float& v : ff.env) v -= mean;
    // Light frequency smoothing removes pitch-harmonic ripple but keeps the vocal formant envelope.
    auto original = ff.env;
    for (int b = 0; b < BANDS; ++b) {
        double s = 0.0, w = 0.0;
        for (int d = -2; d <= 2; ++d) {
            const int j = std::clamp(b + d, 0, BANDS - 1);
            const double ww = (d == 0 ? 3.0 : (std::abs(d) == 1 ? 2.0 : 1.0));
            s += original[static_cast<size_t>(j)] * ww;
            w += ww;
        }
        ff.env[static_cast<size_t>(b)] = std::clamp(static_cast<float>(s / w), -24.0f, 24.0f);
    }
    ff.f0 = estimateF0(mag, sr);
    ff.voiced = ff.f0 > 0.0f && ff.highRatio < 0.48f && ff.flatness < 0.48f;
    if (!ff.voiced) ff.group = 0;
    else if (ff.f0 < 130.0f) ff.group = 1;
    else if (ff.f0 < 200.0f) ff.group = 2;
    else if (ff.f0 < 300.0f) ff.group = 3;
    else ff.group = 4;
    return ff;
}

struct RunningStats {
    uint64_t count = 0;
    std::array<double, BANDS> mean{};
    std::array<double, BANDS> m2{};
    void add(const std::array<float, BANDS>& x) {
        ++count;
        const double n = static_cast<double>(count);
        for (int b = 0; b < BANDS; ++b) {
            const double delta = x[static_cast<size_t>(b)] - mean[static_cast<size_t>(b)];
            mean[static_cast<size_t>(b)] += delta / n;
            const double delta2 = x[static_cast<size_t>(b)] - mean[static_cast<size_t>(b)];
            m2[static_cast<size_t>(b)] += delta * delta2;
        }
    }
};

float envDistance(const float* a, const std::array<float, BANDS>& b) {
    double d = 0.0, wsum = 0.0;
    for (int i = 3; i < BANDS - 6; ++i) {
        const float hzPos = static_cast<float>(i) / (BANDS - 1);
        const double w = 0.65 + 0.70 * std::sin(3.14159265358979323846 * hzPos);
        const double e = static_cast<double>(a[i] - b[static_cast<size_t>(i)]);
        d += w * e * e;
        wsum += w;
    }
    return static_cast<float>(d / std::max(wsum, 1e-9));
}

void updatePrototype(ProfileV3& p, const FrameFeatures& ff) {
    const int start = ff.group * PROTOS_PER_GROUP;
    int empty = -1;
    int nearest = start;
    float nearestD = std::numeric_limits<float>::max();
    for (int j = 0; j < PROTOS_PER_GROUP; ++j) {
        const int idx = start + j;
        if (p.protoCount[static_cast<size_t>(idx)] == 0) { if (empty < 0) empty = idx; continue; }
        const float d = envDistance(&p.prototypes[static_cast<size_t>(idx * BANDS)], ff.env);
        if (d < nearestD) { nearestD = d; nearest = idx; }
    }
    int idx = nearest;
    if (empty >= 0 && (p.protoCount[static_cast<size_t>(nearest)] == 0 || nearestD > 0.075f)) idx = empty;
    uint32_t& count = p.protoCount[static_cast<size_t>(idx)];
    ++count;
    // Cap the adaptation rate so long recordings do not freeze prototypes too early.
    const float lr = std::max(0.004f, 1.0f / static_cast<float>(count));
    float* dst = &p.prototypes[static_cast<size_t>(idx * BANDS)];
    for (int b = 0; b < BANDS; ++b) dst[b] += (ff.env[static_cast<size_t>(b)] - dst[b]) * lr;
}


uint64_t mix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

void reservoirAdd(std::vector<std::array<float, BANDS>>& reservoir,
                  const std::array<float, BANDS>& env, uint64_t seen) {
    if (reservoir.size() < PCA_RESERVOIR) {
        reservoir.push_back(env);
        return;
    }
    const uint64_t j = mix64(seen) % std::max<uint64_t>(1, seen);
    if (j < PCA_RESERVOIR) reservoir[static_cast<size_t>(j)] = env;
}

void computePca(const std::vector<std::array<float, BANDS>>& samples,
                const std::array<float, BANDS>& mean,
                std::array<float, PCA_COMPONENTS * BANDS>& basis,
                std::array<float, PCA_COMPONENTS>& scale) {
    basis.fill(0.0f);
    scale.fill(0.0f);
    if (samples.size() < 32) return;

    std::vector<double> cov(static_cast<size_t>(BANDS * BANDS), 0.0);
    std::array<double, BANDS> centered{};
    for (const auto& sample : samples) {
        for (int i = 0; i < BANDS; ++i) centered[static_cast<size_t>(i)] = sample[static_cast<size_t>(i)] - mean[static_cast<size_t>(i)];
        for (int i = 0; i < BANDS; ++i) {
            const double xi = centered[static_cast<size_t>(i)];
            for (int j = i; j < BANDS; ++j) {
                cov[static_cast<size_t>(i * BANDS + j)] += xi * centered[static_cast<size_t>(j)];
            }
        }
    }
    const double denom = static_cast<double>(samples.size() - 1);
    for (int i = 0; i < BANDS; ++i) {
        for (int j = i; j < BANDS; ++j) {
            const double v = cov[static_cast<size_t>(i * BANDS + j)] / denom;
            cov[static_cast<size_t>(i * BANDS + j)] = v;
            cov[static_cast<size_t>(j * BANDS + i)] = v;
        }
    }

    std::array<double, BANDS> v{};
    std::array<double, BANDS> w{};
    for (int c = 0; c < PCA_COMPONENTS; ++c) {
        for (int i = 0; i < BANDS; ++i) {
            v[static_cast<size_t>(i)] = std::sin((c + 1) * (i + 1) * 0.371) + 0.31 * std::cos((c + 2) * (i + 1) * 0.193);
        }
        for (int prev = 0; prev < c; ++prev) {
            double dot = 0.0;
            for (int i = 0; i < BANDS; ++i) dot += v[static_cast<size_t>(i)] * basis[static_cast<size_t>(prev * BANDS + i)];
            for (int i = 0; i < BANDS; ++i) v[static_cast<size_t>(i)] -= dot * basis[static_cast<size_t>(prev * BANDS + i)];
        }
        for (int iter = 0; iter < 48; ++iter) {
            w.fill(0.0);
            for (int i = 0; i < BANDS; ++i) {
                double sum = 0.0;
                for (int j = 0; j < BANDS; ++j) sum += cov[static_cast<size_t>(i * BANDS + j)] * v[static_cast<size_t>(j)];
                w[static_cast<size_t>(i)] = sum;
            }
            for (int prev = 0; prev < c; ++prev) {
                double dot = 0.0;
                for (int i = 0; i < BANDS; ++i) dot += w[static_cast<size_t>(i)] * basis[static_cast<size_t>(prev * BANDS + i)];
                for (int i = 0; i < BANDS; ++i) w[static_cast<size_t>(i)] -= dot * basis[static_cast<size_t>(prev * BANDS + i)];
            }
            double norm = 0.0;
            for (double x : w) norm += x * x;
            norm = std::sqrt(std::max(norm, 1e-18));
            for (int i = 0; i < BANDS; ++i) v[static_cast<size_t>(i)] = w[static_cast<size_t>(i)] / norm;
        }
        double eig = 0.0;
        for (int i = 0; i < BANDS; ++i) {
            double row = 0.0;
            for (int j = 0; j < BANDS; ++j) row += cov[static_cast<size_t>(i * BANDS + j)] * v[static_cast<size_t>(j)];
            eig += v[static_cast<size_t>(i)] * row;
            basis[static_cast<size_t>(c * BANDS + i)] = static_cast<float>(v[static_cast<size_t>(i)]);
        }
        scale[static_cast<size_t>(c)] = static_cast<float>(std::sqrt(std::max(eig, 1e-8)));
    }
}


void sanitizeProfile(ProfileV3& p) {
    auto clampFinite = [](auto& values, float lo, float hi) {
        for (auto& v : values) {
            if (!std::isfinite(v)) v = 0.0f;
            v = std::clamp(v, lo, hi);
        }
    };
    clampFinite(p.mean, -24.0f, 24.0f);
    clampFinite(p.stdev, 0.0f, 24.0f);
    clampFinite(p.groupMean, -24.0f, 24.0f);
    clampFinite(p.prototypes, -24.0f, 24.0f);
    clampFinite(p.pcaBasis, -2.0f, 2.0f);
    clampFinite(p.pcaScale, 0.0f, 48.0f);

    p.h.sourceSeconds = std::clamp(std::isfinite(p.h.sourceSeconds) ? p.h.sourceSeconds : 0.0f,
                                   0.0f, MAX_TRAIN_SECONDS);
    p.h.cleanSeconds = std::clamp(std::isfinite(p.h.cleanSeconds) ? p.h.cleanSeconds : 0.0f,
                                  0.0f, p.h.sourceSeconds);
    p.h.medianF0 = std::clamp(std::isfinite(p.h.medianF0) ? p.h.medianF0 : 0.0f,
                              0.0f, 4000.0f);
    p.h.voicedRatio = std::clamp(std::isfinite(p.h.voicedRatio) ? p.h.voicedRatio : 0.0f,
                                 0.0f, 1.0f);
    p.h.spectralCentroid = std::clamp(std::isfinite(p.h.spectralCentroid) ? p.h.spectralCentroid : 0.0f,
                                      0.0f, OUT_SR * 0.5f);
    p.h.qualityScore = std::clamp(std::isfinite(p.h.qualityScore) ? p.h.qualityScore : 0.0f,
                                  0.0f, 100.0f);
    p.h.clippingRatio = std::clamp(std::isfinite(p.h.clippingRatio) ? p.h.clippingRatio : 0.0f,
                                   0.0f, 1.0f);
    p.h.noiseFloorDb = std::clamp(std::isfinite(p.h.noiseFloorDb) ? p.h.noiseFloorDb : -90.0f,
                                  -120.0f, 0.0f);
}

bool readProfileV3(const std::string& path, ProfileV3& p, std::string& error) {
    std::ifstream in(path, std::ios::binary);
    if (!in) { error = "Cannot open trained voice profile"; return false; }
    in.read(reinterpret_cast<char*>(&p.h), sizeof(p.h));
    if (!in || std::memcmp(p.h.magic, MAGIC_V3, sizeof(MAGIC_V3)) != 0 || p.h.version != 3 ||
        p.h.bandCount != BANDS || p.h.groupCount != GROUPS || p.h.prototypeCount != PROTOS) {
        error = "Invalid or unsupported VSPTRAIN3 profile"; return false;
    }
    in.read(reinterpret_cast<char*>(p.mean.data()), static_cast<std::streamsize>(sizeof(float) * p.mean.size()));
    in.read(reinterpret_cast<char*>(p.stdev.data()), static_cast<std::streamsize>(sizeof(float) * p.stdev.size()));
    in.read(reinterpret_cast<char*>(p.groupMean.data()), static_cast<std::streamsize>(sizeof(float) * p.groupMean.size()));
    in.read(reinterpret_cast<char*>(p.groupCount.data()), static_cast<std::streamsize>(sizeof(uint32_t) * p.groupCount.size()));
    in.read(reinterpret_cast<char*>(p.prototypes.data()), static_cast<std::streamsize>(sizeof(float) * p.prototypes.size()));
    in.read(reinterpret_cast<char*>(p.protoCount.data()), static_cast<std::streamsize>(sizeof(uint32_t) * p.protoCount.size()));
    in.read(reinterpret_cast<char*>(p.pcaBasis.data()), static_cast<std::streamsize>(sizeof(float) * p.pcaBasis.size()));
    in.read(reinterpret_cast<char*>(p.pcaScale.data()), static_cast<std::streamsize>(sizeof(float) * p.pcaScale.size()));
    if (!in) { error = "Truncated VSPTRAIN3 profile"; return false; }

    if (p.h.referenceSampleRate < 12000u || p.h.referenceSampleRate > 192000u ||
        !std::isfinite(p.h.sourceSeconds) || p.h.sourceSeconds < 0.0f ||
        p.h.sourceSeconds > MAX_TRAIN_SECONDS + 1.0f ||
        !std::isfinite(p.h.cleanSeconds) || p.h.cleanSeconds < 0.0f ||
        p.h.cleanSeconds > p.h.sourceSeconds + 5.0f ||
        !std::isfinite(p.h.qualityScore) || p.h.qualityScore < 0.0f || p.h.qualityScore > 100.5f ||
        !std::isfinite(p.h.clippingRatio) || p.h.clippingRatio < 0.0f || p.h.clippingRatio > 1.0f ||
        !std::isfinite(p.h.noiseFloorDb) || p.h.noiseFloorDb < -140.0f || p.h.noiseFloorDb > 5.0f ||
        !std::isfinite(p.h.medianF0) || p.h.medianF0 < 0.0f || p.h.medianF0 > 4000.0f ||
        !std::isfinite(p.h.voicedRatio) || p.h.voicedRatio < 0.0f || p.h.voicedRatio > 1.0f ||
        !std::isfinite(p.h.spectralCentroid) || p.h.spectralCentroid < 0.0f ||
        p.h.spectralCentroid > static_cast<float>(p.h.referenceSampleRate) * 0.5f + 100.0f) {
        error = "Invalid VSPTRAIN3 metadata";
        return false;
    }

    auto finiteBounded = [&](const auto& values, float limit, const char* label) -> bool {
        for (float v : values) {
            if (!std::isfinite(v) || std::abs(v) > limit) {
                error = std::string("Corrupted VSPTRAIN3 ") + label;
                return false;
            }
        }
        return true;
    };
    if (!finiteBounded(p.mean, 32.0f, "mean envelope") ||
        !finiteBounded(p.stdev, 32.0f, "envelope variance") ||
        !finiteBounded(p.groupMean, 32.0f, "group envelope") ||
        !finiteBounded(p.prototypes, 32.0f, "prototype envelope") ||
        !finiteBounded(p.pcaBasis, 4.0f, "PCA basis") ||
        !finiteBounded(p.pcaScale, 64.0f, "PCA scale")) {
        return false;
    }
    for (float v : p.stdev) {
        if (v < 0.0f) { error = "Corrupted VSPTRAIN3 negative deviation"; return false; }
    }
    for (float v : p.pcaScale) {
        if (v < 0.0f) { error = "Corrupted VSPTRAIN3 negative PCA scale"; return false; }
    }
    return true;
}

bool readProfileV1(const std::string& path, HeaderV1& h, std::array<float, BANDS_V1>& bands, std::string& error) {
    std::ifstream in(path, std::ios::binary);
    if (!in) { error = "Cannot open trained voice profile"; return false; }
    in.read(reinterpret_cast<char*>(&h), sizeof(h));
    if (!in || std::memcmp(h.magic, MAGIC_V1, sizeof(MAGIC_V1)) != 0 || h.version != 1 ||
        h.sampleRate != OUT_SR || h.bandCount != BANDS_V1) { error = "Invalid VSPTRAIN1 profile"; return false; }
    in.read(reinterpret_cast<char*>(bands.data()), static_cast<std::streamsize>(sizeof(float) * bands.size()));
    return static_cast<bool>(in);
}

bool isV3(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    char magic[8]{};
    return in.read(magic, 8) && std::memcmp(magic, MAGIC_V3, 8) == 0;
}

float median(std::vector<float> v) {
    if (v.empty()) return 0.0f;
    const size_t m = v.size() / 2;
    std::nth_element(v.begin(), v.begin() + static_cast<long>(m), v.end());
    return v[m];
}

} // namespace

int VoiceProfileEngine::validate(const std::string& profilePath, std::string& error) {
    if (isV3(profilePath)) {
        ProfileV3 p{};
        return readProfileV3(profilePath, p, error) ? 0 : 1;
    }
    HeaderV1 h{};
    std::array<float, BANDS_V1> bands{};
    return readProfileV1(profilePath, h, bands, error) ? 0 : 1;
}

int VoiceProfileEngine::inspect(const std::string& profilePath,
                                VoiceProfileMetrics& metrics,
                                std::string& error) {
    if (isV3(profilePath)) {
        ProfileV3 profile{};
        if (!readProfileV3(profilePath, profile, error)) return 1;
        metrics.version = static_cast<int>(profile.h.version);
        metrics.sourceSeconds = profile.h.sourceSeconds;
        metrics.cleanSeconds = profile.h.cleanSeconds;
        metrics.qualityScore = profile.h.qualityScore;
        metrics.clippingRatio = profile.h.clippingRatio;
        metrics.noiseFloorDb = profile.h.noiseFloorDb;
        metrics.medianF0 = profile.h.medianF0;
        metrics.voicedRatio = profile.h.voicedRatio;
        metrics.spectralCentroid = profile.h.spectralCentroid;
        metrics.analyzedFrames = profile.h.analyzedFrames;
        return 0;
    }

    HeaderV1 header{};
    std::array<float, BANDS_V1> bands{};
    if (!readProfileV1(profilePath, header, bands, error)) return 1;
    metrics.version = static_cast<int>(header.version);
    metrics.medianF0 = header.medianF0;
    metrics.voicedRatio = header.voicedRatio;
    metrics.spectralCentroid = header.spectralCentroid;
    return 0;
}

int VoiceProfileEngine::train(const std::string& inputPath, const std::string& profilePath, std::string& error) {
    return trainMany({inputPath}, profilePath, error);
}

int VoiceProfileEngine::trainMany(const std::vector<std::string>& inputPaths,
                                  const std::string& profilePath,
                                  std::string& error) {
    gCancelTraining.store(false, std::memory_order_relaxed);
    gTrainingProgress.store(0.01f, std::memory_order_relaxed);
    if (inputPaths.empty()) { error = "Training dataset is empty"; return 9; }
    if (inputPaths.size() > 64) { error = "Training dataset contains too many files"; return 9; }

    struct SourcePass {
        std::string path;
        int sampleRate = 0;
        float seconds = 0.0f;
        float noiseDb = -90.0f;
        float gateDb = -52.0f;
        uint64_t sampleCount = 0;
        uint64_t clipped = 0;
    };

    std::vector<SourcePass> sources;
    sources.reserve(inputPaths.size());
    double totalSeconds = 0.0;
    uint64_t totalSamples = 0;
    uint64_t totalClipped = 0;
    double weightedNoiseDb = 0.0;

    // Pass 1 is performed independently per recording. A noisy clip can no longer raise the
    // activity gate for every clean clip in a multi-file dataset.
    for (size_t sourceIndex = 0; sourceIndex < inputPaths.size(); ++sourceIndex) {
        const auto& path = inputPaths[sourceIndex];
        WavStreamReader reader;
        if (!reader.open(path, error)) return 10;
        SourcePass source;
        source.path = path;
        source.seconds = reader.durationSeconds();
        source.sampleRate = reader.rate();
        if (source.seconds < 1.0f) { error = "Every training clip must be at least 1 second"; return 11; }
        if (source.sampleRate < 12000 || source.sampleRate > 192000) {
            error = "Unsupported training sample rate"; return 13;
        }
        totalSeconds += source.seconds;
        if (totalSeconds > MAX_TRAIN_SECONDS + 0.5) {
            error = "Training dataset exceeds the 50 minute limit"; return 12;
        }

        std::array<uint64_t, 181> rmsHist{};
        std::vector<float> block;
        const size_t blockFrames = static_cast<size_t>(source.sampleRate) * 20u;
        while (reader.readMono(blockFrames, block)) {
            if (gCancelTraining.load(std::memory_order_relaxed)) {
                error = "Training cancelled";
                gTrainingProgress.store(0.0f, std::memory_order_relaxed);
                return 90;
            }
            const float fileProgress = (static_cast<float>(sourceIndex) + reader.progress()) /
                                       static_cast<float>(inputPaths.size());
            gTrainingProgress.store(0.03f + 0.37f * fileProgress, std::memory_order_relaxed);
            const size_t frame = std::max<size_t>(256, static_cast<size_t>(source.sampleRate / 50));
            for (size_t pos = 0; pos < block.size(); pos += frame) {
                const size_t end = std::min(block.size(), pos + frame);
                double energy = 0.0;
                for (size_t i = pos; i < end; ++i) {
                    const float sample = block[i];
                    energy += static_cast<double>(sample) * sample;
                    if (std::abs(sample) >= 0.995f) ++source.clipped;
                    ++source.sampleCount;
                }
                const float rms = std::sqrt(static_cast<float>(energy / std::max<size_t>(1, end - pos)));
                const float db = std::clamp(dbFromRms(rms), -90.0f, 0.0f);
                const int idx = std::clamp(static_cast<int>(std::lround((db + 90.0f) * 2.0f)), 0, 180);
                ++rmsHist[static_cast<size_t>(idx)];
            }
        }
        source.noiseDb = percentileFromHist(rmsHist, 0.12);
        source.gateDb = std::clamp(source.noiseDb + 11.0f, -52.0f, -25.0f);
        totalSamples += source.sampleCount;
        totalClipped += source.clipped;
        weightedNoiseDb += static_cast<double>(source.noiseDb) * source.seconds;
        sources.push_back(std::move(source));
    }

    if (totalSeconds < 5.0) { error = "Training audio must be at least 5 seconds"; return 11; }
    const float noiseDb = totalSeconds > 0.0
        ? static_cast<float>(weightedNoiseDb / totalSeconds) : -90.0f;
    const float clippingRatio = totalSamples > 0
        ? static_cast<float>(totalClipped) / static_cast<float>(totalSamples) : 0.0f;
    gTrainingProgress.store(0.42f, std::memory_order_relaxed);

    const auto window = makeWindow();
    std::vector<std::complex<float>> spec(N);
    std::vector<float> mag;
    RunningStats globalStats;
    std::array<RunningStats, GROUPS> groupStats{};
    ProfileV3 profile{};
    std::vector<std::array<float, BANDS>> pcaReservoir;
    pcaReservoir.reserve(PCA_RESERVOIR);
    std::vector<float> f0Sample;
    f0Sample.reserve(8192);
    double centroidSum = 0.0;
    double cleanSeconds = 0.0;
    uint64_t centroidCount = 0, voicedCount = 0, cleanFrames = 0;

    // Pass 2 fits the shared speaker envelope, pitch-register clusters, prototypes and PCA
    // manifold over all accepted recordings without ever loading the full dataset into RAM.
    for (size_t sourceIndex = 0; sourceIndex < sources.size(); ++sourceIndex) {
        const auto& source = sources[sourceIndex];
        WavStreamReader reader;
        if (!reader.open(source.path, error)) return 10;
        std::vector<float> block;
        std::vector<float> carry;
        carry.reserve(N);
        const size_t blockFrames = static_cast<size_t>(source.sampleRate) * 20u;
        while (reader.readMono(blockFrames, block)) {
            if (gCancelTraining.load(std::memory_order_relaxed)) {
                error = "Training cancelled";
                gTrainingProgress.store(0.0f, std::memory_order_relaxed);
                return 90;
            }
            const float fileProgress = (static_cast<float>(sourceIndex) + reader.progress()) /
                                       static_cast<float>(sources.size());
            gTrainingProgress.store(0.42f + 0.50f * fileProgress, std::memory_order_relaxed);
            std::vector<float> joined;
            joined.reserve(carry.size() + block.size());
            joined.insert(joined.end(), carry.begin(), carry.end());
            joined.insert(joined.end(), block.begin(), block.end());
            if (joined.size() >= N) {
                for (size_t pos = 0; pos + N <= joined.size(); pos += HOP) {
                    const FrameFeatures ff = analyzeFrame(joined.data() + pos, source.sampleRate, window, spec, mag);
                    if (dbFromRms(ff.rms) < source.gateDb) continue;
                    ++cleanFrames;
                    cleanSeconds += static_cast<double>(HOP) / source.sampleRate;
                    globalStats.add(ff.env);
                    reservoirAdd(pcaReservoir, ff.env, cleanFrames);
                    groupStats[static_cast<size_t>(ff.group)].add(ff.env);
                    updatePrototype(profile, ff);
                    centroidSum += ff.centroid;
                    ++centroidCount;
                    if (ff.voiced) {
                        ++voicedCount;
                        if (f0Sample.size() < 8192) f0Sample.push_back(ff.f0);
                        else {
                            const size_t idx = static_cast<size_t>(cleanFrames % f0Sample.size());
                            f0Sample[idx] = ff.f0;
                        }
                    }
                }
                const size_t keep = std::min<size_t>(N - HOP, joined.size());
                carry.assign(joined.end() - static_cast<long>(keep), joined.end());
            }
        }
    }

    if (globalStats.count < 80 || cleanFrames < 80) { error = "Not enough clean voice activity for professional training"; return 20; }

    std::memcpy(profile.h.magic, MAGIC_V3, sizeof(MAGIC_V3));
    profile.h.version = 3;
    profile.h.referenceSampleRate = OUT_SR;
    profile.h.bandCount = BANDS;
    profile.h.groupCount = GROUPS;
    profile.h.prototypeCount = PROTOS;
    profile.h.flags = 1u; // register-conditioned prototypes
    profile.h.analyzedFrames = cleanFrames;
    profile.h.sourceSeconds = static_cast<float>(totalSeconds);
    profile.h.cleanSeconds = static_cast<float>(cleanSeconds);
    profile.h.medianF0 = median(f0Sample);
    profile.h.voicedRatio = cleanFrames > 0 ? static_cast<float>(voicedCount) / static_cast<float>(cleanFrames) : 0.0f;
    profile.h.spectralCentroid = centroidCount > 0 ? static_cast<float>(centroidSum / centroidCount) : 0.0f;
    profile.h.clippingRatio = clippingRatio;
    profile.h.noiseFloorDb = noiseDb;

    for (int b = 0; b < BANDS; ++b) {
        profile.mean[static_cast<size_t>(b)] = static_cast<float>(globalStats.mean[static_cast<size_t>(b)]);
        const double var = globalStats.count > 1 ? globalStats.m2[static_cast<size_t>(b)] / static_cast<double>(globalStats.count - 1) : 0.0;
        profile.stdev[static_cast<size_t>(b)] = static_cast<float>(std::sqrt(std::max(0.0, var)));
    }
    gTrainingProgress.store(0.94f, std::memory_order_relaxed);
    computePca(pcaReservoir, profile.mean, profile.pcaBasis, profile.pcaScale);

    for (int g = 0; g < GROUPS; ++g) {
        profile.groupCount[static_cast<size_t>(g)] = static_cast<uint32_t>(std::min<uint64_t>(groupStats[static_cast<size_t>(g)].count, 0xffffffffu));
        for (int b = 0; b < BANDS; ++b) {
            profile.groupMean[static_cast<size_t>(g * BANDS + b)] = groupStats[static_cast<size_t>(g)].count > 0
                ? static_cast<float>(groupStats[static_cast<size_t>(g)].mean[static_cast<size_t>(b)])
                : profile.mean[static_cast<size_t>(b)];
        }
    }

    // Quality score rewards clean active speech and penalizes clipping/noisy input; informational only.
    const float cleanRatio = std::clamp(profile.h.cleanSeconds / std::max(1.0f, profile.h.sourceSeconds), 0.0f, 1.0f);
    const float noiseScore = std::clamp(((-noiseDb) - 25.0f) / 35.0f, 0.0f, 1.0f);
    const float clipScore = std::clamp(1.0f - clippingRatio * 100.0f, 0.0f, 1.0f);
    profile.h.qualityScore = 100.0f * (0.42f * noiseScore + 0.33f * cleanRatio + 0.25f * clipScore);
    sanitizeProfile(profile);
    gTrainingProgress.store(0.98f, std::memory_order_relaxed);

    // Write atomically and self-validate before exposing the final file to Kotlin.
    const std::string tempPath = profilePath + ".tmp";
    std::remove(tempPath.c_str());
    {
        std::ofstream out(tempPath, std::ios::binary | std::ios::trunc);
        if (!out) { error = "Cannot create professional trained voice profile"; return 30; }
        out.write(reinterpret_cast<const char*>(&profile.h), sizeof(profile.h));
        out.write(reinterpret_cast<const char*>(profile.mean.data()), static_cast<std::streamsize>(sizeof(float) * profile.mean.size()));
        out.write(reinterpret_cast<const char*>(profile.stdev.data()), static_cast<std::streamsize>(sizeof(float) * profile.stdev.size()));
        out.write(reinterpret_cast<const char*>(profile.groupMean.data()), static_cast<std::streamsize>(sizeof(float) * profile.groupMean.size()));
        out.write(reinterpret_cast<const char*>(profile.groupCount.data()), static_cast<std::streamsize>(sizeof(uint32_t) * profile.groupCount.size()));
        out.write(reinterpret_cast<const char*>(profile.prototypes.data()), static_cast<std::streamsize>(sizeof(float) * profile.prototypes.size()));
        out.write(reinterpret_cast<const char*>(profile.protoCount.data()), static_cast<std::streamsize>(sizeof(uint32_t) * profile.protoCount.size()));
        out.write(reinterpret_cast<const char*>(profile.pcaBasis.data()), static_cast<std::streamsize>(sizeof(float) * profile.pcaBasis.size()));
        out.write(reinterpret_cast<const char*>(profile.pcaScale.data()), static_cast<std::streamsize>(sizeof(float) * profile.pcaScale.size()));
        out.flush();
        if (!out) {
            out.close();
            std::remove(tempPath.c_str());
            error = "Failed writing professional voice profile";
            return 31;
        }
        out.close();
        if (!out) {
            std::remove(tempPath.c_str());
            error = "Failed closing professional voice profile";
            return 31;
        }
    }

    ProfileV3 verified{};
    std::string verifyError;
    if (!readProfileV3(tempPath, verified, verifyError)) {
        std::remove(tempPath.c_str());
        error = "Self-check failed after training: " + verifyError;
        return 32;
    }

    std::remove(profilePath.c_str());
    if (std::rename(tempPath.c_str(), profilePath.c_str()) != 0) {
        std::remove(tempPath.c_str());
        error = "Failed installing validated trained voice profile";
        return 33;
    }

    gTrainingProgress.store(1.0f, std::memory_order_relaxed);
    return 0;
}

float VoiceProfileEngine::trainingProgress() {
    return std::clamp(gTrainingProgress.load(std::memory_order_relaxed), 0.0f, 1.0f);
}

void VoiceProfileEngine::cancelTraining() {
    gCancelTraining.store(true, std::memory_order_relaxed);
}

int VoiceProfileEngine::apply(const std::string& inputPath, const std::string& outputPath,
                              const std::string& profilePath, float strength, std::string& error) {
    strength = std::clamp(strength, 0.0f, 1.0f);
    if (!isV3(profilePath)) {
        // Backward compatibility: convert V1's 64-band mean into a lightweight V2-like target during application.
        HeaderV1 h{};
        std::array<float, BANDS_V1> old{};
        if (!readProfileV1(profilePath, h, old, error)) return 30;
        AudioBuffer b;
        if (!WavIO::readMonoFloat(inputPath, b, error)) return 10;
        std::vector<float> audio = b.sampleRate == OUT_SR ? b.mono : WavIO::resampleSinc(b.mono, b.sampleRate, OUT_SR);
        if (audio.size() < N) { error = "Audio is too short for trained voice profile"; return 11; }
        const auto window = makeWindow();
        const int frames = 1 + static_cast<int>((audio.size() + HOP - 1) / HOP);
        std::vector<float> output(audio.size() + N, 0.0f), weight(audio.size() + N, 0.0f);
        std::vector<std::complex<float>> spec(N);
        for (int f = 0; f < frames; ++f) {
            const int start = f * HOP - N / 2;
            for (int i = 0; i < N; ++i) {
                const int idx = start + i;
                const float x = idx >= 0 && idx < static_cast<int>(audio.size()) ? audio[static_cast<size_t>(idx)] : 0.0f;
                spec[static_cast<size_t>(i)] = {x * window[static_cast<size_t>(i)], 0.0f};
            }
            fft(spec, false);
            std::array<double, BANDS_V1> power{};
            for (int k = 1; k <= HALF; ++k) {
                const float hz = static_cast<float>(k) * OUT_SR / N;
                if (hz < 70.0f || hz > 16000.0f) continue;
                power[static_cast<size_t>(bandForHz(hz, BANDS_V1))] += std::norm(spec[static_cast<size_t>(k)]) + 1e-12;
            }
            std::array<float, BANDS_V1> src{};
            for (int j = 0; j < BANDS_V1; ++j) src[static_cast<size_t>(j)] = 0.5f * std::log(static_cast<float>(power[static_cast<size_t>(j)] + 1e-10));
            const float mean = std::accumulate(src.begin() + 4, src.end() - 6, 0.0f) / static_cast<float>(BANDS_V1 - 10);
            for (int k = 1; k <= HALF; ++k) {
                const float hz = static_cast<float>(k) * OUT_SR / N;
                const float pos = bandPosition(hz, BANDS_V1);
                const int a = std::clamp(static_cast<int>(std::floor(pos)), 0, BANDS_V1 - 1);
                const int c = std::min(BANDS_V1 - 1, a + 1);
                const float t = pos - a;
                const float deltaA = std::clamp(old[static_cast<size_t>(a)] - (src[static_cast<size_t>(a)] - mean), -1.0f, 1.0f);
                const float deltaC = std::clamp(old[static_cast<size_t>(c)] - (src[static_cast<size_t>(c)] - mean), -1.0f, 1.0f);
                const float g = std::exp((deltaA * (1.0f - t) + deltaC * t) * strength * 0.78f);
                spec[static_cast<size_t>(k)] *= g;
                if (k < HALF) spec[static_cast<size_t>(N - k)] *= g;
            }
            fft(spec, true);
            for (int i = 0; i < N; ++i) {
                const int idx = start + i;
                if (idx < 0 || idx >= static_cast<int>(output.size())) continue;
                const float w = window[static_cast<size_t>(i)];
                output[static_cast<size_t>(idx)] += spec[static_cast<size_t>(i)].real() * w;
                weight[static_cast<size_t>(idx)] += w * w;
            }
        }
        for (size_t i = 0; i < audio.size(); ++i) {
            const float wet = output[i] / std::max(weight[i], 1e-6f);
            audio[i] = std::clamp(0.18f * audio[i] + 0.82f * wet, -1.0f, 1.0f);
        }
        return WavIO::writeMono24(outputPath, audio, OUT_SR, error) ? 0 : 20;
    }

    ProfileV3 p{};
    if (!readProfileV3(profilePath, p, error)) return 30;
    AudioBuffer b;
    if (!WavIO::readMonoFloat(inputPath, b, error)) return 10;
    std::vector<float> audio = b.sampleRate == OUT_SR ? b.mono : WavIO::resampleSinc(b.mono, b.sampleRate, OUT_SR);
    if (audio.size() < N) { error = "Audio is too short for professional voice profile"; return 11; }
    if (strength < 0.01f) return WavIO::writeMono24(outputPath, audio, OUT_SR, error) ? 0 : 20;

    const auto window = makeWindow();
    const int frames = 1 + static_cast<int>((audio.size() + HOP - 1) / HOP);
    std::vector<float> output(audio.size() + N, 0.0f), weight(audio.size() + N, 0.0f);
    std::vector<std::complex<float>> spec(N);
    std::vector<float> mag;
    std::array<float, BANDS> prevGain{};
    prevGain.fill(1.0f);
    gLastEffectDb.store(0.0f, std::memory_order_relaxed);

    // Source-reference pass: estimate the source speaker's long-term spectral envelope.
    // Subtracting this from the target profile is the core of the identity transfer: it
    // changes the speaker coloration while retaining each frame's phonetic residual.
    RunningStats sourceGlobalStats;
    std::array<RunningStats, GROUPS> sourceGroupStats{};
    {
        std::vector<std::complex<float>> analysisSpec(N);
        std::vector<float> analysisMag;
        for (int f = 0; f < frames; ++f) {
            const int start = f * HOP - N / 2;
            std::array<float, N> frame{};
            for (int i = 0; i < N; ++i) {
                const int idx = start + i;
                frame[static_cast<size_t>(i)] = idx >= 0 && idx < static_cast<int>(audio.size())
                    ? audio[static_cast<size_t>(idx)] : 0.0f;
            }
            const FrameFeatures ff = analyzeFrame(frame.data(), OUT_SR, window, analysisSpec, analysisMag);
            if (ff.rms < 0.0012f) continue;
            sourceGlobalStats.add(ff.env);
            sourceGroupStats[static_cast<size_t>(ff.group)].add(ff.env);
        }
    }
    if (sourceGlobalStats.count < 8) {
        error = "Not enough active source voice for trained profile transfer";
        return 12;
    }
    std::array<float, BANDS> sourceMean{};
    std::array<float, GROUPS * BANDS> sourceGroupMean{};
    for (int band = 0; band < BANDS; ++band) {
        sourceMean[static_cast<size_t>(band)] =
            static_cast<float>(sourceGlobalStats.mean[static_cast<size_t>(band)]);
    }
    for (int group = 0; group < GROUPS; ++group) {
        for (int band = 0; band < BANDS; ++band) {
            sourceGroupMean[static_cast<size_t>(group * BANDS + band)] =
                sourceGroupStats[static_cast<size_t>(group)].count >= 6
                    ? static_cast<float>(sourceGroupStats[static_cast<size_t>(group)].mean[static_cast<size_t>(band)])
                    : sourceMean[static_cast<size_t>(band)];
        }
    }

    double effectDbSum = 0.0;
    uint64_t effectDbCount = 0;

    for (int f = 0; f < frames; ++f) {
        const int start = f * HOP - N / 2;
        std::array<float, N> frame{};
        for (int i = 0; i < N; ++i) {
            const int idx = start + i;
            frame[static_cast<size_t>(i)] = idx >= 0 && idx < static_cast<int>(audio.size()) ? audio[static_cast<size_t>(idx)] : 0.0f;
        }
        FrameFeatures ff = analyzeFrame(frame.data(), OUT_SR, window, spec, mag);
        const int g = ff.group;
        const bool targetGroupUsable = p.groupCount[static_cast<size_t>(g)] >= 12;
        const float* targetBase = targetGroupUsable
            ? &p.groupMean[static_cast<size_t>(g * BANDS)]
            : p.mean.data();
        const float* sourceBase = &sourceGroupMean[static_cast<size_t>(g * BANDS)];

        std::array<float, BANDS> sourceResidual{};
        for (int band = 0; band < BANDS; ++band) {
            sourceResidual[static_cast<size_t>(band)] =
                ff.env[static_cast<size_t>(band)] - sourceBase[band];
        }

        // Choose the target prototype by residual shape, not absolute speaker coloration.
        // This maps similar phonetic/formant states across speakers instead of selecting the
        // prototype merely because its average spectrum happens to resemble the source.
        int nearest = -1;
        float nearestD = std::numeric_limits<float>::max();
        const int protoStart = g * PROTOS_PER_GROUP;
        for (int j = 0; j < PROTOS_PER_GROUP; ++j) {
            const int idx = protoStart + j;
            if (p.protoCount[static_cast<size_t>(idx)] == 0) continue;
            double d = 0.0, wsum = 0.0;
            const float* proto = &p.prototypes[static_cast<size_t>(idx * BANDS)];
            for (int band = 3; band < BANDS - 6; ++band) {
                const float pos = static_cast<float>(band) / static_cast<float>(BANDS - 1);
                const double w = 0.65 + 0.70 * std::sin(3.14159265358979323846 * pos);
                const double targetResidual = static_cast<double>(proto[band] - targetBase[band]);
                const double e = targetResidual - static_cast<double>(sourceResidual[static_cast<size_t>(band)]);
                d += w * e * e;
                wsum += w;
            }
            const float score = static_cast<float>(d / std::max(wsum, 1e-9));
            if (score < nearestD) { nearestD = score; nearest = idx; }
        }

        std::array<float, BANDS> protoResidual{};
        if (nearest >= 0) {
            const float* proto = &p.prototypes[static_cast<size_t>(nearest * BANDS)];
            for (int band = 0; band < BANDS; ++band) {
                protoResidual[static_cast<size_t>(band)] = proto[band] - targetBase[band];
            }
        } else {
            protoResidual = sourceResidual;
        }

        // Project the source phonetic residual into the target speaker's learned manifold.
        std::array<float, BANDS> pcaResidual{};
        for (int c = 0; c < PCA_COMPONENTS; ++c) {
            const float scale = p.pcaScale[static_cast<size_t>(c)];
            if (!(scale > 1e-5f)) continue;
            double coeff = 0.0;
            for (int band = 0; band < BANDS; ++band) {
                coeff += static_cast<double>(p.pcaBasis[static_cast<size_t>(c * BANDS + band)]) *
                         static_cast<double>(sourceResidual[static_cast<size_t>(band)]);
            }
            const float clampedCoeff = std::clamp(static_cast<float>(coeff), -2.5f * scale, 2.5f * scale);
            for (int band = 0; band < BANDS; ++band) {
                pcaResidual[static_cast<size_t>(band)] +=
                    p.pcaBasis[static_cast<size_t>(c * BANDS + band)] * clampedCoeff;
            }
        }

        const float identity = std::pow(std::clamp(strength, 0.0f, 1.0f), 0.72f);
        const float sourceResidualWeight = 0.50f - 0.18f * identity;
        const float protoResidualWeight = 0.28f + 0.18f * identity;
        const float pcaResidualWeight = 1.0f - sourceResidualWeight - protoResidualWeight;

        std::array<float, BANDS> target{};
        for (int band = 0; band < BANDS; ++band) {
            const float residual =
                sourceResidualWeight * sourceResidual[static_cast<size_t>(band)] +
                protoResidualWeight * protoResidual[static_cast<size_t>(band)] +
                pcaResidualWeight * pcaResidual[static_cast<size_t>(band)];
            target[static_cast<size_t>(band)] = targetBase[band] + residual;
        }

        std::array<float, BANDS> delta{};
        const float identityBoost = 1.00f + 0.34f * identity;
        for (int band = 0; band < BANDS; ++band) {
            delta[static_cast<size_t>(band)] =
                (target[static_cast<size_t>(band)] - ff.env[static_cast<size_t>(band)]) * identityBoost;
        }
        auto rawDelta = delta;
        for (int band = 0; band < BANDS; ++band) {
            double s = 0.0, w = 0.0;
            for (int d = -3; d <= 3; ++d) {
                const int j = std::clamp(band + d, 0, BANDS - 1);
                const double ww = 4.0 - std::abs(d);
                s += rawDelta[static_cast<size_t>(j)] * ww;
                w += ww;
            }
            delta[static_cast<size_t>(band)] = static_cast<float>(s / w);
        }

        // Speech protection remains frequency- and articulation-aware. Voiced regions receive
        // the full identity transfer; consonant/noise-rich frames keep more of the source so
        // pronunciation stays crisp. The activity curve is deliberately more sensitive than
        // v1.6.0 so normal/quiet recordings do not silently lose most of the effect.
        float articulationProtect = ff.voiced ? 1.0f : 0.38f;
        articulationProtect *= std::clamp(1.08f - ff.highRatio * 0.88f, 0.42f, 1.0f);
        const float activity = std::clamp((ff.rms - 0.0008f) / 0.0085f, 0.0f, 1.0f);
        for (int band = 0; band < BANDS; ++band) {
            float bandStrength = strength * articulationProtect * activity;
            if (band < 4) bandStrength *= 0.30f;
            if (band > BANDS - 9) bandStrength *= 0.58f;
            float d = std::clamp(delta[static_cast<size_t>(band)], -1.18f, 1.18f) * bandStrength;
            if (activity > 0.12f && band >= 4 && band < BANDS - 8) {
                effectDbSum += std::abs(static_cast<double>(d)) * 8.685889638;
                ++effectDbCount;
            }
            const float desired = std::exp(d);
            const float attack = desired < prevGain[static_cast<size_t>(band)] ? 0.50f : 0.82f;
            prevGain[static_cast<size_t>(band)] = std::clamp(
                attack * prevGain[static_cast<size_t>(band)] + (1.0f - attack) * desired, 0.40f, 2.55f);
        }

        for (int k = 1; k <= HALF; ++k) {
            const float hz = static_cast<float>(k) * OUT_SR / N;
            const float pos = bandPosition(hz, BANDS);
            const int a = std::clamp(static_cast<int>(std::floor(pos)), 0, BANDS - 1);
            const int c = std::min(BANDS - 1, a + 1);
            const float t = pos - a;
            const float gain = prevGain[static_cast<size_t>(a)] * (1.0f - t) + prevGain[static_cast<size_t>(c)] * t;
            spec[static_cast<size_t>(k)] *= gain;
            if (k < HALF) spec[static_cast<size_t>(N - k)] *= gain;
        }
        fft(spec, true);
        for (int i = 0; i < N; ++i) {
            const int idx = start + i;
            if (idx < 0 || idx >= static_cast<int>(output.size())) continue;
            const float w = window[static_cast<size_t>(i)];
            output[static_cast<size_t>(idx)] += spec[static_cast<size_t>(i)].real() * w;
            weight[static_cast<size_t>(idx)] += w * w;
        }
    }

    for (size_t i = 0; i < audio.size(); ++i) {
        const float wet = output[i] / std::max(weight[i], 1e-6f);
        // Articulation has already been protected in the spectral domain. High strengths may
        // therefore use an almost fully-wet path without losing consonant clarity.
        const float wetMix = 0.80f + 0.20f * std::pow(strength, 0.62f);
        audio[i] = std::clamp(audio[i] * (1.0f - wetMix) + wet * wetMix, -1.0f, 1.0f);
    }
    gLastEffectDb.store(effectDbCount > 0
        ? static_cast<float>(effectDbSum / static_cast<double>(effectDbCount))
        : 0.0f, std::memory_order_relaxed);
    return WavIO::writeMono24(outputPath, audio, OUT_SR, error) ? 0 : 20;
}

float VoiceProfileEngine::lastEffectDb() {
    return std::max(0.0f, gLastEffectDb.load(std::memory_order_relaxed));
}

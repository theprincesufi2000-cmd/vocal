# v1.6.0 Timbre Transfer Hotfix

- `versionCode` bumped to 14 while keeping `versionName = "1.6.0"`.
- Replaced the weak source-conditioned transfer with a source-reference pass that estimates the current speaker envelope before applying the trained identity.
- Target prototypes are selected by phonetic residual shape rather than absolute spectral colour.
- Target PCA is now used as a pronunciation/articulation manifold instead of dominating the speaker identity.
- Stronger wet path and activity curve make 85–100% settings audibly effective while consonant/high-frequency protection remains active.
- Default local-profile strength changed to 90%, with Natural 75%, Match 90%, and Max 100% shortcuts.
- Added `voiceProfileLastEffectDb()` and completion status such as `VSPTRAIN Δ5.2 dB` so the user can verify that the trained profile actually changed the active spectral envelope.
- Added a regression smoke test that fails CI if a spectrally different source receives less than 0.75 dB average active-band timbre transfer.

# v1.6.0 ProTrainingSuite Hotfix

- Fixed real-world VSPTRAIN3 validation failures caused by an overly strict spectral-envelope bound that could reject valid trained voices.
- Spectral envelopes are now sanitized/clamped before serialization and validated with realistic structural limits.
- Added atomic `.tmp` training output, flush/close self-check, and verified rename so interrupted training never installs a partial profile.
- Added detailed native training/validation diagnostics through `voiceProfileLastError()`.
- Training manager now removes invalid partial profiles and reports the real native cause instead of only `نموذج VSPTRAIN غير صالح`.
- `versionCode` bumped to 13 while keeping `versionName = "1.6.0"` for an in-place hotfix update.

# Changelog

## 1.6.0 — Pro Training Suite

- Added native multi-recording training for up to 64 clips / 50 minutes.
- Added independent noise-floor and voice-activity gating for every source recording.
- Fixed clean-duration accounting across datasets with different sample rates.
- Added JNI profile inspection and measured quality reporting in the UI.
- Added native progress reporting and safe cancellation for long training sessions.
- Added training presets and a multi-document Android picker.
- Added `.vspmodel` VSPMODEL2 import/export with metadata and SHA-256 verification.
- Added `.vspdataset` export for lossless hand-off to GPU RVC training.
- Added self-contained `.vspvoice` export with shared ContentVec/RMVPE core embedding.
- Added per-payload SHA-256 verification for portable VSPVOICE imports.
- Added `tools/vsp_package_tool.py` and a native multi-clip smoke test.
- Version bumped to `1.6.0` / `versionCode 12`.

## 1.5.0 — Pro Training 50m

- Replaced the simple 64-band VSPTRAIN1 trainer with backward-compatible **VSPTRAIN3**.
- Added streaming training for source recordings up to **50 minutes** without loading the full file into RAM.
- Added 96-band normalized vocal-envelope learning.
- Added voiced/unvoiced separation and four pitch-register models.
- Added 30 adaptive target-envelope prototypes using online clustering.
- Added input noise-floor, clipping and clean-voice analysis.
- Added pronunciation protection for consonant/unvoiced frames during application.
- Added bounded temporal/frequency smoothing and dry articulation preservation.
- VSPTRAIN1 files remain importable/applicable.
- Updated UI copy and long-training status messages.
- Version bumped to `1.5.0` / `versionCode 11`.

## 1.4.0 — Saved Voice Training

- Added reusable local `.vsptrain` profiles and import/export.

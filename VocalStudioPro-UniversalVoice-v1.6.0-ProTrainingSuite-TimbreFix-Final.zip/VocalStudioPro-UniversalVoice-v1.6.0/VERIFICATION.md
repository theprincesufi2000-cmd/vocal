## v1.6.0 Timbre Transfer Hotfix regression

- Full native source + JNI compile: `-Wall -Wextra -Werror` PASS.
- Existing VSPTRAIN3 validity/range regression: PASS.
- New source-referenced identity-transfer smoke test: PASS.
- Synthetic contrast source at 90% produced ~6.4 dB average active-band timbre shift before mastering.
- Full profile → Studio Master path test produced ~5.2 dB measured trained-profile shift and a valid 48 kHz / 24-bit WAV.
- Previous trained VSPTRAIN3 files remain binary-compatible; retraining is not required.

## v1.6.0 ProTrainingSuite Hotfix regression

The training validator bug reported on-device was reproduced before the fix with valid spectral profiles whose learned envelope exceeded the old arbitrary `±8` bound (for example, the 400 Hz / 3 kHz / 6 kHz / 10 kHz stress fixtures).

After the fix:

- all stress fixtures train successfully and immediately pass `VoiceProfileEngine::validate()`;
- the learned envelope can legitimately exceed `8.0` while remaining finite and structurally safe;
- truncated VSPTRAIN3 files are still rejected;
- VSPTRAIN1 backward compatibility remains valid;
- the final profile is written to `.tmp`, flushed, closed, self-validated, then atomically renamed;
- C++/JNI compiles with `-Wall -Wextra -Werror`.

# Vocal Studio Pro 1.6.0 — Verification

- versionName: 1.6.0
- versionCode: 12
- C++/JNI strict compile: tested with `-Wall -Wextra -Werror`.
- VSPTRAIN3 multi-clip train/inspect/validate/apply: tested end-to-end on the host toolchain.
- Training source smoke test: two independent 4 s / 48 kHz / PCM24 clips.
- Output: 48 kHz / PCM24 with source frame count preserved.
- Profile size in synthetic test: ~19 KB.
- 50-minute hard limit: verified via header/duration validation; 50:01 is rejected before processing.
- Existing RVC/Applio adaptive-frame engine retained.

A full Android `assembleRelease` is delegated to the included GitHub Actions workflow when the local environment does not contain the Android SDK/Maven dependency set.

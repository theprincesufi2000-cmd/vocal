#!/usr/bin/env python3
"""Inspect, verify and safely extract VocalStudioPro portable packages."""

from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import shutil
import sys
import zipfile


def digest(stream) -> str:
    value = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        value.update(chunk)
    return value.hexdigest()


def safe_name(name: str) -> pathlib.PurePosixPath:
    path = pathlib.PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name:
        raise ValueError(f"unsafe ZIP path: {name}")
    return path


def load_json(package: zipfile.ZipFile, name: str) -> dict:
    info = package.getinfo(name)
    if info.file_size > 1024 * 1024:
        raise ValueError(f"{name} is unexpectedly large")
    with package.open(info) as stream:
        return json.load(stream)


def expected_payloads(package: zipfile.ZipFile) -> tuple[str, dict[str, str]]:
    names = set(package.namelist())
    if "manifest.json" in names:
        manifest = load_json(package, "manifest.json")
        kind = manifest.get("format", "")
        if kind == "VSPMODEL2":
            return kind, {manifest["profileFile"]: manifest["sha256"]}
        if kind == "VSPDATASET1":
            return kind, {item["file"]: item["sha256"] for item in manifest.get("audio", [])}
        raise ValueError(f"unsupported manifest format: {kind!r}")
    if "metadata.json" in names:
        metadata = load_json(package, "metadata.json")
        if metadata.get("format") not in {"VSPVOICE", "VSPVOICE-AUTO"}:
            raise ValueError("unsupported VSPVOICE metadata")
        return "VSPVOICE", dict(metadata.get("payloadSha256", {}))
    raise ValueError("package has no recognized manifest")


def verify(path: pathlib.Path) -> tuple[str, int]:
    with zipfile.ZipFile(path) as package:
        for info in package.infolist():
            safe_name(info.filename)
        kind, expected = expected_payloads(package)
        if not expected:
            raise ValueError("package does not contain a checksum table")
        for name, wanted in expected.items():
            safe_name(name)
            if not isinstance(wanted, str) or len(wanted) != 64:
                raise ValueError(f"invalid SHA-256 value for {name}")
            with package.open(name) as stream:
                actual = digest(stream)
            if actual.lower() != wanted.lower():
                raise ValueError(f"SHA-256 mismatch for {name}")
        return kind, len(expected)


def extract(path: pathlib.Path, destination: pathlib.Path) -> None:
    verify(path)
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with zipfile.ZipFile(path) as package:
        for info in package.infolist():
            relative = safe_name(info.filename)
            target = (destination / pathlib.Path(*relative.parts)).resolve()
            if root != target and root not in target.parents:
                raise ValueError(f"unsafe extraction target: {info.filename}")
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with package.open(info) as source, target.open("wb") as output:
                    shutil.copyfileobj(source, output, 1024 * 1024)


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    check = sub.add_parser("verify")
    check.add_argument("package", type=pathlib.Path)
    unpack = sub.add_parser("extract")
    unpack.add_argument("package", type=pathlib.Path)
    unpack.add_argument("destination", type=pathlib.Path)
    args = parser.parse_args()
    try:
        if args.command == "verify":
            kind, count = verify(args.package)
            print(f"PASS {kind}: {count} payload(s) verified")
        else:
            extract(args.package, args.destination)
            print(f"PASS extracted to {args.destination}")
        return 0
    except (OSError, KeyError, ValueError, zipfile.BadZipFile, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

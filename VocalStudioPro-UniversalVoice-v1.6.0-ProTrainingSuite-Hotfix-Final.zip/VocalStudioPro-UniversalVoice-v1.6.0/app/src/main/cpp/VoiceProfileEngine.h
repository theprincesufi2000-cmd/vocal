#pragma once
#include <string>
#include <vector>

struct VoiceProfileMetrics {
    int version = 0;
    float sourceSeconds = 0.0f;
    float cleanSeconds = 0.0f;
    float qualityScore = 0.0f;
    float clippingRatio = 0.0f;
    float noiseFloorDb = -90.0f;
    float medianF0 = 0.0f;
    float voicedRatio = 0.0f;
    float spectralCentroid = 0.0f;
    unsigned long long analyzedFrames = 0;
};

class VoiceProfileEngine {
public:
    static int train(const std::string& inputPath, const std::string& profilePath, std::string& error);
    static int trainMany(const std::vector<std::string>& inputPaths,
                         const std::string& profilePath,
                         std::string& error);
    static int apply(const std::string& inputPath, const std::string& outputPath,
                     const std::string& profilePath, float strength, std::string& error);
    static int validate(const std::string& profilePath, std::string& error);
    static int inspect(const std::string& profilePath, VoiceProfileMetrics& metrics, std::string& error);
    static float trainingProgress();
    static void cancelTraining();
};

package com.mustafa.vocalstudio.voice

import java.io.File

data class TrainedVoiceProfile(
    val id: String,
    val name: String,
    val file: File,
    val createdAt: Long,
    val sourceSeconds: Float,
    val sourceCount: Int = 1,
    val format: String = "VSPTRAIN3",
    val cleanSeconds: Float = 0f,
    val qualityScore: Float = 0f,
    val clippingRatio: Float = 0f,
    val noiseFloorDb: Float = -90f,
    val medianF0: Float = 0f,
    val voicedRatio: Float = 0f,
    val spectralCentroid: Float = 0f,
    val sha256: String = ""
) {
    val cleanRatio: Float
        get() = if (sourceSeconds > 0f) (cleanSeconds / sourceSeconds).coerceIn(0f, 1f) else 0f

    val qualityLabel: String
        get() = when {
            qualityScore >= 85f -> "ممتاز"
            qualityScore >= 70f -> "جيد جدًا"
            qualityScore >= 55f -> "جيد"
            qualityScore > 0f -> "يحتاج تحسين"
            else -> "غير مقاس"
        }
}

enum class TrainingPreset(
    val title: String,
    val minimumRecommendedSeconds: Float,
    val description: String
) {
    QUICK("سريع", 5f, "اختبار تقني يبدأ من 5 ثوانٍ"),
    STUDIO("Studio", 180f, "يتطلب 3 دقائق نظيفة على الأقل"),
    ULTRA("Ultra", 600f, "يتطلب 10 دقائق ويحلل حتى 50 دقيقة")
}

data class TrainingAudioItem(
    val id: String,
    val displayName: String,
    val file: File,
    val durationSeconds: Float,
    val sampleRate: Int,
    val channels: Int
)

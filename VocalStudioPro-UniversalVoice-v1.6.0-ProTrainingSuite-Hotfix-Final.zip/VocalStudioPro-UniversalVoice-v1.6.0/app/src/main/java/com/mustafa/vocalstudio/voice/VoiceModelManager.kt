package com.mustafa.vocalstudio.voice

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.net.HttpURLConnection
import java.net.URI
import java.util.LinkedHashMap
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Universal local model importer.
 *
 * Directly runnable formats:
 *  - .vspvoice (ZIP based)
 *  - ZIP containing RVC ONNX voice + ContentVec/HuBERT ONNX (+ optional pitch ONNX)
 *  - standalone RVC voice ONNX when a shared Content encoder has already been imported
 *
 * Accepted/catalogued but not directly executable by ONNX Runtime:
 *  - RVC PyTorch checkpoint .pth (+ optional .index), including those inside ZIP files.
 *
 * Raw .pth checkpoints are state dictionaries, not executable ONNX/TorchScript graphs. The
 * importer therefore preserves them and marks them CONVERSION_REQUIRED instead of failing.
 */
class VoiceModelManager(private val context: Context) {
    data class ImportResult(
        val model: VoiceModel?,
        val message: String,
        val coreInstalled: Boolean = false
    )

    private val root = File(context.filesDir, "voice_models").apply { mkdirs() }
    private val coreRoot = File(root, "_core").apply { mkdirs() }

    fun listModels(): List<VoiceModel> = root.listFiles()
        ?.filter { it.isDirectory && !it.name.startsWith(".") && it.name != "_core" }
        ?.mapNotNull { runCatching { VoiceModel.fromDirectory(it) }.getOrNull() }
        ?.sortedWith(compareByDescending<VoiceModel> { it.isReady }.thenBy { it.name.lowercase() })
        ?: emptyList()

    fun importAny(uri: Uri, rightsConfirmed: Boolean): ImportResult {
        require(rightsConfirmed) { "أكد أولًا أن لديك حق استخدام النموذج الصوتي" }
        val displayName = queryDisplayName(uri) ?: "voice-model-${System.currentTimeMillis()}"
        val staging = File(root, ".import-${System.nanoTime()}").apply { mkdirs() }
        val normalized = File(root, ".normalized-${System.nanoTime()}").apply { mkdirs() }

        try {
            if (looksLikeZip(uri, displayName)) {
                extractSecure(uri, staging)
            } else {
                val target = File(staging, sanitizeFileName(displayName))
                copyUri(uri, target)
            }

            // Existing VSPVOICE package, even if wrapped in an extra folder.
            findVspMetadata(staging)?.let { metadata ->
                verifyPortablePayloads(metadata)
                moveDirectoryContents(metadata.parentFile ?: staging, normalized)
                val model = installNormalized(normalized)
                staging.deleteRecursively()
                return ImportResult(model, "تم استيراد ${model.name} · ${model.stateLabel()}")
            }

            val files = staging.walkTopDown().filter { it.isFile }.toList()
            require(files.isNotEmpty()) { "الملف أو ZIP فارغ" }

            val onnxFiles = files.filter { it.extension.equals("onnx", true) || it.extension.equals("ort", true) }
            val pthFiles = files.filter { it.extension.equals("pth", true) || it.extension.equals("pt", true) }
            val indexFiles = files.filter { it.extension.equals("index", true) }

            if (onnxFiles.isNotEmpty()) {
                val onnxResult = importOnnxBundle(
                    displayName = displayName,
                    onnxFiles = onnxFiles,
                    checkpoint = pthFiles.maxByOrNull { it.length() },
                    index = indexFiles.maxByOrNull { it.length() },
                    normalized = normalized
                )
                staging.deleteRecursively()
                if (onnxResult != null) return onnxResult
            }

            if (pthFiles.isNotEmpty()) {
                val checkpoint = pthFiles.maxByOrNull { it.length() }!!
                val index = indexFiles.maxByOrNull { it.length() }
                moveLarge(checkpoint, File(normalized, "model.pth"))
                if (index != null) moveLarge(index, File(normalized, "model.index"))

                val inferredVersion = inferRvcVersion(files.map { it.name }, checkpoint.name)
                val channels = if (inferredVersion == 1) 256 else 768
                val inferredSr = inferSampleRateOrNull(files.map { it.name })
                val sr = inferredSr ?: 40_000
                writeMetadata(
                    dir = normalized,
                    displayName = displayName,
                    sourceFormat = VoiceSourceFormat.RVC_PYTORCH,
                    state = VoiceModelState.CONVERSION_REQUIRED,
                    engine = "rvc-pytorch-v$inferredVersion",
                    sampleRate = sr,
                    sampleRateKnown = inferredSr != null,
                    featureChannels = channels,
                    contentModelName = "",
                    pitchModelName = "",
                    voiceModelName = "",
                    checkpointName = "model.pth",
                    indexName = if (index != null) "model.index" else "",
                    statusDetail = "تم استيراد checkpoint RVC. ملف .pth الخام ليس graph قابلًا للتنفيذ بواسطة ONNX Runtime؛ يلزم تصدير voice.onnx مرة واحدة."
                )
                val model = installNormalized(normalized)
                staging.deleteRecursively()
                return ImportResult(
                    model,
                    "تم حفظ نموذج RVC (${checkpoint.name})${if (index != null) " مع INDEX" else ""}. يحتاج تحويل ONNX قبل التشغيل."
                )
            }

            if (indexFiles.isNotEmpty()) {
                error("تم العثور على .index فقط. ملف INDEX ليس نموذج صوت بمفرده؛ أضف معه .pth أو voice.onnx داخل ZIP واحد")
            }

            error("لم يتم العثور على نموذج مدعوم داخل الملف. يدعم المستورد VSPVOICE وONNX/ORT وRVC PTH/INDEX وZIP التي تحتويها")
        } catch (t: Throwable) {
            staging.deleteRecursively()
            normalized.deleteRecursively()
            throw t
        }
    }

    fun hasSharedRvcV2Core(): Boolean = File(coreRoot, "content_encoder.onnx").let {
        it.isFile && it.length() > 1_000_000
    }

    /**
     * Downloads the shared 768-channel RVC v2 ContentVec core once. The per-voice ONNX stays
     * separate and small model installs reference this file through @core/content_encoder.onnx.
     * RMVPE is intentionally optional because the native F0 extractor remains available.
     */
    fun downloadSharedRvcV2Core(onProgress: (Float) -> Unit = {}): String {
        val finalFile = File(coreRoot, "content_encoder.onnx")
        if (finalFile.isFile && finalFile.length() > 1_000_000) {
            refreshModelsWaitingForCore()
            return "RVC v2 Core مثبت مسبقًا"
        }

        val temp = File(coreRoot, ".contentvec-v2-${System.nanoTime()}.part")
        val url = "https://huggingface.co/TigreGotico/voiceclonnx-rvc/resolve/main/contentvec_768l12_q8.onnx?download=true"
        try {
            downloadHttps(url, temp, 180_000_000L, onProgress)
            require(temp.length() in 50_000_000L..180_000_000L) { "حجم RVC Core غير متوقع" }
            val probe = OnnxModelProbe.inspect(temp)
            require(probe.kind == OnnxModelProbe.Kind.CONTENT) { "الملف المحمل ليس Content Encoder صالحًا" }
            require(probe.featureChannels == null || probe.featureChannels == 768) {
                "RVC Core لا يخرج 768 feature channel"
            }
            if (finalFile.exists()) finalFile.delete()
            require(temp.renameTo(finalFile) || runCatching {
                copyLarge(temp, finalFile)
                temp.delete()
                true
            }.getOrDefault(false)) { "تعذر تثبيت RVC Core" }
            refreshModelsWaitingForCore()
            onProgress(1f)
            return "تم تثبيت RVC v2 Core وأصبحت نماذج ONNX المنتظرة جاهزة"
        } finally {
            if (temp.exists()) temp.delete()
        }
    }

    private fun downloadHttps(
        initialUrl: String,
        target: File,
        maxBytes: Long,
        onProgress: (Float) -> Unit
    ) {
        var current = initialUrl
        var redirects = 0
        while (true) {
            require(redirects <= 8) { "عدد تحويلات رابط التنزيل كبير جدًا" }
            val connection = (URI.create(current).toURL().openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 45_000
                instanceFollowRedirects = false
                requestMethod = "GET"
                setRequestProperty("User-Agent", "VocalStudioPro/1.6.0 Android")
                setRequestProperty("Accept", "application/octet-stream,*/*")
            }
            try {
                val code = connection.responseCode
                if (code in 300..399) {
                    val location = connection.getHeaderField("Location")
                        ?: error("رابط تنزيل Core أعاد تحويلًا بدون Location")
                    current = URI.create(current).resolve(location).toString()
                    redirects++
                    continue
                }
                require(code in 200..299) { "فشل تنزيل RVC Core: HTTP $code" }
                val expected = connection.contentLengthLong
                if (expected > 0) require(expected <= maxBytes) { "RVC Core أكبر من الحد المسموح" }
                target.parentFile?.mkdirs()
                connection.inputStream.buffered(512 * 1024).use { input ->
                    FileOutputStream(target).buffered(512 * 1024).use { output ->
                        val buffer = ByteArray(512 * 1024)
                        var total = 0L
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            total += n
                            require(total <= maxBytes) { "RVC Core أكبر من الحد المسموح" }
                            output.write(buffer, 0, n)
                            if (expected > 0) onProgress((total.toDouble() / expected.toDouble()).toFloat().coerceIn(0f, 0.99f))
                        }
                    }
                }
                require(target.isFile && target.length() > 1_000_000) { "تنزيل RVC Core غير مكتمل" }
                return
            } finally {
                connection.disconnect()
            }
        }
    }

    fun remove(model: VoiceModel) {
        if (model.directory.parentFile?.canonicalFile == root.canonicalFile) {
            model.directory.deleteRecursively()
        }
    }

    /**
     * Exports a self-contained VSPVOICE package. Shared ContentVec/RMVPE files are copied into
     * the package and metadata references are rewritten, so another device can import it without
     * redownloading the RVC core. A SHA-256 table protects every payload.
     */
    fun exportPortable(model: VoiceModel, uri: Uri) {
        model.validateInstalled()
        val metadataFile = File(model.directory, "metadata.json")
        val metadata = JSONObject(metadataFile.readText(Charsets.UTF_8))
            .put("format", "VSPVOICE")
            .put("formatVersion", 3)
            .put("packageFormat", "VSPVOICE-PORTABLE-1")
            .put("exportedAt", System.currentTimeMillis())

        val payloads = LinkedHashMap<String, File>()
        fun add(name: String, file: File) {
            if (name.isNotBlank() && file.isFile && file.length() > 0) payloads[name] = file
        }

        if (model.contentModelName.isNotBlank() && model.contentModel.isFile) {
            add("content_encoder.onnx", model.contentModel)
            metadata.put("contentModel", "content_encoder.onnx")
        }
        if (model.pitchModelName.isNotBlank() && model.pitchModel.isFile) {
            add("pitch.onnx", model.pitchModel)
            metadata.put("pitchModel", "pitch.onnx")
        }
        add("voice.onnx", model.voiceModel)
        if (model.voiceModel.isFile) metadata.put("voiceModel", "voice.onnx")
        add("model.pth", model.checkpointFile)
        if (model.checkpointFile.isFile) metadata.put("checkpoint", "model.pth")
        add("model.index", model.indexFile)
        if (model.indexFile.isFile) metadata.put("index", "model.index")
        add("cover.png", model.coverFile)

        val checksums = JSONObject()
        payloads.forEach { (name, file) -> checksums.put(name, sha256(file)) }
        metadata.put("payloadSha256", checksums)

        context.contentResolver.openOutputStream(uri, "w").use { raw ->
            requireNotNull(raw) { "تعذر فتح مكان حفظ حزمة النموذج" }
            ZipOutputStream(BufferedOutputStream(raw, 512 * 1024)).use { zip ->
                zip.setLevel(3)
                zip.putNextEntry(ZipEntry("metadata.json"))
                zip.write(metadata.toString(2).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                payloads.forEach { (name, file) ->
                    zip.putNextEntry(ZipEntry(name))
                    file.inputStream().buffered(512 * 1024).use { it.copyTo(zip, 512 * 1024) }
                    zip.closeEntry()
                }
            }
        }
    }

    private fun importOnnxBundle(
        displayName: String,
        onnxFiles: List<File>,
        checkpoint: File?,
        index: File?,
        normalized: File
    ): ImportResult? {
        val inspected = onnxFiles.map { file ->
            val result = runCatching { OnnxModelProbe.inspect(file) }
            Triple(file, result.getOrNull(), result.exceptionOrNull())
        }
        val probes = inspected.map { (file, probe, _) -> probe ?: OnnxModelProbe.guess(file) }

        var voice = probes.firstOrNull { it.kind == OnnxModelProbe.Kind.VOICE }
            ?: probes.firstOrNull {
                val n = it.file.name.lowercase(Locale.ROOT)
                n.contains("voice") || n.contains("rvc") || n.contains("synth") || n.contains("generator")
            }
        var content = probes.firstOrNull { it.kind == OnnxModelProbe.Kind.CONTENT && it.file != voice?.file }
        val pitch = probes.firstOrNull { it.kind == OnnxModelProbe.Kind.PITCH }

        // A standalone downloaded RVC voice is frequently named after the character/speaker
        // (for example Nova_HD.onnx) and may not include the words voice/rvc/model. If ORT
        // probing fails during import because of memory/provider limits, do not reject a valid
        // .onnx merely because its filename is arbitrary. Treat one otherwise-unknown ONNX as
        // the voice candidate unless it is clearly a ContentVec/RMVPE core model. Runtime will
        // still validate the graph before conversion.
        if (voice == null && onnxFiles.size == 1 && content == null && pitch == null) {
            val only = onnxFiles.single()
            val n = only.name.lowercase(Locale.ROOT)
            val clearlyCore = n.contains("hubert") || n.contains("content") || n.contains("vec") ||
                n.contains("encoder") || n.contains("rmvpe") || n.contains("pitch") || n.contains("f0")
            if (!clearlyCore) {
                voice = OnnxModelProbe.guess(only).copy(kind = OnnxModelProbe.Kind.VOICE)
            }
        }

        if (voice != null && content?.file == voice.file) content = null

        // A ZIP containing core models only installs the shared core automatically.
        if (voice == null && content != null && checkpoint == null) {
            moveLarge(content.file, File(coreRoot, "content_encoder.onnx"))
            if (pitch != null) moveLarge(pitch.file, File(coreRoot, "pitch.onnx"))
            refreshModelsWaitingForCore()
            normalized.deleteRecursively()
            return ImportResult(
                model = null,
                message = "تم تثبيت Content Encoder${if (pitch != null) " + Pitch" else ""} كـ Core مشترك. النماذج المنتظرة تم تحديثها تلقائيًا.",
                coreInstalled = true
            )
        }

        if (voice == null) return null

        moveLarge(voice.file, File(normalized, "voice.onnx"))
        if (index != null) moveLarge(index, File(normalized, "model.index"))
        if (checkpoint != null) moveLarge(checkpoint, File(normalized, "model.pth"))

        var contentProbe = content
        var pitchProbe = pitch
        if (contentProbe != null) {
            moveLarge(contentProbe.file, File(normalized, "content_encoder.onnx"))
        }
        if (pitchProbe != null) {
            moveLarge(pitchProbe.file, File(normalized, "pitch.onnx"))
        }

        val localContent = File(normalized, "content_encoder.onnx")
        val localPitch = File(normalized, "pitch.onnx")
        val sharedContent = File(coreRoot, "content_encoder.onnx")
        val sharedPitch = File(coreRoot, "pitch.onnx")
        val contentModelName = when {
            localContent.isFile && localContent.length() > 1024 -> "content_encoder.onnx"
            sharedContent.isFile && sharedContent.length() > 1024 -> "@core/content_encoder.onnx"
            else -> ""
        }
        val pitchModelName = when {
            localPitch.isFile && localPitch.length() > 1024 -> "pitch.onnx"
            sharedPitch.isFile && sharedPitch.length() > 1024 -> "@core/pitch.onnx"
            else -> ""
        }
        val ready = contentModelName.isNotBlank()

        // Re-probe actual files when possible. A failed probe does not reject the voice model;
        // the runtime path will validate it when conversion is requested.
        val voiceProbe = runCatching { OnnxModelProbe.inspect(File(normalized, "voice.onnx")) }.getOrNull() ?: voice
        val resolvedContentFile = when (contentModelName) {
            "content_encoder.onnx" -> localContent
            "@core/content_encoder.onnx" -> sharedContent
            else -> null
        }
        val resolvedPitchFile = when (pitchModelName) {
            "pitch.onnx" -> localPitch
            "@core/pitch.onnx" -> sharedPitch
            else -> null
        }
        contentProbe = resolvedContentFile?.let { runCatching { OnnxModelProbe.inspect(it) }.getOrNull() } ?: contentProbe
        pitchProbe = resolvedPitchFile?.let { runCatching { OnnxModelProbe.inspect(it) }.getOrNull() } ?: pitchProbe

        val featureChannels = voiceProbe.featureChannels
            ?: contentProbe?.featureChannels
            ?: if (inferRvcVersion(listOf(displayName) + onnxFiles.map { it.name }, displayName) == 1) 256 else 768
        val version = if (featureChannels == 256) 1 else 2
        val namedSr = inferSampleRateOrNull(
            listOf(displayName) + onnxFiles.map { it.name } + listOfNotNull(index?.name, checkpoint?.name)
        )
        val sr = voiceProbe.sampleRate ?: namedSr ?: 40_000
        val sampleRateKnown = voiceProbe.sampleRate != null || namedSr != null

        val voiceInputs = voiceProbe.inputs
        val phoneInput = OnnxModelProbe.findName(voiceInputs, "phone", "phones", "features", "feats") ?: "phone"
        val phoneLengthsInput = OnnxModelProbe.findName(voiceInputs, "phone_lengths", "phone_length", "p_len", "p_length", "lengths", "length", "seq_len") ?: "phone_lengths"
        val pitchInput = OnnxModelProbe.findName(voiceInputs, "pitch") ?: "pitch"
        val pitchFInput = OnnxModelProbe.findName(voiceInputs, "pitchf", "pitch_f", "f0") ?: "pitchf"
        val speakerInput = OnnxModelProbe.findName(voiceInputs, "ds", "sid", "speaker", "speaker_id", "spk", "spk_id") ?: "ds"
        val noiseInput = OnnxModelProbe.findName(voiceInputs, "rnd", "noise", "z") ?: "rnd"

        writeMetadata(
            dir = normalized,
            displayName = displayName,
            sourceFormat = if (voiceProbe.kind == OnnxModelProbe.Kind.VOICE) VoiceSourceFormat.RVC_ONNX else VoiceSourceFormat.ONNX_GENERIC,
            state = if (ready) VoiceModelState.READY else VoiceModelState.MISSING_CORE,
            engine = "rvc-onnx-v$version",
            sampleRate = sr,
            sampleRateKnown = sampleRateKnown,
            featureChannels = featureChannels,
            contentModelName = contentModelName,
            pitchModelName = pitchModelName,
            voiceModelName = "voice.onnx",
            checkpointName = if (checkpoint != null) "model.pth" else "",
            indexName = if (index != null) "model.index" else "",
            statusDetail = if (ready) {
                "جاهز للتشغيل. ${if (pitchModelName.isNotBlank()) "Pitch ONNX" else "Native F0 fallback"}."
            } else {
                "تم استيراد Voice ONNX. يحتاج RVC Content Encoder مرة واحدة؛ استخدم زر تنزيل Core داخل التطبيق أو استورد content_encoder.onnx."
            },
            contentInput = contentProbe?.primaryInput ?: "input_values",
            contentOutput = contentProbe?.primaryOutput ?: "hidden_states",
            contentInputRank = contentProbe?.inputRank ?: 2,
            contentOutputLayout = contentProbe?.contentLayout ?: "BTC",
            pitchInput = pitchProbe?.primaryInput ?: "audio",
            pitchOutput = pitchProbe?.primaryOutput ?: "f0",
            pitchInputRank = pitchProbe?.inputRank ?: 2,
            voicePhoneInput = phoneInput,
            voicePhoneLengthsInput = phoneLengthsInput,
            voicePitchInput = pitchInput,
            voicePitchFInput = pitchFInput,
            voiceSpeakerInput = speakerInput,
            voiceNoiseInput = noiseInput,
            voiceOutput = voiceProbe.primaryOutput ?: "audio"
        )

        val model = installNormalized(normalized)
        return ImportResult(model, "تم اكتشاف ${model.formatLabel()} تلقائيًا · ${model.stateLabel()}")
    }

    private fun refreshModelsWaitingForCore() {
        val sharedContent = File(coreRoot, "content_encoder.onnx")
        if (!sharedContent.isFile || sharedContent.length() <= 1024) return
        val sharedPitch = File(coreRoot, "pitch.onnx")

        // Probe the installed Core once and persist its real graph contract. This repairs metadata
        // written by v1.3.1 where ContentVec was assumed to use audio -> features although common
        // Transformers exports actually use input_values + attention_mask -> hidden_states.
        val contentProbe = runCatching { OnnxModelProbe.inspect(sharedContent) }.getOrNull()
        val pitchProbe = sharedPitch.takeIf { it.isFile && it.length() > 1024 }
            ?.let { runCatching { OnnxModelProbe.inspect(it) }.getOrNull() }

        root.listFiles()
            ?.filter { it.isDirectory && it.name != "_core" && !it.name.startsWith(".") }
            ?.forEach { dir ->
                val model = runCatching { VoiceModel.fromDirectory(dir) }.getOrNull() ?: return@forEach
                if (!model.voiceModel.isFile) return@forEach

                val usesSharedCore = model.state == VoiceModelState.MISSING_CORE ||
                    model.contentModelName == "@core/content_encoder.onnx"
                if (!usesSharedCore) return@forEach

                val metadataFile = File(dir, "metadata.json")
                val meta = JSONObject(metadataFile.readText(Charsets.UTF_8))
                meta.put("formatVersion", 3)
                meta.put("state", VoiceModelState.READY.name)
                meta.put("contentModel", "@core/content_encoder.onnx")
                meta.put("contentInput", contentProbe?.primaryInput ?: "input_values")
                meta.put("contentOutput", contentProbe?.primaryOutput ?: "hidden_states")
                meta.put("contentInputRank", (contentProbe?.inputRank ?: 2).coerceIn(1, 3))
                meta.put("contentOutputLayout", contentProbe?.contentLayout ?: "BTC")
                contentProbe?.featureChannels?.let { meta.put("featureChannels", it) }

                if (sharedPitch.isFile && sharedPitch.length() > 1024) {
                    meta.put("pitchModel", "@core/pitch.onnx")
                    meta.put("pitchInput", pitchProbe?.primaryInput ?: "audio")
                    meta.put("pitchOutput", pitchProbe?.primaryOutput ?: "f0")
                    meta.put("pitchInputRank", (pitchProbe?.inputRank ?: 2).coerceIn(1, 3))
                }
                meta.put(
                    "statusDetail",
                    "تم ربط RVC Core وفحص I/O تلقائيًا؛ Runtime يعيد اكتشاف أسماء ONNX عند كل تشغيل."
                )
                metadataFile.writeText(meta.toString(2), Charsets.UTF_8)
            }
    }

    /** Persist the sample rate learned from a successful voice-model inference. */
    fun updateDetectedSampleRate(model: VoiceModel, sampleRate: Int): VoiceModel? {
        if (sampleRate !in 16_000..96_000 || !model.directory.isDirectory) return null
        return runCatching {
            val metadataFile = File(model.directory, "metadata.json")
            val meta = JSONObject(metadataFile.readText(Charsets.UTF_8))
            meta.put("formatVersion", 3)
            meta.put("sampleRate", sampleRate)
            meta.put("sampleRateKnown", true)
            metadataFile.writeText(meta.toString(2), Charsets.UTF_8)
            VoiceModel.fromDirectory(model.directory)
        }.getOrNull()
    }

    private fun installNormalized(normalized: File): VoiceModel {
        val parsed = VoiceModel.fromDirectory(normalized)
        val safeId = sanitizeId(parsed.id.ifBlank { parsed.name })
        val finalDir = File(root, safeId)
        val backup = File(root, ".backup-$safeId-${System.nanoTime()}")

        if (finalDir.exists()) {
            require(finalDir.renameTo(backup)) { "تعذر تجهيز تحديث النموذج الحالي" }
        }
        try {
            require(normalized.renameTo(finalDir)) { "تعذر تثبيت النموذج في مساحة التطبيق" }
            backup.deleteRecursively()
        } catch (t: Throwable) {
            if (!finalDir.exists() && backup.exists()) backup.renameTo(finalDir)
            throw t
        }
        return VoiceModel.fromDirectory(finalDir)
    }

    private fun writeMetadata(
        dir: File,
        displayName: String,
        sourceFormat: VoiceSourceFormat,
        state: VoiceModelState,
        engine: String,
        sampleRate: Int,
        sampleRateKnown: Boolean,
        featureChannels: Int,
        contentModelName: String,
        pitchModelName: String,
        voiceModelName: String,
        checkpointName: String,
        indexName: String,
        statusDetail: String,
        contentInput: String = "input_values",
        contentOutput: String = "hidden_states",
        contentInputRank: Int = 2,
        contentOutputLayout: String = "BTC",
        pitchInput: String = "audio",
        pitchOutput: String = "f0",
        pitchInputRank: Int = 2,
        voicePhoneInput: String = "phone",
        voicePhoneLengthsInput: String = "phone_lengths",
        voicePitchInput: String = "pitch",
        voicePitchFInput: String = "pitchf",
        voiceSpeakerInput: String = "ds",
        voiceNoiseInput: String = "rnd",
        voiceOutput: String = "audio"
    ) {
        val cleanName = displayName.substringBeforeLast('.').ifBlank { "Imported Voice" }.take(128)
        val idSeed = "$cleanName-${File(dir, voiceModelName.ifBlank { checkpointName }).length()}-$engine"
        val id = sanitizeId(cleanName) + "-" + shortHash(idSeed).take(10)
        val json = JSONObject()
            .put("format", "VSPVOICE-AUTO")
            .put("formatVersion", 3)
            .put("id", id)
            .put("name", cleanName)
            .put("author", "Local import")
            .put("engine", engine)
            .put("sourceFormat", sourceFormat.name)
            .put("state", state.name)
            .put("statusDetail", statusDetail)
            .put("sampleRate", sampleRate)
            .put("sampleRateKnown", sampleRateKnown)
            .put("contentSampleRate", 16_000)
            .put("featureChannels", featureChannels)
            .put("featureUpsample", 2)
            .put("authorized", true)
            .put("license", "User supplied / rights confirmed")
            .put("contentModel", contentModelName)
            .put("pitchModel", pitchModelName)
            .put("voiceModel", voiceModelName)
            .put("checkpoint", checkpointName)
            .put("index", indexName)
            .put("contentInput", contentInput)
            .put("contentOutput", contentOutput)
            .put("contentInputRank", contentInputRank.coerceIn(1, 3))
            .put("contentOutputLayout", if (contentOutputLayout == "BCT") "BCT" else "BTC")
            .put("pitchInput", pitchInput)
            .put("pitchOutput", pitchOutput)
            .put("pitchInputRank", pitchInputRank.coerceIn(1, 3))
            .put("voicePhoneInput", voicePhoneInput)
            .put("voicePhoneLengthsInput", voicePhoneLengthsInput)
            .put("voicePitchInput", voicePitchInput)
            .put("voicePitchFInput", voicePitchFInput)
            .put("voiceSpeakerInput", voiceSpeakerInput)
            .put("voiceNoiseInput", voiceNoiseInput)
            .put("voiceOutput", voiceOutput)
            .put("speakerId", 0)
        File(dir, "metadata.json").writeText(json.toString(2), Charsets.UTF_8)
    }

    private fun findVspMetadata(dir: File): File? = dir.walkTopDown()
        .filter { it.isFile && it.name.equals("metadata.json", true) && it.length() in 2..1_048_576 }
        .firstOrNull { file ->
            runCatching {
                val json = JSONObject(file.readText(Charsets.UTF_8))
                json.optString("format") == "VSPVOICE" || json.optString("format") == "VSPVOICE-AUTO"
            }.getOrDefault(false)
        }

    private fun verifyPortablePayloads(metadataFile: File) {
        val json = JSONObject(metadataFile.readText(Charsets.UTF_8))
        val checksums = json.optJSONObject("payloadSha256") ?: return
        val base = metadataFile.parentFile?.canonicalFile ?: error("مجلد حزمة النموذج غير صالح")
        val names = checksums.keys()
        var count = 0
        while (names.hasNext()) {
            val name = names.next()
            count++
            require(count <= 16) { "جدول تحقق النموذج يحتوي ملفات أكثر من الحد المسموح" }
            require(name.isNotBlank() && !name.contains('/') && !name.contains('\\') && !name.contains("..")) {
                "اسم ملف غير آمن في جدول تحقق النموذج"
            }
            val expected = checksums.optString(name)
            require(expected.matches(Regex("[0-9a-fA-F]{64}"))) { "SHA-256 غير صالح للملف $name" }
            val file = File(base, name).canonicalFile
            require(file.path.startsWith(base.path + File.separator) && file.isFile) { "ملف الحزمة مفقود: $name" }
            require(sha256(file).equals(expected, true)) { "فشل تحقق SHA-256 للملف $name" }
        }
    }

    private fun looksLikeZip(uri: Uri, name: String): Boolean {
        val lower = name.lowercase(Locale.ROOT)
        if (lower.endsWith(".zip") || lower.endsWith(".vspvoice")) return true
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val header = ByteArray(4)
                val n = input.read(header)
                n == 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
                    (header[2] == 0x03.toByte() || header[2] == 0x05.toByte() || header[2] == 0x07.toByte())
            } ?: false
        }.getOrDefault(false)
    }

    private fun copyUri(uri: Uri, target: File) {
        target.parentFile?.mkdirs()
        val input = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح ملف النموذج")
        input.use { src ->
            FileOutputStream(target).buffered(256 * 1024).use { out -> src.copyTo(out, 256 * 1024) }
        }
        require(target.length() > 0) { "ملف النموذج فارغ" }
    }

    private fun extractSecure(uri: Uri, outDir: File) {
        val input = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح ZIP")
        val canonicalRoot = outDir.canonicalFile
        var total = 0L
        var entries = 0
        val maxTotal = 6_000_000_000L
        val maxEntry = 5_000_000_000L
        val maxEntries = 512

        ZipInputStream(BufferedInputStream(input, 256 * 1024)).use { zis ->
            val buffer = ByteArray(512 * 1024)
            while (true) {
                val entry = zis.nextEntry ?: break
                if (entry.isDirectory) {
                    zis.closeEntry()
                    continue
                }
                entries++
                require(entries <= maxEntries) { "ZIP يحتوي ملفات أكثر من الحد المسموح" }
                require(entry.name.isNotBlank() && entry.name.length <= 300) { "اسم ملف غير صالح داخل ZIP" }
                val target = File(outDir, entry.name).canonicalFile
                require(target.path.startsWith(canonicalRoot.path + File.separator)) { "تم رفض مسار ZIP غير آمن" }
                target.parentFile?.mkdirs()
                var entryBytes = 0L
                FileOutputStream(target).buffered(512 * 1024).use { out ->
                    while (true) {
                        val n = zis.read(buffer)
                        if (n <= 0) break
                        entryBytes += n
                        total += n
                        require(entryBytes <= maxEntry && total <= maxTotal) { "حزمة النموذج أكبر من الحد المسموح" }
                        out.write(buffer, 0, n)
                    }
                }
                zis.closeEntry()
            }
        }
    }

    private fun moveDirectoryContents(source: File, target: File) {
        source.walkTopDown().forEach { file ->
            if (file == source) return@forEach
            val rel = file.relativeTo(source).path
            val dest = File(target, rel)
            if (file.isDirectory) dest.mkdirs() else moveLarge(file, dest)
        }
    }

    private fun moveLarge(source: File, target: File) {
        target.parentFile?.mkdirs()
        if (source.canonicalFile == target.canonicalFile) return
        if (source.renameTo(target)) return
        copyLarge(source, target)
        source.delete()
    }

    private fun copyLarge(source: File, target: File) {
        target.parentFile?.mkdirs()
        FileInputStream(source).buffered(512 * 1024).use { input ->
            FileOutputStream(target).buffered(512 * 1024).use { output -> input.copyTo(output, 512 * 1024) }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (!c.moveToFirst()) null else c.getString(0)
            }
        }.getOrNull()
    }

    private fun inferSampleRateOrNull(names: List<String>): Int? {
        val joined = names.joinToString(" ").lowercase(Locale.ROOT)
        return when {
            Regex("(^|[^0-9])48k([^0-9]|$)").containsMatchIn(joined) -> 48_000
            Regex("(^|[^0-9])44(?:\\.1)?k([^0-9]|$)").containsMatchIn(joined) -> 44_100
            Regex("(^|[^0-9])40k([^0-9]|$)").containsMatchIn(joined) -> 40_000
            Regex("(^|[^0-9])32k([^0-9]|$)").containsMatchIn(joined) -> 32_000
            else -> null
        }
    }

    private fun inferRvcVersion(names: List<String>, fallback: String): Int {
        val joined = (names + fallback).joinToString(" ").lowercase(Locale.ROOT)
        return when {
            joined.contains("_v1") || joined.contains("-v1") || joined.contains(" rvc1") -> 1
            joined.contains("_v2") || joined.contains("-v2") || joined.contains(" rvc2") -> 2
            else -> 2
        }
    }

    private fun sanitizeFileName(value: String): String = value
        .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]+"), "_")
        .take(180)
        .ifBlank { "model.bin" }

    private fun sanitizeId(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9._-]+"), "-")
        .trim('-')
        .take(64)
        .ifBlank { "voice-${System.currentTimeMillis()}" }

    private fun shortHash(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(512 * 1024).use { input ->
            val buffer = ByteArray(512 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}

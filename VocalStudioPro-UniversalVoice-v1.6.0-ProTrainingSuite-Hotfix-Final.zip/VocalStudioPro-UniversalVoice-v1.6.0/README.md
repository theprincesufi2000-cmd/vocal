# Vocal Studio Pro v1.6.0 — Pro Training Suite + Portable RVC

> **v1.6.0 training hotfix:** valid real-world VSPTRAIN3 models are no longer rejected by the former overly strict spectral-envelope check. Training output is now sanitized, self-validated, and atomically installed before the UI sees it.


Native Android vocal studio built with Kotlin/Jetpack Compose, JNI and C++17 DSP.

## Highlights

- Offline vocal recording/import.
- StudioClean spectral denoise, hum removal and mastering.
- Key-aware Auto-Tune.
- Universal RVC/Applio ONNX import and adaptive fixed/dynamic frame inference.
- **Multi-clip VSPTRAIN3** from up to 64 isolated recordings / 50 minutes.
- Per-recording noise gate and post-training quality report.
- Integrity-checked `.vspmodel` import/export with metadata and SHA-256.
- Self-contained `.vspvoice` export, including a referenced shared RVC core.
- Lossless `.vspdataset` export for a real GPU RVC v2/RMVPE training workflow.
- 48 kHz / 24-bit WAV output.

## Pro Training 50m

VSPTRAIN3 is designed for mobile training without huge RAM use. It streams every source file twice,
measures its noise floor independently, then learns one 96-band timbre model, voiced/unvoiced
behavior, four pitch registers, 30 adaptive timbre prototypes and a PCA articulation manifold.
During inference it protects consonants and leaves timing/F0 intact to reduce pronunciation damage.

For the strongest local profile, use 10-50 minutes of clean isolated vocal audio. More duration does not compensate for reverb, clipping or background music.

This local trainer is an adaptive speaker-timbre model rather than a full RVC/VITS generator
training run. For neural training, export `.vspdataset`, train RVC v2 + RMVPE + ContentVec + FAISS
on a GPU, then import/export the resulting model through the portable VSPVOICE path.

See `docs/PRO_TRAINING_SUITE.md` for the exact distinction and package formats.

## Android toolchain

- compileSdk / targetSdk: 37
- minSdk: 26
- JDK: 17
- Gradle: 9.6.0
- AGP: 9.4.0
- NDK: 28.2.13676358
- CMake: 3.22.1
- ONNX Runtime Android: 1.29.0

## GitHub Actions

Upload `VocalStudioPro-UniversalVoice-v1.6.0-ProTrainingSuite-Hotfix-Final.zip` to the repository root and use the included `.github/workflows/build.yml`.

# Vocal Studio Pro 1.1

تطبيق Android Native لمعالجة الغناء محليًا بالكامل على الهاتف. المشروع مكتوب بـ **Kotlin + Jetpack Compose + C++17/Android NDK + JNI** ولا يحتاج Flutter أو خادم أو API لمعالجة الصوت.

## ما الجديد في 1.1 — Studio Clean Engine

الإصدار 1.1 يرفع جودة المعالجة بشكل واضح، خصوصًا للتسجيلات المنزلية أو التسجيلات التي تحتوي على hiss / room noise / hum:

- **Spectral Noise Reduction حقيقي** باستخدام STFT + Noise Profile + Wiener-style masking بدل الاعتماد على Noise Gate فقط.
- استخراج بصمة الضوضاء من أهدأ إطارات التسجيل مع حماية نطاقات الـ vocal formants والهارمونيكس لتقليل التشويه المعدني.
- Frequency + temporal mask smoothing لتقليل musical noise.
- **Auto Mains Hum Remover** يكتشف عائلة 50Hz أو 60Hz ويزيل الهارمونيكس المزعجة بنطاقات notch ضيقة.
- High-pass vocal filter من درجتين + DC blocker.
- Downward expander ناعم بعد التنظيف بدل gate قاسٍ يقطع التنفس ونهايات الكلمات.
- **Vocal Leveling** تلقائي لتقريب الجمل الهادئة والقوية قبل الضغط النهائي.
- **Multiband Compression** منفصل للنطاق المنخفض/المتوسط/العالي بدل compressor واحد.
- Split-band **De-Esser** يخفض نطاق الصفير بدل خفض الصوت كله.
- تحكم مستقل في **Clarity / Warmth / Air**.
- Plate reverb متوازي مع pre-delay ليبقى الصوت في المقدمة.
- **4x interpolated True-Peak analysis + lookahead limiter** لتقليل inter-sample clipping.
- Preset جديد **Studio** مضبوط للوضوح والنظافة والتوازن.

## الميزات الأساسية

- تسجيل صوت خام داخل التطبيق بصيغة WAV مع محاولة تعطيل AGC/AEC/Noise Suppression الخاصة بالنظام لتقليل التلوين قبل المعالجة.
- استيراد WAV مباشرة، وفك الصيغ التي يدعمها MediaCodec في الجهاز مثل MP3/M4A/AAC/FLAC/OGG إلى PCM قبل المعالجة.
- اختيار الجذر الموسيقي C..B مع Major أو Natural Minor.
- Pitch Detection حقيقي باستخدام YIN.
- Scale Quantizer لتحديد أقرب نغمة مسموحة داخل المقام.
- Dynamic Phase-Vocoder Pitch Correction لتغيير مقدار التصحيح مع النغمة المكتشفة، وليس Pitch Shift ثابتًا.
- Retune Speed + Strength + Humanize.
- معاينة waveform وتشغيل التسجيل الأصلي والناتج.
- تصدير WAV نهائي **48 kHz / 24-bit PCM / mono**.
- المعالجة Offline بالكامل.

> أفضل نتيجة تأتي من Vocal منفرد وجاف قدر الإمكان، ومن تسجيل بدون clipping وبمستوى ميكروفون جيد. المعالجة تستطيع تحسين التسجيل بشكل كبير، لكنها لا تستطيع استعادة معلومات صوتية لم تُسجل أصلًا أو إزالة ضوضاء شديدة جدًا بلا أي أثر على الصوت.

## خط المعالجة

```text
Imported / Recorded Vocal
        ↓
48 kHz float conversion
        ↓
DC blocker + 4th-order HPF
        ↓
50/60 Hz mains-family detection
        ↓
Narrow harmonic notch removal
        ↓
STFT noise profiling
        ↓
Wiener spectral denoise
        ↓
Soft downward expander
        ↓
YIN F0 detection
        ↓
Scale quantizer
        ↓
Dynamic pitch correction
        ↓
Vocal leveling
        ↓
3-band dynamics
        ↓
Corrective EQ
        ↓
Split-band De-Esser
        ↓
Clarity / Warmth / Air
        ↓
Soft saturation
        ↓
Parallel plate + pre-delay
        ↓
True-peak lookahead limiter
        ↓
24-bit / 48 kHz WAV
```

## الإعداد الموصى به

للتسجيلات العادية ابدأ بـ **Studio**. إذا كان التسجيل نظيفًا جدًا استخدم Natural أو خفّض Noise Reduction. لا ترفع Air وClarity إلى 100% مع تسجيل مليء بالـ hiss لأن أي enhancer عالي التردد قد يبرز البقايا المتبقية من الضوضاء.

### Presets

- **Natural**: تصحيح نغمي محافظ، تنظيف خفيف، ديناميكس طبيعية.
- **Modern**: صوت حديث متماسك ومشرق مع Auto-Tune أسرع.
- **Studio**: أقوى تنظيف متوازن + clarity + leveling + multiband master.
- **Hard Tune**: Retune سريع جدًا وتأثير Auto-Tune واضح.

## متطلبات البناء

- JDK 17
- Android SDK Platform 37
- Android NDK `28.2.13676358`
- CMake `3.22.1`
- Gradle `9.6.0`
- Android Gradle Plugin `9.4.0`
- Compose Compiler plugin / Kotlin `2.3.21`

## البناء

المشروع يحتوي على سكربت `gradlew` مستقل: إذا كان Gradle مثبتًا يستخدمه مباشرة، وإلا ينزّل Gradle 9.6 في أول Build.

Linux/macOS:

```bash
chmod +x gradlew
./gradlew :app:assembleDebug
```

Windows:

```bat
gradlew.bat :app:assembleDebug
```

Release:

```bash
./gradlew :app:assembleRelease
```

كما يوجد workflow جاهز داخل `.github/workflows/build.yml` يبني Debug وRelease.

## ملاحظات الأداء

- DSP الأساسي C++ Native ومترجم `-O3 -ffast-math`.
- المعالجة الطيفية تتم Offline لتسمح باستخدام lookahead وتحليل Noise Profile أدق من المعالجة الحية.
- الذاكرة المطلوبة منخفضة نسبيًا لأن STFT يستخدم buffers صغيرة؛ ملف الصوت نفسه يبقى float mono أثناء المعالجة.
- ARM64 هو ABI المفضل للأداء على الهواتف الحديثة.

## الاختبار

- تم تجميع جميع ملفات C++ وJNI باستخدام host C++ compiler بدون أخطاء.
- تم تشغيل اختبار end-to-end على ملف WAV يحوي vocal-like harmonics + hiss + 50Hz hum.
- خرج المحرك WAV 24-bit/48kHz بنفس مدة المصدر.
- في الاختبار الاصطناعي انخفض RMS في مقطع الضوضاء الصامت من حوالي **-35.8 dBFS إلى -45.5 dBFS** مع رفع تماسك المقطع الصوتي، أي تنظيف يقارب 10 dB في هذا السيناريو الاصطناعي دون استخدام gate قاسٍ.

## الترخيص

كود المشروع مرفق بترخيص MIT. تبعيات AndroidX/Gradle/Android SDK تخضع لتراخيصها الخاصة.

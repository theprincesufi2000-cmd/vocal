# Changelog

## 1.1.0 — Studio Clean

- Replaced gate-only cleanup with offline STFT/Wiener spectral denoising.
- Added automatic 50/60 Hz mains-family detection and harmonic notch removal.
- Added soft post-denoise downward expansion.
- Added Vocal Leveling.
- Added three-band vocal compression.
- Added split-band De-Esser.
- Added independent Clarity, Warmth and Air controls.
- Added parallel plate reverb pre-delay.
- Added cubic 4x inter-sample peak estimation and lookahead true-peak limiting.
- Added Studio preset.
- Updated JNI/Kotlin parameter pipeline and UI controls.
- Bumped application version to 1.1.0 / versionCode 2.

# Vocal Studio Pro v1.3.2 — Dynamic ONNX Voice Conversion

Native Android vocal studio: Kotlin + Jetpack Compose + JNI/C++17 + ONNX Runtime.

Processing path:

`Record/import → Spectral Clean → key-aware Auto-Tune → optional RVC/ONNX Voice Conversion → Studio Master → 48 kHz / 24-bit WAV`

## v1.3.2 Core I/O fix

This release fixes ContentVec compatibility without trusting stale metadata. At inference time the app reads the live ONNX graph and supports common ContentVec/HuBERT contracts including:

- `input_values` + optional `attention_mask` → `hidden_states` / `last_hidden_state`
- `source` rank-3 input → `embed`
- `audio`, `waveform`, `wav`, `speech`, or `input` aliases
- INT64 / INT32 / FLOAT / BOOL attention and padding masks
- length inputs when present
- BTC and BCT feature layouts

Models installed by v1.3.1 with stale `audio → features` metadata remain usable because runtime I/O resolution has priority over persisted hints. The shared RVC Core metadata is also repaired when it is installed/refreshed.

## Model import

The app accepts `.zip`, `.vspvoice`, `.onnx`, `.ort`, `.pth`, `.pt`, and `.index`. A directly runnable RVC setup requires a compatible voice ONNX plus ContentVec/HuBERT encoder. The app can download the shared RVC v2 ContentVec core once. Direct-F0 `pitch.onnx` is optional because Native YIN F0 is available.

Raw `.pth` files are PyTorch checkpoints and are catalogued as **Needs ONNX conversion**; Android ONNX Runtime cannot execute arbitrary PyTorch state dictionaries directly. `.index` files are preserved when supplied but retrieval/index inference is not required for the base conversion path.

## Sample rate

When a voice ONNX does not declare its output rate, the UI displays **Auto 40/48 kHz**. After the first successful inference the app estimates the real model output rate from synthesized samples and persists it. The final native mastering stage writes 48 kHz / 24-bit WAV.

## Build

- compileSdk / targetSdk: 37
- minSdk: 26
- JDK: 17
- Gradle: 9.6.0
- AGP: 9.4.0
- NDK: 28.2.13676358
- CMake: 3.22.1
- ONNX Runtime Android: 1.29.0

For GitHub Actions, upload `VocalStudioPro-UniversalVoice-v1.3.2-CoreIO-Final.zip` to the repository root and use `.github/workflows/build.yml`.

## Voice model rights

Only import/use voice models you own or are authorized to use. The project does not include a celebrity/person voice model.

# Vocal Studio Pro 1.3.2 — Verification

Local verification performed on the source package:

- Native C++/JNI: compiled all `.cpp` files with C++17, `-Wall -Wextra -Werror`.
- Kotlin voice layer: compile-check passed for `VoiceModel`, `OnnxModelProbe`, `VoiceConversionEngine`, `VoiceModelManager`, `VoiceWavIO`.
- `StudioViewModel`: compile-check passed.
- Compose `StudioScreen`: compile-check passed against API stubs.
- Regression test: a simulated ContentVec graph exposing only `input_values` + `attention_mask` and `hidden_states` was executed through private `runContent`; stale metadata `audio/features` was ignored and the correct feed was generated.
- XML/YAML syntax and ZIP integrity are checked before release packaging.

Build configuration:
- versionCode: 7
- versionName: 1.3.2
- compileSdk / targetSdk: 37
- Gradle: 9.6.0
- AGP: 9.4.0
- Lifecycle: 2.11.0
- ONNX Runtime Android: 1.29.0
- NDK: 28.2.13676358
- CMake: 3.22.1

Full Android `assembleDebug/assembleRelease` is performed by the included GitHub Actions workflow because the current local verification environment does not contain the complete Android SDK/Maven dependency set.

package com.mustafa.vocalstudio.voice

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.File
import java.util.Locale

/**
 * Lightweight ONNX graph probe used only while importing/configuring models.
 * Runtime execution still re-resolves I/O from the live OrtSession so stale metadata from older
 * app versions cannot break inference.
 */
internal object OnnxModelProbe {
    enum class Kind { VOICE, CONTENT, PITCH, UNKNOWN }

    data class Probe(
        val file: File,
        val kind: Kind,
        val inputs: List<String>,
        val outputs: List<String>,
        val primaryInput: String?,
        val primaryOutput: String?,
        val inputRank: Int,
        val outputRank: Int,
        val featureChannels: Int?,
        val contentLayout: String?,
        val directF0: Boolean,
        val sampleRate: Int?
    )

    private val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }

    fun inspect(file: File): Probe {
        val fileName = file.name.lowercase(Locale.ROOT)
        OrtSession.SessionOptions().use { options ->
            options.setInterOpNumThreads(1)
            options.setIntraOpNumThreads(1)
            return env.createSession(file.absolutePath, options).use { session ->
                val inputs = session.inputNames.toList()
                val outputs = session.outputNames.toList()
                val lowerInputs = inputs.map { it.lowercase(Locale.ROOT) }
                val lowerOutputs = outputs.map { it.lowercase(Locale.ROOT) }

                val phoneName = findName(inputs, "phone", "phones", "features", "feats")
                val hasRvcSignature = lowerInputs.any { it == "phone" || it.contains("phone") } &&
                    lowerInputs.any { it.contains("pitch") } &&
                    lowerInputs.any { it == "ds" || it.contains("speaker") || it.contains("sid") } &&
                    lowerInputs.any { it == "rnd" || it.contains("noise") }

                val looksLikePitchByName = fileName.contains("pitch") || fileName.contains("f0") || fileName.contains("rmvpe")
                val firstOutput = outputs.firstOrNull()
                val firstOutputInfo = firstOutput?.let { session.outputInfo[it]?.info as? TensorInfo }
                val firstOutputShape = firstOutputInfo?.shape ?: longArrayOf()
                val outputLooksLikeF0 = lowerOutputs.any {
                    it == "f0" || it.contains("pitch") || it.contains("frequency") || it.contains("fundamental")
                }
                val salienceBins = firstOutputShape.lastOrNull()?.takeIf { it > 0 }
                val isRmvpeSalience = looksLikePitchByName && salienceBins == 360L
                val directF0 = !isRmvpeSalience && (outputLooksLikeF0 || looksLikePitchByName) &&
                    (firstOutputShape.size <= 2 || salienceBins == null || salienceBins <= 8L)

                val contentByName = fileName.contains("hubert") || fileName.contains("content") ||
                    fileName.contains("vec") || fileName.contains("encoder") || fileName.contains("embed")
                val contentByIo = lowerInputs.any {
                    it == "input_values" || it == "source" || it == "audio" || it == "waveform" || it == "wav"
                } && lowerOutputs.any {
                    it.contains("hidden") || it.contains("embed") || it.contains("feature") || it == "output"
                }

                val kind = when {
                    hasRvcSignature -> Kind.VOICE
                    directF0 -> Kind.PITCH
                    contentByName || contentByIo -> Kind.CONTENT
                    !isRmvpeSalience && inputs.size == 1 && outputs.isNotEmpty() -> Kind.CONTENT
                    else -> Kind.UNKNOWN
                }

                val primaryInput = when (kind) {
                    Kind.VOICE -> phoneName ?: inputs.firstOrNull()
                    Kind.CONTENT -> findName(
                        inputs,
                        "input_values", "source", "audio", "waveform", "wav", "speech", "input"
                    ) ?: inputs.firstOrNull { !it.lowercase(Locale.ROOT).contains("mask") } ?: inputs.firstOrNull()
                    Kind.PITCH -> findName(inputs, "audio", "waveform", "input_values", "source", "input")
                        ?: inputs.firstOrNull()
                    Kind.UNKNOWN -> inputs.firstOrNull()
                }

                val primaryOutput = when (kind) {
                    Kind.CONTENT -> findName(
                        outputs,
                        "hidden_states", "last_hidden_state", "embed", "embeddings", "features", "feature", "output"
                    ) ?: outputs.firstOrNull()
                    Kind.PITCH -> findName(outputs, "f0", "pitch", "frequency", "output") ?: outputs.firstOrNull()
                    Kind.VOICE -> findName(outputs, "audio", "waveform", "output") ?: outputs.firstOrNull()
                    Kind.UNKNOWN -> outputs.firstOrNull()
                }

                val primaryInputInfo = primaryInput?.let { session.inputInfo[it]?.info as? TensorInfo }
                val primaryOutputInfo = primaryOutput?.let { session.outputInfo[it]?.info as? TensorInfo }
                val primaryInputShape = primaryInputInfo?.shape ?: longArrayOf()
                val primaryOutputShape = primaryOutputInfo?.shape ?: longArrayOf()

                var channels: Int? = null
                var layout: String? = null

                if (kind == Kind.VOICE && phoneName != null) {
                    val shape = (session.inputInfo[phoneName]?.info as? TensorInfo)?.shape ?: longArrayOf()
                    channels = shape.lastOrNull()?.takeIf { it in setOf(256L, 768L, 1024L) }?.toInt()
                }

                if (kind == Kind.CONTENT) {
                    val shape = primaryOutputShape
                    if (shape.size >= 2) {
                        val a = shape.getOrNull(shape.size - 2) ?: -1
                        val b = shape.getOrNull(shape.size - 1) ?: -1
                        when {
                            b in setOf(256L, 768L, 1024L) -> {
                                channels = b.toInt()
                                layout = "BTC"
                            }
                            a in setOf(256L, 768L, 1024L) -> {
                                channels = a.toInt()
                                layout = "BCT"
                            }
                        }
                    }
                }

                val custom = runCatching { session.metadata.customMetadata }.getOrDefault(emptyMap())
                val sampleRate = parseSampleRate(
                    sequenceOf("sample_rate", "sampling_rate", "sampleRate", "samplerate", "sr")
                        .mapNotNull { key -> custom.entries.firstOrNull { it.key.equals(key, true) }?.value }
                        .firstOrNull()
                )

                Probe(
                    file = file,
                    kind = kind,
                    inputs = inputs,
                    outputs = outputs,
                    primaryInput = primaryInput,
                    primaryOutput = primaryOutput,
                    inputRank = primaryInputShape.size.coerceAtLeast(1),
                    outputRank = primaryOutputShape.size,
                    featureChannels = channels,
                    contentLayout = layout,
                    directF0 = directF0,
                    sampleRate = sampleRate
                )
            }
        }
    }

    fun guess(file: File): Probe {
        val n = file.name.lowercase(Locale.ROOT)
        val kind = when {
            n.contains("voice") || n.contains("rvc") || n.contains("synth") || n.contains("generator") -> Kind.VOICE
            n.contains("pitch") || n.contains("f0") || n.contains("rmvpe") -> Kind.PITCH
            n.contains("hubert") || n.contains("content") || n.contains("vec") || n.contains("encoder") -> Kind.CONTENT
            else -> Kind.UNKNOWN
        }
        return Probe(
            file = file,
            kind = kind,
            inputs = emptyList(),
            outputs = emptyList(),
            primaryInput = null,
            primaryOutput = null,
            inputRank = 2,
            outputRank = 0,
            featureChannels = null,
            contentLayout = null,
            directF0 = kind == Kind.PITCH,
            sampleRate = null
        )
    }

    fun findName(names: Collection<String>, vararg aliases: String): String? {
        val exact = names.associateBy { it.lowercase(Locale.ROOT) }
        aliases.forEach { alias -> exact[alias.lowercase(Locale.ROOT)]?.let { return it } }
        aliases.forEach { alias ->
            names.firstOrNull { it.lowercase(Locale.ROOT).contains(alias.lowercase(Locale.ROOT)) }?.let { return it }
        }
        return null
    }

    private fun parseSampleRate(value: String?): Int? {
        val raw = value?.trim()?.lowercase(Locale.ROOT) ?: return null
        val number = Regex("([0-9]+(?:\\.[0-9]+)?)").find(raw)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            ?: return null
        val hz = if (raw.contains('k') || number < 1_000.0) (number * 1_000.0).toInt() else number.toInt()
        return hz.takeIf { it in 16_000..96_000 }
    }
}

# Vocal Studio Pro 1.3.3 — Verification

Release target:
- versionCode: 8
- versionName: 1.3.3
- compileSdk / targetSdk: 37
- Gradle: 9.6.0
- AGP: 9.4.0
- NDK: 28.2.13676358
- CMake: 3.22.1
- ONNX Runtime Android: 1.29.0

Regression targets:
1. ContentVec `input_values + attention_mask -> hidden_states`.
2. ContentVec `source -> embed`.
3. Nova/Applio RVC: `feats, p_len, pitch, pitchf, sid` (no rnd).
4. Official RVC: `phone, phone_lengths, pitch, pitchf, ds, rnd`.
5. non-F0 RVC: `feats, p_len, sid`.
6. Native C++ DSP / JNI compilation with warnings treated as errors.
7. ZIP integrity and workflow source validation.

A full Android APK build is performed by the included GitHub Actions workflow because the local verification environment does not provide a complete Android SDK/Maven build environment.

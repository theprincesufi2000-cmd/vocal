# Vocal Studio Pro v1.3.3 — Universal RVC Compatibility

Native Android vocal studio: Kotlin + Jetpack Compose + JNI/C++17 + ONNX Runtime.

Processing path:

`Record/import → Spectral Clean → key-aware Auto-Tune → optional RVC/ONNX Voice Conversion → Studio Master → 48 kHz / 24-bit WAV`

## v1.3.3 RVC signature fix

This release removes the last fixed RVC synthesizer signature assumption. The app now resolves the live ONNX graph and supports common RVC/Applio contracts, including:

- Applio/Nova-style F0 model: `feats, p_len, pitch, pitchf, sid`
- Official RVC ONNX export: `phone, phone_lengths, pitch, pitchf, ds, rnd`
- non-F0 RVC export: `feats, p_len, sid`
- optional noise input (`rnd/noise/z`) instead of requiring it
- `p_len`, `phone_lengths`, `lengths`, `seq_len`, and other length aliases
- `sid`, `ds`, `speaker`, `speaker_id`, and `spk_id` speaker aliases
- INT64 or INT32 scalar/sequence integer inputs
- runtime validation of all required ONNX inputs before inference

The fix is backward-compatible with models imported by v1.3.1/v1.3.2. Re-importing Nova_HD is not required after installing this update.

## ContentVec / HuBERT compatibility

Content encoder I/O is also resolved from the live ONNX graph rather than stale metadata. Supported common contracts include:

- `input_values` + optional `attention_mask` → `hidden_states` / `last_hidden_state`
- `source` rank-3 input → `embed`
- `audio`, `waveform`, `wav`, `speech`, or `input` aliases
- INT64 / INT32 / FLOAT / BOOL masks
- optional length inputs
- BTC and BCT feature layouts

## Model import

The app accepts `.zip`, `.vspvoice`, `.onnx`, `.ort`, `.pth`, `.pt`, and `.index`.

A directly runnable RVC setup requires a compatible voice ONNX plus ContentVec/HuBERT encoder. The app can download the shared RVC v2 ContentVec core once. Direct-F0 `pitch.onnx` is optional because Native F0 extraction is available.

Raw `.pth` files are PyTorch checkpoints and are catalogued as **Needs ONNX conversion**; Android ONNX Runtime cannot execute arbitrary PyTorch state dictionaries directly. `.index` files are preserved when supplied.

## Sample rate

When a voice ONNX does not declare its output rate, the UI uses **Auto 40/48 kHz**. After the first successful inference the app estimates the effective output rate from synthesized samples and uses it for the conversion pipeline. The final native mastering stage exports 48 kHz / 24-bit WAV.

## Build

- compileSdk / targetSdk: 37
- minSdk: 26
- JDK: 17
- Gradle: 9.6.0
- AGP: 9.4.0
- NDK: 28.2.13676358
- CMake: 3.22.1
- Lifecycle: 2.11.0
- ONNX Runtime Android: 1.29.0

For GitHub Actions, upload `VocalStudioPro-UniversalVoice-v1.3.3-RvcCompat-Final.zip` to the repository root and use `.github/workflows/build.yml`.

## Voice model rights

Only import/use voice models you own or are authorized to use. The project does not bundle a real person's voice model.

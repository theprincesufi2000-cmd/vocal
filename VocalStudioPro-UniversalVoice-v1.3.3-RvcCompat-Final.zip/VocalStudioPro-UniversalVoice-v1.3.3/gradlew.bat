@echo off
setlocal
set "ROOT=%~dp0"
set "VERSION=9.6.0"
set "BOOT=%ROOT%.gradle-bootstrap\gradle-%VERSION%"
set "ZIP=%ROOT%.gradle-bootstrap\gradle-%VERSION%-bin.zip"
set "URL=https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip"

if not exist "%BOOT%\bin\gradle.bat" (
  if not exist "%ROOT%.gradle-bootstrap" mkdir "%ROOT%.gradle-bootstrap"
  if not exist "%ZIP%" (
    echo Bootstrapping Gradle %VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Expand-Archive -Path '%ZIP%' -DestinationPath '%ROOT%.gradle-bootstrap' -Force"
  if errorlevel 1 exit /b 1
)

call "%BOOT%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%

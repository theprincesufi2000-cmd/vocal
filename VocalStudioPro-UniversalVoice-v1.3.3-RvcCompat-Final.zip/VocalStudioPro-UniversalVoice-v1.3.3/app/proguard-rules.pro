-keep class com.mustafa.vocalstudio.dsp.NativeDsp { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# ONNX Runtime Java/JNI bridge
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**

# Keep model metadata classes used by local package parsing.
-keep class com.mustafa.vocalstudio.voice.** { *; }

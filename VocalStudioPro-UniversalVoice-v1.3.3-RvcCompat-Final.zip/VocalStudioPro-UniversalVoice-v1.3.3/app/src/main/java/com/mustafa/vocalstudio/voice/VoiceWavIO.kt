package com.mustafa.vocalstudio.voice

import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

internal data class FloatAudio(val samples: FloatArray, val sampleRate: Int)

internal object VoiceWavIO {
    fun readMonoFloat(file: File): FloatAudio {
        val info = WavUtils.readInfo(file)
        val bytesPerSample = info.bitsPerSample / 8
        require(bytesPerSample in 1..4) { "WAV bit depth غير مدعوم" }
        val frameBytes = bytesPerSample * info.channels
        val frames = (info.dataSize / frameBytes).toInt()
        val out = FloatArray(frames)

        RandomAccessFile(file, "r").use { raf ->
            raf.seek(info.dataOffset)
            for (i in 0 until frames) {
                var sum = 0f
                repeat(info.channels) {
                    sum += readSample(raf, info.audioFormat, info.bitsPerSample)
                }
                out[i] = (sum / info.channels.coerceAtLeast(1)).coerceIn(-1f, 1f)
            }
        }
        return FloatAudio(out, info.sampleRate)
    }

    fun writeMono24(file: File, samples: FloatArray, sampleRate: Int) {
        file.parentFile?.mkdirs()
        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(0)
            val dataSize = samples.size.toLong() * 3L
            WavUtils.writePcmHeader(raf, sampleRate, 1, 24, dataSize)
            samples.forEach { s ->
                val v = (s.coerceIn(-1f, 0.9999999f) * 8_388_607f).toInt()
                raf.write(v and 0xff)
                raf.write((v ushr 8) and 0xff)
                raf.write((v ushr 16) and 0xff)
            }
        }
    }

    /** Windowed-sinc resampler optimized for offline vocal conversion. */
    fun resampleSinc(input: FloatArray, srcRate: Int, dstRate: Int, taps: Int = 16): FloatArray {
        if (srcRate == dstRate || input.isEmpty()) return input.copyOf()
        val ratio = dstRate.toDouble() / srcRate.toDouble()
        val outSize = ceil(input.size * ratio).toInt().coerceAtLeast(1)
        val out = FloatArray(outSize)
        val cutoff = minOf(1.0, ratio) * 0.94

        for (i in 0 until outSize) {
            val srcPos = i / ratio
            val center = floor(srcPos).toInt()
            var sum = 0.0
            var norm = 0.0
            for (k in -taps..taps) {
                val idx = center + k
                if (idx !in input.indices) continue
                val x = srcPos - idx
                val ax = abs(x) / (taps + 1.0)
                if (ax >= 1.0) continue
                val sincArg = PI * x * cutoff
                val sinc = if (abs(sincArg) < 1e-9) 1.0 else sin(sincArg) / sincArg
                val window = 0.5 + 0.5 * cos(PI * ax)
                val w = sinc * window * cutoff
                sum += input[idx] * w
                norm += w
            }
            out[i] = if (abs(norm) > 1e-9) (sum / norm).toFloat().coerceIn(-1f, 1f) else 0f
        }
        return out
    }

    fun resizeLinear(input: FloatArray, target: Int): FloatArray {
        if (target <= 0) return FloatArray(0)
        if (input.isEmpty()) return FloatArray(target)
        if (input.size == target) return input.copyOf()
        if (target == 1) return floatArrayOf(input.first())
        val out = FloatArray(target)
        val scale = (input.size - 1).toDouble() / (target - 1).toDouble()
        for (i in out.indices) {
            val p = i * scale
            val a = floor(p).toInt().coerceIn(input.indices)
            val b = (a + 1).coerceAtMost(input.lastIndex)
            val t = (p - a).toFloat()
            out[i] = input[a] * (1f - t) + input[b] * t
        }
        return out
    }

    private fun readSample(raf: RandomAccessFile, format: Int, bits: Int): Float {
        if (format == 3 && bits == 32) {
            return Float.fromBits(readLeInt(raf)).coerceIn(-1f, 1f)
        }
        return when (bits) {
            8 -> ((raf.readUnsignedByte() - 128) / 128f).coerceIn(-1f, 1f)
            16 -> {
                val v = readLeShort(raf)
                val signed = if ((v and 0x8000) != 0) v - 0x10000 else v
                (signed / 32768f).coerceIn(-1f, 1f)
            }
            24 -> {
                val b0 = raf.readUnsignedByte()
                val b1 = raf.readUnsignedByte()
                val b2 = raf.readUnsignedByte()
                var v = b0 or (b1 shl 8) or (b2 shl 16)
                if ((v and 0x800000) != 0) v = v or -0x1000000
                (v / 8_388_608f).coerceIn(-1f, 1f)
            }
            32 -> (readLeInt(raf) / 2_147_483_648f).coerceIn(-1f, 1f)
            else -> error("WAV PCM $bits-bit غير مدعوم")
        }
    }

    private fun readLeShort(raf: RandomAccessFile): Int {
        val a = raf.readUnsignedByte()
        val b = raf.readUnsignedByte()
        return a or (b shl 8)
    }

    private fun readLeInt(raf: RandomAccessFile): Int {
        val a = raf.readUnsignedByte()
        val b = raf.readUnsignedByte()
        val c = raf.readUnsignedByte()
        val d = raf.readUnsignedByte()
        return a or (b shl 8) or (c shl 16) or (d shl 24)
    }
}

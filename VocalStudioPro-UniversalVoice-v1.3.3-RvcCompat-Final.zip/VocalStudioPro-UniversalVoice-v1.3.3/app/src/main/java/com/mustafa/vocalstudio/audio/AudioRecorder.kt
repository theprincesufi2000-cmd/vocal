package com.mustafa.vocalstudio.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class AudioRecorder(private val context: Context) {
    private val running = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private var recordThread: Thread? = null
    private var agc: AutomaticGainControl? = null
    private var ns: NoiseSuppressor? = null
    private var aec: AcousticEchoCanceler? = null

    fun isRecording(): Boolean = running.get()

    fun start(output: File) {
        check(!running.get()) { "Recorder already running" }

        val sampleRate = 48_000
        val rawMinBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        check(rawMinBuffer > 0) { "AudioRecord returned an invalid buffer size: $rawMinBuffer" }
        val minBuffer = rawMinBuffer.coerceAtLeast(sampleRate / 10)

        val source = if (supportsUnprocessed()) {
            MediaRecorder.AudioSource.UNPROCESSED
        } else {
            MediaRecorder.AudioSource.VOICE_RECOGNITION
        }

        val audioRecord = AudioRecord.Builder()
            .setAudioSource(source)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(minBuffer * 4)
            .build()

        check(audioRecord.state == AudioRecord.STATE_INITIALIZED) {
            runCatching { audioRecord.release() }
            "AudioRecord initialization failed"
        }

        var raf: RandomAccessFile? = null
        try {
            disablePlatformEffects(audioRecord.audioSessionId)

            output.parentFile?.mkdirs()
            raf = RandomAccessFile(output, "rw").apply {
                setLength(0)
                WavUtils.writePcmHeader(this, sampleRate, 1, 16, 0)
            }

            recorder = audioRecord
            running.set(true)
            audioRecord.startRecording()

            val file = requireNotNull(raf)
            recordThread = thread(name = "VocalStudioRecorder", isDaemon = true) {
                val buffer = ShortArray(minBuffer)
                var dataBytes = 0L
                try {
                    while (running.get()) {
                        val n = audioRecord.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                        when {
                            n > 0 -> {
                                for (i in 0 until n) {
                                    val v = buffer[i].toInt()
                                    file.write(v and 0xff)
                                    file.write((v ushr 8) and 0xff)
                                }
                                dataBytes += n * 2L
                            }
                            n == AudioRecord.ERROR_DEAD_OBJECT -> break
                            n < 0 && running.get() -> break
                        }
                    }
                } finally {
                    runCatching { audioRecord.stop() }
                    runCatching { audioRecord.release() }
                    runCatching { WavUtils.writePcmHeader(file, sampleRate, 1, 16, dataBytes) }
                    runCatching { file.close() }
                }
            }
        } catch (t: Throwable) {
            running.set(false)
            recorder = null
            runCatching { raf?.close() }
            runCatching { audioRecord.stop() }
            runCatching { audioRecord.release() }
            releasePlatformEffects()
            throw t
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return

        // Stop AudioRecord first so a blocking read() is released immediately.
        runCatching { recorder?.stop() }
        recordThread?.join(2_500)

        // Defensive fallback for vendor implementations that keep read() blocked.
        if (recordThread?.isAlive == true) {
            runCatching { recorder?.release() }
            recordThread?.join(500)
        }

        recordThread = null
        recorder = null
        releasePlatformEffects()
    }

    private fun supportsUnprocessed(): Boolean {
        val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return manager.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED)
            ?.equals("true", ignoreCase = true) == true
    }

    private fun disablePlatformEffects(sessionId: Int) {
        agc = runCatching { AutomaticGainControl.create(sessionId) }.getOrNull()?.also {
            runCatching { it.enabled = false }
        }
        ns = runCatching { NoiseSuppressor.create(sessionId) }.getOrNull()?.also {
            runCatching { it.enabled = false }
        }
        aec = runCatching { AcousticEchoCanceler.create(sessionId) }.getOrNull()?.also {
            runCatching { it.enabled = false }
        }
    }

    private fun releasePlatformEffects() {
        runCatching { agc?.release() }
        runCatching { ns?.release() }
        runCatching { aec?.release() }
        agc = null
        ns = null
        aec = null
    }
}

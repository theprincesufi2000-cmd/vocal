package com.mustafa.vocalstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mustafa.vocalstudio.ui.StudioScreen
import com.mustafa.vocalstudio.ui.VocalStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VocalStudioTheme {
                val vm: StudioViewModel = viewModel()
                StudioScreen(vm)
            }
        }
    }
}

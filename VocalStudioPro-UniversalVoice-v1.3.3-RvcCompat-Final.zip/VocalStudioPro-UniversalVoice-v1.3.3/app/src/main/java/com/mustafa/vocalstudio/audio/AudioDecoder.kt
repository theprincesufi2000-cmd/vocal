package com.mustafa.vocalstudio.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

object AudioDecoder {
    fun toWav(context: Context, uri: Uri, output: File): File {
        output.parentFile?.mkdirs()

        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        if (mime.contains("wav") || mime.contains("wave")) {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Cannot open input audio" }
                output.outputStream().use { out -> input.copyTo(out, 256 * 1024) }
            }

            // Keep compatible PCM/IEEE-float WAV files lossless.
            val directInfo = runCatching { WavUtils.readInfo(output) }.getOrNull()
            if (directInfo != null && directInfo.audioFormat in setOf(1, 3)) {
                return output
            }
            output.delete()
        }

        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        val pcmTemp = File(output.parentFile ?: context.cacheDir, output.nameWithoutExtension + ".pcm.tmp")
        pcmTemp.delete()

        try {
            extractor.setDataSource(context, uri, null)

            var track = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val candidate = extractor.getTrackFormat(i)
                val trackMime = candidate.getString(MediaFormat.KEY_MIME).orEmpty()
                if (trackMime.startsWith("audio/")) {
                    track = i
                    inputFormat = candidate
                    break
                }
            }

            require(track >= 0 && inputFormat != null) { "No decodable audio track found" }
            extractor.selectTrack(track)

            val selectedFormat = requireNotNull(inputFormat)
            val codecMime = selectedFormat.getString(MediaFormat.KEY_MIME)
                ?: error("Missing decoder MIME")

            val decoder = MediaCodec.createDecoderByType(codecMime).apply {
                configure(selectedFormat, null, null, 0)
                start()
            }
            codec = decoder

            var sampleRate = selectedFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = selectedFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            var inputDone = false
            var outputDone = false
            val info = MediaCodec.BufferInfo()

            RandomAccessFile(pcmTemp, "rw").use { pcmRaf ->
                pcmRaf.setLength(0)

                while (!outputDone) {
                    if (!inputDone) {
                        val inputIndex = decoder.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val inputBuffer = decoder.getInputBuffer(inputIndex)
                                ?: error("Decoder returned a null input buffer")
                            inputBuffer.clear()
                            val size = extractor.readSampleData(inputBuffer, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(
                                    inputIndex,
                                    0,
                                    0,
                                    0,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputDone = true
                            } else {
                                decoder.queueInputBuffer(
                                    inputIndex,
                                    0,
                                    size,
                                    extractor.sampleTime.coerceAtLeast(0L),
                                    0
                                )
                                extractor.advance()
                            }
                        }
                    }

                    when (val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = decoder.outputFormat
                            sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            pcmEncoding = if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                                f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                            } else {
                                AudioFormat.ENCODING_PCM_16BIT
                            }
                        }

                        MediaCodec.INFO_TRY_AGAIN_LATER -> Unit

                        else -> if (outputIndex >= 0) {
                            val out = decoder.getOutputBuffer(outputIndex)
                            if (out != null && info.size > 0) {
                                val start = info.offset
                                val end = info.offset + info.size
                                require(start >= 0 && end <= out.capacity()) { "Invalid decoder output range" }

                                val dup = out.duplicate().order(ByteOrder.LITTLE_ENDIAN)
                                dup.position(start)
                                dup.limit(end)
                                writeAsPcm16(
                                    dup.slice().order(ByteOrder.LITTLE_ENDIAN),
                                    pcmEncoding,
                                    pcmRaf
                                )
                            }

                            outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                            decoder.releaseOutputBuffer(outputIndex, false)
                        }
                    }
                }
            }

            require(sampleRate > 0 && channels > 0) { "Decoder returned invalid PCM format" }
            require(pcmTemp.length() > 0L) { "Decoder produced no PCM audio" }

            RandomAccessFile(output, "rw").use { wav ->
                wav.setLength(0)
                WavUtils.writePcmHeader(wav, sampleRate, channels, 16, pcmTemp.length())
                RandomAccessFile(pcmTemp, "r").use { pcm ->
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        val n = pcm.read(buffer)
                        if (n <= 0) break
                        wav.write(buffer, 0, n)
                    }
                }
            }

            return output
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
            pcmTemp.delete()
        }
    }

    private fun writeAsPcm16(buffer: ByteBuffer, encoding: Int, out: RandomAccessFile) {
        when (encoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> {
                while (buffer.remaining() >= 4) {
                    val s = buffer.float.coerceIn(-1f, 1f)
                    writeShort(out, (s * 32767f).toInt())
                }
            }

            AudioFormat.ENCODING_PCM_8BIT -> {
                while (buffer.hasRemaining()) {
                    val u = buffer.get().toInt() and 0xff
                    writeShort(out, (u - 128) shl 8)
                }
            }

            AudioFormat.ENCODING_PCM_24BIT_PACKED -> {
                while (buffer.remaining() >= 3) {
                    val b0 = buffer.get().toInt() and 0xff
                    val b1 = buffer.get().toInt() and 0xff
                    val b2 = buffer.get().toInt()
                    val value = b0 or (b1 shl 8) or (b2 shl 16)
                    writeShort(out, value shr 8)
                }
            }

            AudioFormat.ENCODING_PCM_32BIT -> {
                while (buffer.remaining() >= 4) {
                    writeShort(out, buffer.int shr 16)
                }
            }

            else -> {
                while (buffer.remaining() >= 2) {
                    writeShort(out, buffer.short.toInt())
                }
            }
        }
    }

    private fun writeShort(out: RandomAccessFile, value: Int) {
        val v = value.coerceIn(-32768, 32767)
        out.write(v and 0xff)
        out.write((v ushr 8) and 0xff)
    }
}

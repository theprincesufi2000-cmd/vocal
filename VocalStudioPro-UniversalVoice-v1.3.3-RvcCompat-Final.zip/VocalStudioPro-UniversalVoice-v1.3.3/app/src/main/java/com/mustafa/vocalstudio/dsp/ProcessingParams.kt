package com.mustafa.vocalstudio.dsp

data class ProcessingParams(
    val rootPitchClass: Int = 0,
    val scaleMode: Int = 0, // 0 major, 1 natural minor
    val strength: Float = 0.95f,
    val retuneMs: Float = 20f,
    val humanize: Float = 0.25f,

    val noiseReduction: Float = 0.62f,
    val clarity: Float = 0.66f,
    val warmth: Float = 0.34f,
    val air: Float = 0.52f,
    val deEsser: Float = 0.52f,
    val compression: Float = 0.68f,
    val leveling: Float = 0.72f,
    val reverb: Float = 0.14f
)

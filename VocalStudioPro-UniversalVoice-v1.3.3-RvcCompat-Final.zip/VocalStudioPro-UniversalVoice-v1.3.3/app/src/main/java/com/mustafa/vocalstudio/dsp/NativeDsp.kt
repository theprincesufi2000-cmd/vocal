package com.mustafa.vocalstudio.dsp

object NativeDsp {
    init { System.loadLibrary("vocal_dsp") }

    @JvmStatic external fun processWav(
        inputPath: String,
        outputPath: String,
        rootPitchClass: Int,
        scaleMode: Int,
        strength: Float,
        retuneMs: Float,
        humanize: Float,
        noiseReduction: Float,
        clarity: Float,
        warmth: Float,
        air: Float,
        deEsser: Float,
        compression: Float,
        leveling: Float,
        reverb: Float
    ): Int

    @JvmStatic external fun prepareForVoiceModel(
        inputPath: String,
        outputPath: String,
        rootPitchClass: Int,
        scaleMode: Int,
        strength: Float,
        retuneMs: Float,
        humanize: Float,
        noiseReduction: Float
    ): Int

    @JvmStatic external fun masterOnly(
        inputPath: String,
        outputPath: String,
        clarity: Float,
        warmth: Float,
        air: Float,
        deEsser: Float,
        compression: Float,
        leveling: Float,
        reverb: Float
    ): Int

    /**
     * Native F0 fallback used when a voice pack does not include a direct-F0 ONNX model.
     * Returns one Hz value per requested frame; unvoiced frames are 0.
     */
    @JvmStatic external fun extractF0(
        samples: FloatArray,
        sampleRate: Int,
        frameCount: Int,
        minHz: Float = 50f,
        maxHz: Float = 1_100f
    ): FloatArray

    @JvmStatic external fun engineVersion(): String
}

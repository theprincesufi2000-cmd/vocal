package com.mustafa.vocalstudio.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class WavPlayer {
    private val playing = AtomicBoolean(false)
    private var worker: Thread? = null
    private var track: AudioTrack? = null

    fun isPlaying(): Boolean = playing.get()

    fun play(file: File, onFinished: (() -> Unit)? = null) {
        stop()

        val info = WavUtils.readInfo(file)
        require(info.channels > 0) { "Invalid WAV channel count" }

        // Preserve mono/stereo. Multichannel source previews are safely downmixed
        // to mono; the native processing engine also produces a mono vocal master.
        val outputChannels = when (info.channels) {
            1 -> 1
            2 -> 2
            else -> 1
        }
        val channelMask = if (outputChannels == 1) {
            AudioFormat.CHANNEL_OUT_MONO
        } else {
            AudioFormat.CHANNEL_OUT_STEREO
        }

        val rawMin = AudioTrack.getMinBufferSize(
            info.sampleRate,
            channelMask,
            AudioFormat.ENCODING_PCM_16BIT
        )
        require(rawMin > 0) { "AudioTrack returned an invalid buffer size: $rawMin" }
        val minBuffer = rawMin.coerceAtLeast(16 * 1024)

        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(info.sampleRate)
                    .setChannelMask(channelMask)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(minBuffer * 2)
            .build()

        check(audioTrack.state == AudioTrack.STATE_INITIALIZED) {
            runCatching { audioTrack.release() }
            "AudioTrack initialization failed"
        }

        track = audioTrack
        playing.set(true)
        audioTrack.play()

        worker = thread(name = "VocalStudioPlayer", isDaemon = true) {
            try {
                RandomAccessFile(file, "r").use { raf ->
                    raf.seek(info.dataOffset)
                    val bytesPerSample = (info.bitsPerSample / 8).coerceAtLeast(1)
                    val inputFrameBytes = info.channels * bytesPerSample
                    val maxData = info.dataSize
                    var readData = 0L
                    val source = ByteArray(64 * 1024)
                    // Worst case: 8-bit mono expands 2x. Multichannel sources
                    // are downmixed, so 128 KiB is enough for this source block.
                    val pcm16 = ByteArray(128 * 1024)
                    val alignedCapacity = source.size - (source.size % inputFrameBytes)

                    while (playing.get() && readData < maxData) {
                        var wanted = minOf(alignedCapacity.toLong(), maxData - readData).toInt()
                        wanted -= wanted % inputFrameBytes
                        if (wanted <= 0) break

                        val n = raf.read(source, 0, wanted)
                        if (n <= 0) break
                        readData += n

                        val converted = convertTo16(
                            source = source,
                            length = n,
                            bits = info.bitsPerSample,
                            format = info.audioFormat,
                            inputChannels = info.channels,
                            outputChannels = outputChannels,
                            out = pcm16
                        )

                        var offset = 0
                        while (playing.get() && offset < converted) {
                            val written = audioTrack.write(
                                pcm16,
                                offset,
                                converted - offset,
                                AudioTrack.WRITE_BLOCKING
                            )
                            if (written <= 0) break
                            offset += written
                        }
                    }
                }
            } finally {
                playing.set(false)
                runCatching { audioTrack.stop() }
                runCatching { audioTrack.release() }
                if (track === audioTrack) track = null
                onFinished?.invoke()
            }
        }
    }

    fun stop() {
        playing.set(false)
        runCatching { track?.pause() }
        runCatching { track?.flush() }
        worker?.join(1_000)
        worker = null
        track = null
    }

    private fun convertTo16(
        source: ByteArray,
        length: Int,
        bits: Int,
        format: Int,
        inputChannels: Int,
        outputChannels: Int,
        out: ByteArray
    ): Int {
        val bytesPerSample = (bits / 8).coerceAtLeast(1)
        val inputFrameBytes = bytesPerSample * inputChannels
        if (inputFrameBytes <= 0) return 0

        if (format == 1 && bits == 16 && inputChannels == outputChannels) {
            val aligned = length - (length % inputFrameBytes)
            val n = minOf(aligned, out.size - (out.size % (2 * outputChannels)))
            source.copyInto(out, endIndex = n)
            return n
        }

        val frames = length / inputFrameBytes
        val maxFrames = out.size / (2 * outputChannels)
        val usableFrames = minOf(frames, maxFrames)
        var dst = 0

        repeat(usableFrames) { frame ->
            val frameOffset = frame * inputFrameBytes

            if (outputChannels == 1) {
                var sum = 0L
                for (channel in 0 until inputChannels) {
                    val src = frameOffset + channel * bytesPerSample
                    sum += decodeSample16(source, src, bits, format)
                }
                writePcm16(out, dst, (sum / inputChannels).toInt())
                dst += 2
            } else {
                for (channel in 0 until 2) {
                    val src = frameOffset + channel * bytesPerSample
                    writePcm16(out, dst, decodeSample16(source, src, bits, format))
                    dst += 2
                }
            }
        }

        return dst
    }

    private fun decodeSample16(source: ByteArray, src: Int, bits: Int, format: Int): Int {
        val value = when {
            format == 3 && bits == 32 -> {
                val raw = (source[src].toInt() and 0xff) or
                    ((source[src + 1].toInt() and 0xff) shl 8) or
                    ((source[src + 2].toInt() and 0xff) shl 16) or
                    ((source[src + 3].toInt() and 0xff) shl 24)
                (Float.fromBits(raw).coerceIn(-1f, 1f) * 32767f).toInt()
            }

            bits == 24 -> {
                var raw = (source[src].toInt() and 0xff) or
                    ((source[src + 1].toInt() and 0xff) shl 8) or
                    ((source[src + 2].toInt() and 0xff) shl 16)
                if ((raw and 0x800000) != 0) raw = raw or -0x1000000
                raw shr 8
            }

            bits == 32 -> {
                val raw = (source[src].toInt() and 0xff) or
                    ((source[src + 1].toInt() and 0xff) shl 8) or
                    ((source[src + 2].toInt() and 0xff) shl 16) or
                    ((source[src + 3].toInt() and 0xff) shl 24)
                raw shr 16
            }

            bits == 16 -> {
                val raw = (source[src].toInt() and 0xff) or
                    (source[src + 1].toInt() shl 8)
                raw.toShort().toInt()
            }

            bits == 8 -> ((source[src].toInt() and 0xff) - 128) shl 8
            else -> 0
        }

        return value.coerceIn(-32768, 32767)
    }

    private fun writePcm16(out: ByteArray, dst: Int, value: Int) {
        val v = value.coerceIn(-32768, 32767)
        out[dst] = (v and 0xff).toByte()
        out[dst + 1] = ((v ushr 8) and 0xff).toByte()
    }
}

package com.mustafa.vocalstudio.voice

enum class VoiceQuality { FAST, BALANCED, ULTRA }

data class VoiceConversionParams(
    val enabled: Boolean = false,
    val mix: Float = 0.92f,
    val transposeSemitones: Float = 0f,
    val consonantProtect: Float = 0.45f,
    val quality: VoiceQuality = VoiceQuality.BALANCED,
    val preferNnapi: Boolean = true
)

package com.mustafa.vocalstudio.voice

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import com.mustafa.vocalstudio.dsp.NativeDsp
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.nio.LongBuffer
import java.util.Random
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Offline RVC-style ONNX voice conversion runtime.
 *
 * Pack contract:
 *  - content_encoder.onnx: one float audio input -> phone/features tensor.
 *  - pitch.onnx: one float audio input -> F0 in Hz.
 *  - voice.onnx: RVC/Applio synthesizer. Common signatures include:
 *      official export: phone, phone_lengths, pitch, pitchf, ds, rnd
 *      Applio export:   feats, p_len, pitch, pitchf, sid
 *      non-F0 export:   feats, p_len, sid
 *
 * Runtime I/O is resolved from the live ONNX graph; persisted names are hints only.
 *
 * The app intentionally does not ship a person's voice model. Models are imported locally.
 */
class VoiceConversionEngine {
    data class Stats(
        val provider: String,
        val usedNnapi: Boolean,
        val chunks: Int,
        val sampleRate: Int,
        val durationSeconds: Double
    )

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()

    fun convert(
        inputWav: File,
        outputWav: File,
        model: VoiceModel,
        params: VoiceConversionParams,
        onProgress: (Float) -> Unit = {}
    ): Stats {
        model.validateReady()
        require(params.enabled) { "Voice Conversion غير مفعل" }

        val source = VoiceWavIO.readMonoFloat(inputWav)
        require(source.samples.size >= source.sampleRate / 3) { "الصوت أقصر من اللازم للتحويل" }

        val quality = qualityConfig(params.quality)
        val sessions = SessionBundle.open(env, model, quality.threads, params.preferNnapi)
        try {
            val chunkSamples = (quality.chunkSeconds * source.sampleRate).roundToInt().coerceAtLeast(source.sampleRate)
            val overlapSamples = (quality.overlapSeconds * source.sampleRate).roundToInt().coerceAtLeast(1)
            val step = (chunkSamples - overlapSamples).coerceAtLeast(source.sampleRate / 2)
            val starts = buildChunkStarts(source.samples.size, chunkSamples, step)

            // RVC ONNX files often do not embed their training/output sample rate in metadata or
            // filename (e.g. Nova_HD.onnx). Detect the effective rate from the first synthesized
            // chunk instead of blindly trusting the imported fallback value.
            val firstStart = starts.first()
            val firstEnd = minOf(source.samples.size, firstStart + chunkSamples)
            val firstChunk = source.samples.copyOfRange(firstStart, firstEnd)
            val firstResult = convertChunk(firstChunk, source.sampleRate, model, params, sessions, 0)
            val effectiveRate = estimateModelSampleRate(
                outputSamples = firstResult.audio.size,
                inputSamples = firstEnd - firstStart,
                inputRate = source.sampleRate,
                fallback = model.sampleRate
            )

            val totalOutSamples = ceil(source.samples.size.toDouble() * effectiveRate / source.sampleRate).toInt()
            val mixAccum = FloatArray(totalOutSamples)
            val weightAccum = FloatArray(totalOutSamples)

            starts.forEachIndexed { chunkIndex, start ->
                val end = minOf(source.samples.size, start + chunkSamples)
                val chunk = source.samples.copyOfRange(start, end)
                val chunkResult = if (chunkIndex == 0) firstResult
                    else convertChunk(chunk, source.sampleRate, model, params, sessions, chunkIndex)

                val expectedLen = ((end - start).toDouble() * effectiveRate / source.sampleRate)
                    .roundToInt()
                    .coerceAtLeast(1)
                val exact = VoiceWavIO.resizeLinear(chunkResult.audio, expectedLen)
                val original = VoiceWavIO.resizeLinear(
                    if (source.sampleRate == effectiveRate) chunk else VoiceWavIO.resampleSinc(chunk, source.sampleRate, effectiveRate),
                    expectedLen
                )

                val blended = FloatArray(expectedLen)
                for (i in blended.indices) {
                    val f0Index = if (chunkResult.f0.isEmpty()) 0 else
                        ((i.toLong() * chunkResult.f0.size) / expectedLen.coerceAtLeast(1)).toInt().coerceIn(0, chunkResult.f0.lastIndex)
                    val unvoiced = chunkResult.f0.getOrElse(f0Index) { 0f } <= 20f
                    val protect = if (unvoiced) params.consonantProtect.coerceIn(0f, 1f) else 0f
                    val convertedShare = (params.mix.coerceIn(0f, 1f) * (1f - protect)).coerceIn(0f, 1f)
                    blended[i] = (exact[i] * convertedShare + original[i] * (1f - convertedShare)).coerceIn(-1.2f, 1.2f)
                }

                val outStart = (start.toDouble() * effectiveRate / source.sampleRate).roundToInt()
                val overlapOut = (overlapSamples.toDouble() * effectiveRate / source.sampleRate).roundToInt().coerceAtLeast(1)
                val hasLeft = start > 0
                val hasRight = end < source.samples.size

                for (i in blended.indices) {
                    val dst = outStart + i
                    if (dst !in mixAccum.indices) break
                    var w = 1f
                    if (hasLeft && i < overlapOut) w *= i.toFloat() / overlapOut.toFloat()
                    if (hasRight && i >= blended.size - overlapOut) {
                        w *= (blended.size - 1 - i).coerceAtLeast(0).toFloat() / overlapOut.toFloat()
                    }
                    w = w.coerceIn(0.001f, 1f)
                    mixAccum[dst] += blended[i] * w
                    weightAccum[dst] += w
                }

                onProgress((chunkIndex + 1f) / starts.size.coerceAtLeast(1))
            }

            for (i in mixAccum.indices) {
                val w = weightAccum[i]
                if (w > 1e-6f) mixAccum[i] /= w
            }

            VoiceWavIO.writeMono24(outputWav, mixAccum, effectiveRate)
            return Stats(
                provider = sessions.provider,
                usedNnapi = sessions.provider == "NNAPI",
                chunks = starts.size,
                sampleRate = effectiveRate,
                durationSeconds = source.samples.size.toDouble() / source.sampleRate.toDouble()
            )
        } finally {
            sessions.close()
        }
    }

    private data class ChunkResult(val audio: FloatArray, val f0: FloatArray)

    private fun convertChunk(
        sourceChunk: FloatArray,
        sourceRate: Int,
        model: VoiceModel,
        params: VoiceConversionParams,
        sessions: SessionBundle,
        chunkIndex: Int
    ): ChunkResult {
        val contentAudio = if (sourceRate == model.contentSampleRate) sourceChunk
            else VoiceWavIO.resampleSinc(sourceChunk, sourceRate, model.contentSampleRate)

        var features = runContent(sessions.content, model, contentAudio)
        if (model.featureUpsample > 1) {
            features = upsampleFeatures(features, model.featureUpsample)
        }

        var f0 = if (sessions.pitch != null) {
            runPitch(sessions.pitch, model, contentAudio)
        } else {
            NativeDsp.extractF0(
                samples = contentAudio,
                sampleRate = model.contentSampleRate,
                frameCount = features.frames,
                minHz = 50f,
                maxHz = 1_100f
            )
        }
        f0 = resampleF0(f0, features.frames)

        val transposeFactor = 2.0.pow(params.transposeSemitones.coerceIn(-24f, 24f) / 12.0).toFloat()
        for (i in f0.indices) {
            if (f0[i] > 20f) f0[i] = (f0[i] * transposeFactor).coerceIn(20f, 2_000f)
            else f0[i] = 0f
        }
        val coarse = coarsePitch(f0)

        val voiceIo = resolveVoiceIo(sessions.voice, model)
        voiceIo.featureChannels?.let { expected ->
            require(features.channels == expected) {
                "Content features=${features.channels} لا تطابق مدخل نموذج RVC=$expected"
            }
        }
        val inputs = linkedMapOf<String, OnnxTensor>()
        try {
            val phoneInfo = voiceTensorInfo(sessions.voice, voiceIo.phone)
            require(phoneInfo.type == OnnxJavaType.FLOAT) {
                "مدخل features في RVC يجب أن يكون FLOAT وليس ${phoneInfo.type}"
            }
            inputs[voiceIo.phone] = floatTensor(
                features.data,
                featureShape(phoneInfo, features.frames, features.channels, voiceIo.phone)
            )

            val lenInfo = voiceTensorInfo(sessions.voice, voiceIo.phoneLengths)
            inputs[voiceIo.phoneLengths] = singleValueTensor(
                lenInfo,
                features.frames.toLong(),
                voiceIo.phoneLengths
            )

            if (voiceIo.pitch != null && voiceIo.pitchF != null) {
                val pitchInfo = voiceTensorInfo(sessions.voice, voiceIo.pitch)
                inputs[voiceIo.pitch] = integerSequenceTensor(
                    pitchInfo,
                    coarse,
                    features.frames,
                    voiceIo.pitch
                )

                val pitchFInfo = voiceTensorInfo(sessions.voice, voiceIo.pitchF)
                inputs[voiceIo.pitchF] = floatSequenceTensor(
                    pitchFInfo,
                    f0,
                    features.frames,
                    voiceIo.pitchF
                )
            }

            val speakerInfo = voiceTensorInfo(sessions.voice, voiceIo.speaker)
            inputs[voiceIo.speaker] = singleValueTensor(
                speakerInfo,
                model.speakerId,
                voiceIo.speaker
            )

            voiceIo.noise?.let { noiseName ->
                val noiseInfo = voiceTensorInfo(sessions.voice, noiseName)
                require(noiseInfo.type == OnnxJavaType.FLOAT) {
                    "مدخل noise في RVC يجب أن يكون FLOAT وليس ${noiseInfo.type}"
                }
                val shape = noiseShape(noiseInfo, features.frames, noiseName)
                val count = shape.fold(1L) { a, b -> a * b }.toInt()
                val rnd = gaussianNoise(count, seed = 0x51A7L + chunkIndex)
                inputs[noiseName] = floatTensor(rnd, shape)
            }

            sessions.voice.run(inputs).use { result ->
                val value = result.get(voiceIo.output).orElseThrow {
                    IllegalStateException("مخرج ${voiceIo.output} غير موجود في نموذج RVC")
                }
                require(value is OnnxTensor) { "مخرج نموذج RVC ليس Tensor" }
                val audio = value.floatBuffer?.copyToArray()
                    ?: error("مخرج نموذج RVC ليس Float tensor")
                require(audio.isNotEmpty()) { "نموذج RVC أعاد صوتًا فارغًا" }
                return ChunkResult(audio, f0)
            }
        } finally {
            inputs.values.forEach { runCatching { it.close() } }
        }
    }

    private data class FeatureMatrix(val data: FloatArray, val frames: Int, val channels: Int)

    private data class VoiceIo(
        val phone: String,
        val phoneLengths: String,
        val pitch: String?,
        val pitchF: String?,
        val speaker: String,
        val noise: String?,
        val output: String,
        val featureChannels: Int?
    )

    /**
     * Runs ContentVec/HuBERT without trusting persisted input/output names.
     *
     * Supported common exports include:
     *  - Transformers/voiceclonnx: input_values + attention_mask -> hidden_states
     *  - ozada/onnx_rvc: source (1,1,T) -> embed
     *  - simple custom exports: audio/waveform/input -> features/last_hidden_state
     *
     * This runtime introspection is deliberate: models installed by v1.3.1 may contain stale
     * metadata (e.g. contentInput="audio") even though the actual graph expects input_values.
     */
    private fun runContent(session: OrtSession, model: VoiceModel, audio: FloatArray): FeatureMatrix {
        val inputNames = session.inputNames
        val audioName = resolveActualName(
            inputNames,
            model.contentInput,
            "input_values", "source", "audio", "waveform", "wav", "speech", "input"
        ) ?: inputNames.firstOrNull { !it.lowercase().contains("mask") }
        ?: error("تعذر تحديد مدخل الصوت لـ Content Encoder. Inputs=${inputNames.joinToString()}")

        val audioInfo = session.inputInfo[audioName]?.info as? TensorInfo
            ?: error("مدخل $audioName في Content Encoder ليس Tensor")
        require(audioInfo.type == OnnxJavaType.FLOAT) {
            "Content Encoder يتوقع ${audioInfo.type} للصوت بدل FLOAT"
        }
        val audioShape = signalShape(audioInfo.shape.size, audio.size, audioName)

        val inputs = linkedMapOf<String, OnnxTensor>()
        try {
            inputs[audioName] = floatTensor(audio, audioShape)

            inputNames.filter { it != audioName }.forEach { name ->
                val info = session.inputInfo[name]?.info as? TensorInfo
                    ?: error("مدخل $name في Content Encoder ليس Tensor")
                val lower = name.lowercase()
                inputs[name] = when {
                    lower.contains("attention_mask") || lower == "attn_mask" ->
                        maskTensor(info, audio.size, active = true, inputName = name)
                    lower.contains("padding_mask") || lower == "pad_mask" ->
                        maskTensor(info, audio.size, active = false, inputName = name)
                    lower.contains("length") || lower.endsWith("_len") || lower == "len" ->
                        lengthTensor(info, audio.size, name)
                    else -> error(
                        "Content Encoder يحتوي مدخلًا إضافيًا غير معروف: $name (${info.type}, ${info.shape.contentToString()}). " +
                            "المدخلات: ${inputNames.joinToString()}"
                    )
                }
            }

            session.run(inputs).use { result ->
                val outputName = resolveContentOutput(session, model)
                val value = result.get(outputName).orElseThrow {
                    IllegalStateException("مخرج $outputName غير موجود في Content Encoder")
                }
                require(value is OnnxTensor) { "مخرج Content Encoder ليس Tensor" }
                val info = value.info as? TensorInfo ?: error("معلومات مخرج Content Encoder غير صالحة")
                require(info.type == OnnxJavaType.FLOAT) { "Content features ليست FLOAT بل ${info.type}" }
                val dims = info.shape
                val raw = value.floatBuffer?.copyToArray() ?: error("Content features ليست Float")
                require(raw.isNotEmpty()) { "Content Encoder أعاد features فارغة" }

                val declared = model.featureChannels
                val knownChannels = linkedSetOf(declared, 256, 768, 1024)
                val last = dims.lastOrNull()?.toInt() ?: -1
                val prev = dims.getOrNull(dims.size - 2)?.toInt() ?: -1

                val layout: String
                val channels: Int
                val frames: Int
                when {
                    dims.size >= 2 && last in knownChannels && last > 0 -> {
                        layout = "BTC"
                        channels = last
                        frames = raw.size / channels
                    }
                    dims.size >= 2 && prev in knownChannels && prev > 0 -> {
                        layout = "BCT"
                        channels = prev
                        frames = raw.size / channels
                    }
                    declared > 0 && raw.size % declared == 0 -> {
                        layout = if (model.contentOutputLayout == "BCT") "BCT" else "BTC"
                        channels = declared
                        frames = raw.size / channels
                    }
                    else -> error("تعذر تحديد أبعاد Content features: ${dims.contentToString()} / ${raw.size} values")
                }

                require(frames > 0 && channels > 0 && raw.size >= frames * channels) {
                    "Content features غير صالحة: frames=$frames channels=$channels size=${raw.size}"
                }

                if (layout == "BTC") {
                    return FeatureMatrix(raw.copyOf(frames * channels), frames, channels)
                }

                // BCT/CT -> transpose to time-major BTC expected by RVC net_g.
                val transposed = FloatArray(frames * channels)
                for (c in 0 until channels) {
                    for (t in 0 until frames) {
                        transposed[t * channels + c] = raw[c * frames + t]
                    }
                }
                return FeatureMatrix(transposed, frames, channels)
            }
        } finally {
            inputs.values.forEach { runCatching { it.close() } }
        }
    }

    private fun runPitch(session: OrtSession, model: VoiceModel, audio: FloatArray): FloatArray {
        val inputNames = session.inputNames
        val inputName = resolveActualName(
            inputNames,
            model.pitchInput,
            "audio", "waveform", "input_values", "source", "input"
        ) ?: inputNames.firstOrNull()
        ?: error("pitch.onnx لا يحتوي مدخلات")
        val inputInfo = session.inputInfo[inputName]?.info as? TensorInfo
            ?: error("مدخل $inputName في pitch.onnx ليس Tensor")
        require(inputInfo.type == OnnxJavaType.FLOAT) { "Pitch input يجب أن يكون FLOAT" }

        val inputs = linkedMapOf<String, OnnxTensor>()
        try {
            inputs[inputName] = floatTensor(audio, signalShape(inputInfo.shape.size, audio.size, inputName))
            inputNames.filter { it != inputName }.forEach { name ->
                val info = session.inputInfo[name]?.info as? TensorInfo
                    ?: error("مدخل $name في pitch.onnx ليس Tensor")
                val lower = name.lowercase()
                inputs[name] = when {
                    lower.contains("attention_mask") -> maskTensor(info, audio.size, true, name)
                    lower.contains("padding_mask") -> maskTensor(info, audio.size, false, name)
                    lower.contains("length") || lower.endsWith("_len") -> lengthTensor(info, audio.size, name)
                    else -> error("pitch.onnx يحتوي مدخلًا إضافيًا غير معروف: $name")
                }
            }

            session.run(inputs).use { result ->
                val outputName = resolveActualName(
                    session.outputNames,
                    model.pitchOutput,
                    "f0", "pitch", "frequency", "output"
                ) ?: session.outputNames.firstOrNull() ?: error("pitch.onnx لا يحتوي مخرجات")
                val value = result.get(outputName).orElseThrow {
                    IllegalStateException("مخرج $outputName غير موجود في pitch.onnx")
                }
                require(value is OnnxTensor) { "مخرج pitch ليس Tensor" }
                val info = value.info as? TensorInfo ?: error("Pitch output info غير صالح")
                val dims = info.shape
                val raw = value.floatBuffer?.copyToArray() ?: error("Pitch output ليس Float")
                // Raw RMVPE salience is [T,360] and needs mel preprocessing + decoder; do not
                // silently interpret those logits as Hz. Native F0 is used unless a direct-F0
                // model was classified at import time.
                require(dims.lastOrNull() != 360L) {
                    "RMVPE الخام (360 bins) يحتاج decoder خاص؛ احذف pitch.onnx ليستخدم Native F0 أو استورد Direct-F0 ONNX"
                }
                return raw.mapToFloatArray { v -> if (v.isFinite() && v in 20f..2_000f) v else 0f }
            }
        } finally {
            inputs.values.forEach { runCatching { it.close() } }
        }
    }

    private fun resolveContentOutput(session: OrtSession, model: VoiceModel): String {
        resolveActualName(
            session.outputNames,
            model.contentOutput,
            "hidden_states", "last_hidden_state", "embed", "embeddings", "features", "feature", "output"
        )?.let { return it }

        return session.outputInfo.entries.firstOrNull { (_, node) ->
            val info = node.info as? TensorInfo
            info != null && info.type == OnnxJavaType.FLOAT && info.shape.size in 2..3
        }?.key ?: session.outputNames.firstOrNull()
        ?: error("Content Encoder لا يحتوي مخرجات")
    }

    private fun resolveVoiceIo(session: OrtSession, model: VoiceModel): VoiceIo {
        val names = session.inputNames
        val infos = session.inputInfo

        fun byAliases(preferred: String?, vararg aliases: String): String? =
            resolveActualName(names, preferred, *aliases)

        fun tensor(name: String): TensorInfo? = infos[name]?.info as? TensorInfo
        fun lower(name: String) = name.lowercase()

        // 1) Semantic aliases first. These cover official RVC, Applio and common community exports.
        val phone = byAliases(
            model.voicePhoneInput,
            "phone", "phones", "features", "feature", "feats", "hubert", "content", "units"
        ) ?: names.firstOrNull { name ->
            val info = tensor(name) ?: return@firstOrNull false
            val shape = info.shape
            info.type == OnnxJavaType.FLOAT && shape.size in 2..3 &&
                shape.any { it in setOf(256L, 768L, 1024L) } &&
                !lower(name).contains("noise")
        } ?: error("تعذر تحديد مدخل features في نموذج RVC. Inputs=${names.joinToString()}")

        val phoneLengths = byAliases(
            model.voicePhoneLengthsInput,
            "phone_lengths", "phone_length", "p_len", "p_length", "lengths", "length",
            "seq_len", "seq_length", "input_lengths", "feature_lengths", "len"
        ) ?: names.firstOrNull { name ->
            name != phone && run {
                val l = lower(name)
                val info = tensor(name)
                info != null && info.shape.size <= 2 &&
                    info.type in setOf(OnnxJavaType.INT64, OnnxJavaType.INT32) &&
                    (l.contains("len") || l.contains("length"))
            }
        } ?: error("تعذر تحديد مدخل طول RVC (p_len/phone_lengths). Inputs=${names.joinToString()}")

        val speaker = byAliases(
            model.voiceSpeakerInput,
            "ds", "sid", "speaker", "speaker_id", "spk", "spk_id", "speakerid"
        ) ?: names.firstOrNull { name ->
            name !in setOf(phone, phoneLengths) && run {
                val info = tensor(name)
                info != null && info.shape.size <= 2 &&
                    info.type in setOf(OnnxJavaType.INT64, OnnxJavaType.INT32) &&
                    lower(name).let { it.contains("speaker") || it.contains("sid") || it.contains("spk") }
            }
        } ?: error("تعذر تحديد مدخل speaker/sid في نموذج RVC. Inputs=${names.joinToString()}")

        val pitch = byAliases(
            model.voicePitchInput,
            "pitch", "pitch_coarse", "f0_coarse", "coarse_f0", "pitchc"
        )
        val pitchF = byAliases(
            model.voicePitchFInput,
            "pitchf", "pitch_f", "f0", "f0f", "f0_float", "fundamental_frequency"
        )

        // F0 models must expose both coarse pitch and continuous F0. Non-F0 RVC exports expose neither.
        require((pitch == null) == (pitchF == null)) {
            "نموذج RVC يحتوي مدخل Pitch غير مكتمل. pitch=$pitch pitchf=$pitchF Inputs=${names.joinToString()}"
        }

        val noise = byAliases(
            model.voiceNoiseInput,
            "rnd", "noise", "z", "rand", "random", "noise_scale"
        ) ?: names.firstOrNull { name ->
            name !in listOfNotNull(phone, phoneLengths, pitch, pitchF, speaker) && run {
                val info = tensor(name)
                info != null && info.type == OnnxJavaType.FLOAT && info.shape.size >= 2 &&
                    (info.shape.any { it == 192L } || lower(name).contains("noise") || lower(name) == "rnd")
            }
        }

        // Reject unknown required inputs instead of sending a partially-populated map to ORT.
        val mapped = listOfNotNull(phone, phoneLengths, pitch, pitchF, speaker, noise).toSet()
        val unmapped = names.filterNot { it in mapped }
        require(unmapped.isEmpty()) {
            "نموذج RVC يحتوي مدخلات إضافية غير معروفة: ${unmapped.joinToString()}. Inputs=${names.joinToString()}"
        }

        val phoneInfo = tensor(phone)
        val featureChannels = phoneInfo?.shape?.firstOrNull { it in setOf(256L, 768L, 1024L) }?.toInt()
        val output = resolveActualName(
            session.outputNames,
            model.voiceOutput,
            "audio", "waveform", "wav", "output", "audio_out", "y"
        ) ?: session.outputNames.firstOrNull() ?: error("نموذج RVC لا يحتوي مخرجات")

        return VoiceIo(
            phone = phone,
            phoneLengths = phoneLengths,
            pitch = pitch,
            pitchF = pitchF,
            speaker = speaker,
            noise = noise,
            output = output,
            featureChannels = featureChannels
        )
    }

    private fun voiceTensorInfo(session: OrtSession, name: String): TensorInfo =
        session.inputInfo[name]?.info as? TensorInfo
            ?: error("مدخل $name في نموذج RVC ليس Tensor")

    private fun featureShape(info: TensorInfo, frames: Int, channels: Int, inputName: String): LongArray =
        when (info.shape.size) {
            2 -> longArrayOf(frames.toLong(), channels.toLong())
            3 -> longArrayOf(1, frames.toLong(), channels.toLong())
            else -> error("رتبة مدخل features $inputName غير مدعومة: ${info.shape.size}")
        }

    private fun sequenceShape(info: TensorInfo, frames: Int, inputName: String): LongArray =
        when (info.shape.size) {
            1 -> longArrayOf(frames.toLong())
            2 -> longArrayOf(1, frames.toLong())
            3 -> longArrayOf(1, 1, frames.toLong())
            else -> error("رتبة مدخل $inputName غير مدعومة: ${info.shape.size}")
        }

    private fun integerSequenceTensor(
        info: TensorInfo,
        values: LongArray,
        frames: Int,
        inputName: String
    ): OnnxTensor {
        val shape = sequenceShape(info, frames, inputName)
        return when (info.type) {
            OnnxJavaType.INT64 -> longTensor(values, shape)
            OnnxJavaType.INT32 -> intTensor(IntArray(values.size) { values[it].toInt() }, shape)
            else -> error("نوع $inputName يجب أن يكون INT64/INT32 وليس ${info.type}")
        }
    }

    private fun floatSequenceTensor(
        info: TensorInfo,
        values: FloatArray,
        frames: Int,
        inputName: String
    ): OnnxTensor {
        require(info.type == OnnxJavaType.FLOAT) {
            "نوع $inputName يجب أن يكون FLOAT وليس ${info.type}"
        }
        return floatTensor(values, sequenceShape(info, frames, inputName))
    }

    private fun singleValueTensor(
        info: TensorInfo,
        value: Long,
        inputName: String
    ): OnnxTensor {
        val shape = when (info.shape.size) {
            0 -> longArrayOf()
            1 -> longArrayOf(1)
            2 -> longArrayOf(1, 1)
            else -> error("رتبة مدخل $inputName غير مدعومة للقيمة المفردة: ${info.shape.size}")
        }
        return when (info.type) {
            OnnxJavaType.INT64 -> longTensor(longArrayOf(value), shape)
            OnnxJavaType.INT32 -> intTensor(intArrayOf(value.toInt()), shape)
            OnnxJavaType.FLOAT -> floatTensor(floatArrayOf(value.toFloat()), shape)
            else -> error("نوع $inputName غير مدعوم: ${info.type}")
        }
    }

    private fun noiseShape(info: TensorInfo, frames: Int, inputName: String): LongArray {
        val declared = info.shape
        require(declared.size in 2..4) {
            "رتبة noise $inputName غير مدعومة: ${declared.size}"
        }
        var dynamicSeen = 0
        return LongArray(declared.size) { i ->
            val d = declared[i]
            when {
                d > 0 -> d
                i == declared.lastIndex -> frames.toLong()
                i == 0 -> 1L
                dynamicSeen++ == 0 -> 192L
                else -> 1L
            }
        }
    }

    private fun resolveActualName(names: Collection<String>, preferred: String?, vararg aliases: String): String? {
        if (!preferred.isNullOrBlank()) {
            names.firstOrNull { it == preferred }?.let { return it }
            names.firstOrNull { it.equals(preferred, ignoreCase = true) }?.let { return it }
        }
        return OnnxModelProbe.findName(names, *aliases)
    }

    private fun signalShape(rank: Int, samples: Int, inputName: String): LongArray = when (rank) {
        0, 1 -> longArrayOf(samples.toLong())
        2 -> longArrayOf(1, samples.toLong())
        3 -> longArrayOf(1, 1, samples.toLong())
        else -> error("رتبة مدخل $inputName غير مدعومة: $rank")
    }

    private fun maskShape(rank: Int, samples: Int): LongArray = when (rank) {
        0, 1 -> longArrayOf(samples.toLong())
        2 -> longArrayOf(1, samples.toLong())
        3 -> longArrayOf(1, 1, samples.toLong())
        else -> error("رتبة mask غير مدعومة: $rank")
    }

    private fun maskTensor(info: TensorInfo, samples: Int, active: Boolean, inputName: String): OnnxTensor {
        val shape = maskShape(info.shape.size, samples)
        val count = shape.fold(1L) { a, b -> a * b }.toInt()
        return when (info.type) {
            OnnxJavaType.INT64 -> longTensor(LongArray(count) { if (active) 1L else 0L }, shape)
            OnnxJavaType.INT32 -> intTensor(IntArray(count) { if (active) 1 else 0 }, shape)
            OnnxJavaType.FLOAT -> floatTensor(FloatArray(count) { if (active) 1f else 0f }, shape)
            OnnxJavaType.BOOL -> boolTensor(BooleanArray(count) { active }, shape)
            else -> error("نوع $inputName غير مدعوم للـmask: ${info.type}")
        }
    }

    private fun lengthTensor(info: TensorInfo, samples: Int, inputName: String): OnnxTensor {
        val shape = when (info.shape.size) {
            0, 1 -> longArrayOf(1)
            2 -> longArrayOf(1, 1)
            else -> error("رتبة $inputName غير مدعومة: ${info.shape.size}")
        }
        return when (info.type) {
            OnnxJavaType.INT64 -> longTensor(longArrayOf(samples.toLong()), shape)
            OnnxJavaType.INT32 -> intTensor(intArrayOf(samples), shape)
            OnnxJavaType.FLOAT -> floatTensor(floatArrayOf(samples.toFloat()), shape)
            else -> error("نوع $inputName غير مدعوم للطول: ${info.type}")
        }
    }

    private fun upsampleFeatures(input: FeatureMatrix, factor: Int): FeatureMatrix {
        if (factor <= 1) return input
        val outFrames = input.frames * factor
        val out = FloatArray(outFrames * input.channels)
        for (t in 0 until outFrames) {
            val p = t.toDouble() / factor.toDouble()
            val a = floor(p).toInt().coerceIn(0, input.frames - 1)
            val b = (a + 1).coerceAtMost(input.frames - 1)
            val mix = (p - a).toFloat()
            for (c in 0 until input.channels) {
                val av = input.data[a * input.channels + c]
                val bv = input.data[b * input.channels + c]
                out[t * input.channels + c] = av * (1f - mix) + bv * mix
            }
        }
        return FeatureMatrix(out, outFrames, input.channels)
    }

    private fun resampleF0(input: FloatArray, frames: Int): FloatArray {
        if (frames <= 0) return FloatArray(0)
        if (input.isEmpty()) return FloatArray(frames)
        if (input.size == frames) return input.copyOf()
        if (frames == 1) return floatArrayOf(input.first())
        val out = FloatArray(frames)
        val scale = (input.size - 1).toDouble() / (frames - 1).toDouble()
        for (i in out.indices) {
            val p = i * scale
            val a = floor(p).toInt().coerceIn(input.indices)
            val b = (a + 1).coerceAtMost(input.lastIndex)
            val t = (p - a).toFloat()
            val av = input[a]
            val bv = input[b]
            out[i] = when {
                av <= 20f && bv <= 20f -> 0f
                av <= 20f -> if (t > 0.65f) bv else 0f
                bv <= 20f -> if (t < 0.35f) av else 0f
                else -> av * (1f - t) + bv * t
            }
        }
        return out
    }

    private fun coarsePitch(f0: FloatArray): LongArray {
        val f0Min = 50.0
        val f0Max = 1100.0
        val melMin = 1127.0 * ln(1.0 + f0Min / 700.0)
        val melMax = 1127.0 * ln(1.0 + f0Max / 700.0)
        return LongArray(f0.size) { i ->
            val hz = f0[i].toDouble()
            var mel = if (hz > 0.0) 1127.0 * ln(1.0 + hz / 700.0) else 0.0
            if (mel > 0.0) mel = (mel - melMin) * 254.0 / (melMax - melMin) + 1.0
            mel.roundToInt().coerceIn(1, 255).toLong()
        }
    }

    private fun estimateModelSampleRate(
        outputSamples: Int,
        inputSamples: Int,
        inputRate: Int,
        fallback: Int
    ): Int {
        if (outputSamples <= 0 || inputSamples <= 0 || inputRate <= 0) return fallback
        val estimated = outputSamples.toDouble() * inputRate.toDouble() / inputSamples.toDouble()
        val common = intArrayOf(32_000, 40_000, 44_100, 48_000, 50_000, 64_000)
        val nearest = common.minByOrNull { kotlin.math.abs(it - estimated) } ?: fallback
        val tolerance = maxOf(1_200.0, nearest * 0.08)
        return if (kotlin.math.abs(nearest - estimated) <= tolerance) nearest
        else ((estimated / 1_000.0).roundToInt() * 1_000).coerceIn(16_000, 96_000)
    }

    private fun gaussianNoise(size: Int, seed: Long): FloatArray {
        val random = Random(seed)
        val out = FloatArray(size)
        var i = 0
        while (i < size) {
            val u1 = (random.nextDouble().coerceAtLeast(1e-12))
            val u2 = random.nextDouble()
            val mag = sqrt(-2.0 * ln(u1))
            val z0 = mag * kotlin.math.cos(2.0 * Math.PI * u2)
            val z1 = mag * kotlin.math.sin(2.0 * Math.PI * u2)
            out[i++] = z0.toFloat()
            if (i < size) out[i++] = z1.toFloat()
        }
        return out
    }

    private fun floatTensor(data: FloatArray, shape: LongArray): OnnxTensor =
        OnnxTensor.createTensor(env, directFloatBuffer(data), shape)

    private fun longTensor(data: LongArray, shape: LongArray): OnnxTensor =
        OnnxTensor.createTensor(env, directLongBuffer(data), shape)

    private fun intTensor(data: IntArray, shape: LongArray): OnnxTensor =
        OnnxTensor.createTensor(env, directIntBuffer(data), shape)

    private fun boolTensor(data: BooleanArray, shape: LongArray): OnnxTensor {
        val buffer = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
        data.forEach { buffer.put(if (it) 1.toByte() else 0.toByte()) }
        buffer.rewind()
        return OnnxTensor.createTensor(env, buffer, shape, OnnxJavaType.BOOL)
    }

    private fun directFloatBuffer(data: FloatArray): FloatBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buffer.put(data)
        buffer.rewind()
        return buffer
    }

    private fun directLongBuffer(data: LongArray): LongBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 8).order(ByteOrder.nativeOrder()).asLongBuffer()
        buffer.put(data)
        buffer.rewind()
        return buffer
    }

    private fun directIntBuffer(data: IntArray): IntBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer()
        buffer.put(data)
        buffer.rewind()
        return buffer
    }

    private fun FloatBuffer.copyToArray(): FloatArray {
        val dup = duplicate()
        dup.rewind()
        return FloatArray(dup.remaining()).also { dup.get(it) }
    }

    private inline fun FloatArray.mapToFloatArray(transform: (Float) -> Float): FloatArray =
        FloatArray(size) { i -> transform(this[i]) }

    private fun buildChunkStarts(totalSamples: Int, chunkSamples: Int, step: Int): List<Int> {
        if (totalSamples <= chunkSamples) return listOf(0)
        val starts = ArrayList<Int>()
        var start = 0
        while (start + chunkSamples < totalSamples) {
            starts += start
            start += step
        }
        val finalStart = (totalSamples - chunkSamples).coerceAtLeast(0)
        if (starts.isEmpty() || starts.last() != finalStart) starts += finalStart
        return starts.distinct()
    }

    private data class QualityConfig(val chunkSeconds: Double, val overlapSeconds: Double, val threads: Int)

    private fun qualityConfig(q: VoiceQuality): QualityConfig {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
        return when (q) {
            VoiceQuality.FAST -> QualityConfig(4.0, 0.20, minOf(2, cores))
            VoiceQuality.BALANCED -> QualityConfig(6.0, 0.30, minOf(4, cores))
            VoiceQuality.ULTRA -> QualityConfig(8.0, 0.40, minOf(6, cores))
        }
    }

    private data class SessionBundle(
        val content: OrtSession,
        val pitch: OrtSession?,
        val voice: OrtSession,
        val provider: String
    ) : AutoCloseable {
        override fun close() {
            runCatching { content.close() }
            pitch?.let { runCatching { it.close() } }
            runCatching { voice.close() }
        }

        companion object {
            private enum class Provider { NNAPI, XNNPACK, CPU }

            fun open(env: OrtEnvironment, model: VoiceModel, threads: Int, preferNnapi: Boolean): SessionBundle {
                if (preferNnapi) {
                    openWithProvider(env, model, threads, Provider.NNAPI)?.let { return it }
                }
                openWithProvider(env, model, threads, Provider.XNNPACK)?.let { return it }
                return openWithProvider(env, model, threads, Provider.CPU)
                    ?: error("تعذر فتح نماذج ONNX على NNAPI/XNNPACK/CPU")
            }

            private fun openWithProvider(
                env: OrtEnvironment,
                model: VoiceModel,
                threads: Int,
                provider: Provider
            ): SessionBundle? = runCatching {
                val c = create(env, model.contentModel, threads, provider)
                try {
                    val p = if (model.hasPitchModel) create(env, model.pitchModel, threads, provider) else null
                    try {
                        val v = create(env, model.voiceModel, threads, provider)
                        SessionBundle(c, p, v, provider.name)
                    } catch (t: Throwable) {
                        p?.close()
                        throw t
                    }
                } catch (t: Throwable) {
                    c.close()
                    throw t
                }
            }.getOrNull()

            private fun create(
                env: OrtEnvironment,
                file: File,
                threads: Int,
                provider: Provider
            ): OrtSession {
                val options = OrtSession.SessionOptions()
                try {
                    options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                    options.setInterOpNumThreads(1)
                    options.setMemoryPatternOptimization(true)
                    when (provider) {
                        Provider.NNAPI -> {
                            options.setIntraOpNumThreads(threads.coerceAtLeast(1))
                            options.addNnapi()
                        }
                        Provider.XNNPACK -> {
                            // XNNPACK owns its worker pool; keep ORT's CPU pool minimal.
                            options.setIntraOpNumThreads(1)
                            options.addXnnpack(
                                mapOf("intra_op_num_threads" to threads.coerceAtLeast(1).toString())
                            )
                        }
                        Provider.CPU -> options.setIntraOpNumThreads(threads.coerceAtLeast(1))
                    }
                    return env.createSession(file.absolutePath, options)
                } finally {
                    options.close()
                }
            }
        }
    }
}

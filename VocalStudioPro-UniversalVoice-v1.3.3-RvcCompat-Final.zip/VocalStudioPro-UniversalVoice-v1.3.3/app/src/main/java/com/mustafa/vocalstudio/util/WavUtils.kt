package com.mustafa.vocalstudio.util

import java.io.File
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.max

data class WavInfo(
    val audioFormat: Int,
    val channels: Int,
    val sampleRate: Int,
    val bitsPerSample: Int,
    val dataOffset: Long,
    val dataSize: Long
)

object WavUtils {
    fun readInfo(file: File): WavInfo {
        RandomAccessFile(file, "r").use { raf ->
            require(readAscii(raf, 4) == "RIFF") { "Not a RIFF WAV file" }
            raf.skipBytes(4)
            require(readAscii(raf, 4) == "WAVE") { "Invalid WAV header" }

            var format = 1
            var channels = 1
            var sampleRate = 48_000
            var bits = 16
            var dataOffset = -1L
            var dataSize = 0L

            while (raf.filePointer + 8 <= raf.length()) {
                val id = readAscii(raf, 4)
                val size = readLeInt(raf).toLong() and 0xffffffffL
                val chunkStart = raf.filePointer

                when (id) {
                    "fmt " -> {
                        format = readLeShort(raf)
                        channels = readLeShort(raf)
                        sampleRate = readLeInt(raf)
                        raf.skipBytes(6)
                        bits = readLeShort(raf)
                        // WAVE_FORMAT_EXTENSIBLE stores the real PCM/float
                        // sub-format GUID at byte 24 of the fmt payload.
                        if (format == 0xfffe && size >= 40) {
                            raf.seek(chunkStart + 24)
                            format = readLeInt(raf) and 0xffff
                        }
                    }
                    "data" -> {
                        dataOffset = raf.filePointer
                        dataSize = minOf(size, raf.length() - raf.filePointer)
                        break
                    }
                }

                val next = chunkStart + size + (size and 1L)
                if (next > raf.length()) break
                raf.seek(next)
            }

            require(dataOffset >= 0L && dataSize > 0L) { "WAV has no audio data" }
            return WavInfo(format, channels, sampleRate, bits, dataOffset, dataSize)
        }
    }

    fun writePcmHeader(
        raf: RandomAccessFile,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int,
        dataSize: Long
    ) {
        val blockAlign = channels * bitsPerSample / 8
        val byteRate = sampleRate * blockAlign
        raf.seek(0)
        raf.writeBytes("RIFF")
        writeLeInt(raf, (36L + dataSize).coerceAtMost(0xffffffffL).toInt())
        raf.writeBytes("WAVE")
        raf.writeBytes("fmt ")
        writeLeInt(raf, 16)
        writeLeShort(raf, 1)
        writeLeShort(raf, channels)
        writeLeInt(raf, sampleRate)
        writeLeInt(raf, byteRate)
        writeLeShort(raf, blockAlign)
        writeLeShort(raf, bitsPerSample)
        raf.writeBytes("data")
        writeLeInt(raf, dataSize.coerceAtMost(0xffffffffL).toInt())
    }

    fun waveform(file: File, bars: Int = 96): List<Float> {
        if (!file.exists() || file.length() < 44) return emptyList()
        val info = runCatching { readInfo(file) }.getOrNull() ?: return emptyList()
        val bytesPerSample = max(1, info.bitsPerSample / 8)
        val frameBytes = bytesPerSample * info.channels
        if (frameBytes <= 0) return emptyList()
        val frames = info.dataSize / frameBytes
        if (frames <= 0) return emptyList()
        val step = max(1L, frames / bars)

        val peaks = ArrayList<Float>(bars)
        RandomAccessFile(file, "r").use { raf ->
            for (b in 0 until bars) {
                val startFrame = b * step
                if (startFrame >= frames) {
                    peaks += 0f
                    continue
                }
                raf.seek(info.dataOffset + startFrame * frameBytes)
                val sampleCount = minOf(step, 2048L, frames - startFrame).toInt()
                var peak = 0f
                repeat(sampleCount) {
                    var mono = 0f
                    repeat(info.channels) {
                        mono += readNormalizedSample(raf, info.bitsPerSample, info.audioFormat)
                    }
                    mono /= info.channels.toFloat()
                    peak = max(peak, abs(mono))
                }
                peaks += peak.coerceIn(0f, 1f)
            }
        }
        val global = peaks.maxOrNull()?.coerceAtLeast(0.05f) ?: 1f
        return peaks.map { (it / global).coerceIn(0.03f, 1f) }
    }

    private fun readNormalizedSample(raf: RandomAccessFile, bits: Int, format: Int): Float {
        if (format == 3 && bits == 32) {
            return Float.fromBits(readLeInt(raf)).coerceIn(-1f, 1f)
        }
        return when (bits) {
            8 -> ((raf.readUnsignedByte() - 128) / 128f).coerceIn(-1f, 1f)
            16 -> {
                val v = readLeShortSigned(raf)
                (v / 32768f).coerceIn(-1f, 1f)
            }
            24 -> {
                val b0 = raf.readUnsignedByte()
                val b1 = raf.readUnsignedByte()
                val b2 = raf.readUnsignedByte()
                var v = b0 or (b1 shl 8) or (b2 shl 16)
                if ((v and 0x800000) != 0) v = v or -0x1000000
                (v / 8388608f).coerceIn(-1f, 1f)
            }
            32 -> (readLeInt(raf) / 2147483648f).coerceIn(-1f, 1f)
            else -> 0f
        }
    }

    private fun readAscii(raf: RandomAccessFile, len: Int): String {
        val data = ByteArray(len)
        raf.readFully(data)
        return data.toString(Charsets.US_ASCII)
    }

    private fun readLeShort(raf: RandomAccessFile): Int {
        val a = raf.readUnsignedByte()
        val b = raf.readUnsignedByte()
        return a or (b shl 8)
    }

    private fun readLeShortSigned(raf: RandomAccessFile): Int {
        val v = readLeShort(raf)
        return if ((v and 0x8000) != 0) v - 0x10000 else v
    }

    private fun readLeInt(raf: RandomAccessFile): Int {
        val a = raf.readUnsignedByte()
        val b = raf.readUnsignedByte()
        val c = raf.readUnsignedByte()
        val d = raf.readUnsignedByte()
        return a or (b shl 8) or (c shl 16) or (d shl 24)
    }

    private fun writeLeShort(raf: RandomAccessFile, value: Int) {
        raf.write(value and 0xff)
        raf.write((value ushr 8) and 0xff)
    }

    private fun writeLeInt(raf: RandomAccessFile, value: Int) {
        raf.write(value and 0xff)
        raf.write((value ushr 8) and 0xff)
        raf.write((value ushr 16) and 0xff)
        raf.write((value ushr 24) and 0xff)
    }
}

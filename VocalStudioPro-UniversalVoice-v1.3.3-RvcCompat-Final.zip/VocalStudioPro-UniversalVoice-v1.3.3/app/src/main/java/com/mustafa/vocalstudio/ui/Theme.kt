package com.mustafa.vocalstudio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VocalColors = darkColorScheme(
    primary = Color(0xFF9B7BFF),
    onPrimary = Color(0xFF090B12),
    secondary = Color(0xFF33D6E9),
    tertiary = Color(0xFFFFB86B),
    background = Color(0xFF070A12),
    onBackground = Color(0xFFF4F6FF),
    surface = Color(0xFF111623),
    onSurface = Color(0xFFF4F6FF),
    surfaceVariant = Color(0xFF1A2132),
    onSurfaceVariant = Color(0xFFB9C1D9),
    error = Color(0xFFFF6B7A)
)

@Composable
fun VocalStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VocalColors,
        typography = MaterialTheme.typography,
        content = content
    )
}

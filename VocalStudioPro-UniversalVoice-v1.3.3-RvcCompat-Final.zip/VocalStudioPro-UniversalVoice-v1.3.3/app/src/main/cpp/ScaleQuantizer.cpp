#include "ScaleQuantizer.h"
#include <cmath>
#include <limits>

namespace {
constexpr int MAJOR[7] = {0, 2, 4, 5, 7, 9, 11};
constexpr int MINOR[7] = {0, 2, 3, 5, 7, 8, 10};

bool allowed(int midi, int root, int mode) {
    int rel = (midi - root) % 12;
    if (rel < 0) rel += 12;
    const int* s = mode == 1 ? MINOR : MAJOR;
    for (int i = 0; i < 7; ++i) if (rel == s[i]) return true;
    return false;
}
}

float ScaleQuantizer::hzToMidi(float hz) {
    return hz > 0.0f ? 69.0f + 12.0f * std::log2(hz / 440.0f) : 0.0f;
}

float ScaleQuantizer::nearestScaleMidi(float midi, int rootPitchClass, int scaleMode) {
    rootPitchClass = ((rootPitchClass % 12) + 12) % 12;
    const int center = static_cast<int>(std::lround(midi));
    float best = midi;
    float distance = std::numeric_limits<float>::max();
    for (int note = center - 12; note <= center + 12; ++note) {
        if (!allowed(note, rootPitchClass, scaleMode)) continue;
        const float d = std::abs(note - midi);
        if (d < distance) { distance = d; best = static_cast<float>(note); }
    }
    return best;
}

float ScaleQuantizer::correctionSemitones(float hz, int rootPitchClass, int scaleMode) {
    if (hz <= 0.0f) return 0.0f;
    const float midi = hzToMidi(hz);
    return nearestScaleMidi(midi, rootPitchClass, scaleMode) - midi;
}

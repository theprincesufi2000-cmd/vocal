#pragma once
#include <vector>

class Biquad {
public:
    void highPass(float sampleRate, float frequency, float q = 0.7071f);
    void lowPass(float sampleRate, float frequency, float q = 0.7071f);
    void notch(float sampleRate, float frequency, float q = 20.0f);
    void peaking(float sampleRate, float frequency, float q, float gainDb);
    void lowShelf(float sampleRate, float frequency, float gainDb);
    void highShelf(float sampleRate, float frequency, float gainDb);
    float process(float x);
    void reset();
private:
    float b0_ = 1, b1_ = 0, b2_ = 0, a1_ = 0, a2_ = 0;
    float z1_ = 0, z2_ = 0;
    void set(float b0, float b1, float b2, float a0, float a1, float a2);
};

class DspProcessors {
public:
    static void preprocess(std::vector<float>& audio, int sampleRate, float noiseAmount);
    static void master(std::vector<float>& audio, int sampleRate,
                       float deEsserAmount, float compressionAmount, float reverbAmount,
                       float clarityAmount, float warmthAmount, float airAmount,
                       float levelingAmount);
    static void normalize(std::vector<float>& audio, float targetPeak = 0.89125f);
};

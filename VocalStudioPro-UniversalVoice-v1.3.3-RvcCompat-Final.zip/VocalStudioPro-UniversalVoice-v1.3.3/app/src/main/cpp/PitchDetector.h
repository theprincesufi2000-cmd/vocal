#pragma once
#include <vector>

struct PitchResult {
    float frequency = 0.0f;
    float confidence = 0.0f;
};

class PitchDetector {
public:
    PitchResult detectYin(const float* samples, int count, int sampleRate,
                          float minHz = 70.0f, float maxHz = 1000.0f,
                          float threshold = 0.12f) const;
};

#include "PitchDetector.h"
#include <algorithm>
#include <cmath>
#include <vector>

PitchResult PitchDetector::detectYin(const float* x, int n, int sr,
                                     float minHz, float maxHz, float threshold) const {
    PitchResult result{};
    if (!x || n < 512 || sr <= 0) return result;

    double energy = 0.0;
    float peak = 0.0f;
    for (int i = 0; i < n; ++i) {
        energy += static_cast<double>(x[i]) * x[i];
        peak = std::max(peak, std::abs(x[i]));
    }
    const float rms = static_cast<float>(std::sqrt(energy / n));
    if (rms < 0.006f || peak < 0.018f) return result;

    const int tauMin = std::max(2, static_cast<int>(sr / maxHz));
    const int tauMax = std::min(n / 2 - 1, static_cast<int>(sr / minHz));
    if (tauMax <= tauMin) return result;

    std::vector<float> diff(tauMax + 1, 0.0f);
    std::vector<float> cmnd(tauMax + 1, 1.0f);

    for (int tau = 1; tau <= tauMax; ++tau) {
        double sum = 0.0;
        const int limit = n - tau;
        for (int i = 0; i < limit; ++i) {
            const float d = x[i] - x[i + tau];
            sum += static_cast<double>(d) * d;
        }
        diff[tau] = static_cast<float>(sum);
    }

    double running = 0.0;
    for (int tau = 1; tau <= tauMax; ++tau) {
        running += diff[tau];
        cmnd[tau] = running > 1e-15 ? diff[tau] * tau / static_cast<float>(running) : 1.0f;
    }

    int best = -1;
    for (int tau = tauMin; tau <= tauMax; ++tau) {
        if (cmnd[tau] < threshold) {
            while (tau + 1 <= tauMax && cmnd[tau + 1] < cmnd[tau]) ++tau;
            best = tau;
            break;
        }
    }
    if (best < 0) {
        float minimum = 1.0f;
        for (int tau = tauMin; tau <= tauMax; ++tau) {
            if (cmnd[tau] < minimum) { minimum = cmnd[tau]; best = tau; }
        }
        if (best < 0 || minimum > 0.32f) return result;
    }

    float refined = static_cast<float>(best);
    if (best > 1 && best < tauMax) {
        const float a = cmnd[best - 1], b = cmnd[best], c = cmnd[best + 1];
        const float denom = 2.0f * (2.0f * b - a - c);
        if (std::abs(denom) > 1e-8f) refined += (c - a) / denom;
    }
    if (refined <= 0.0f) return result;
    const float f0 = sr / refined;
    if (f0 < minHz || f0 > maxHz) return result;

    result.frequency = f0;
    result.confidence = std::clamp(1.0f - cmnd[best], 0.0f, 1.0f);
    return result;
}

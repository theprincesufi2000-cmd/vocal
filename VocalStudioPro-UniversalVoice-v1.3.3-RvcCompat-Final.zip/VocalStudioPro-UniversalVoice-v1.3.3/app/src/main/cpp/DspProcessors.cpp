#include "DspProcessors.h"
#include "SpectralDenoiser.h"
#include <algorithm>
#include <cmath>
#include <deque>
#include <numeric>
#include <vector>

namespace {
constexpr float PI = 3.14159265358979323846f;
float dbToGain(float db) { return std::pow(10.0f, db / 20.0f); }
float gainToDb(float x) { return 20.0f * std::log10(std::max(x, 1e-9f)); }

struct Comb {
    std::vector<float> buf;
    size_t index = 0;
    float feedback = 0.76f;
    float damp = 0.28f;
    float filter = 0.0f;
    explicit Comb(int delay) : buf(std::max(1, delay), 0.0f) {}
    float process(float x) {
        const float y = buf[index];
        filter = y * (1.0f - damp) + filter * damp;
        buf[index] = x + filter * feedback;
        if (++index >= buf.size()) index = 0;
        return y;
    }
};

struct Allpass {
    std::vector<float> buf;
    size_t index = 0;
    float feedback = 0.5f;
    explicit Allpass(int delay) : buf(std::max(1, delay), 0.0f) {}
    float process(float x) {
        const float b = buf[index];
        const float y = -x + b;
        buf[index] = x + b * feedback;
        if (++index >= buf.size()) index = 0;
        return y;
    }
};

struct BandCompressor {
    float env = 0.0f;
    float gain = 1.0f;
    float thresholdDb = -18.0f;
    float ratio = 3.0f;
    float attack = 0.0f;
    float release = 0.0f;

    BandCompressor(int sr, float threshold, float r, float attackMs, float releaseMs)
        : thresholdDb(threshold), ratio(r) {
        attack = std::exp(-1.0f / (std::max(0.0002f, attackMs / 1000.0f) * sr));
        release = std::exp(-1.0f / (std::max(0.002f, releaseMs / 1000.0f) * sr));
    }

    float process(float x, float amount) {
        const float a = std::abs(x);
        env = a > env ? attack * env + (1.0f - attack) * a
                      : release * env + (1.0f - release) * a;
        const float levelDb = gainToDb(env);
        float target = 1.0f;
        if (levelDb > thresholdDb) {
            const float compressedDb = thresholdDb + (levelDb - thresholdDb) / ratio;
            target = dbToGain((compressedDb - levelDb) * amount);
        }
        const float coef = target < gain ? 0.55f : 0.995f;
        gain = coef * gain + (1.0f - coef) * target;
        return x * gain;
    }
};

// Narrow-band tone estimate used only to choose 50 Hz vs 60 Hz mains family.
double tonePower(const std::vector<float>& audio, int sr, float hz) {
    if (audio.empty()) return 0.0;
    const size_t maxSamples = std::min<size_t>(audio.size(), static_cast<size_t>(sr) * 12);
    const double w = 2.0 * PI * hz / sr;
    double re = 0.0, im = 0.0;
    // Decimate analysis work while keeping deterministic enough discrimination.
    const int step = 2;
    for (size_t i = 0; i < maxSamples; i += step) {
        const double phase = w * static_cast<double>(i);
        re += audio[i] * std::cos(phase);
        im -= audio[i] * std::sin(phase);
    }
    const double n = std::max<size_t>(1, maxSamples / step);
    return (re * re + im * im) / (n * n);
}

void removeMainsHum(std::vector<float>& audio, int sr, float amount) {
    if (amount < 0.10f || audio.size() < static_cast<size_t>(sr / 2)) return;
    const double e50 = tonePower(audio, sr, 50.0f) + 0.7 * tonePower(audio, sr, 100.0f) + 0.5 * tonePower(audio, sr, 150.0f);
    const double e60 = tonePower(audio, sr, 60.0f) + 0.7 * tonePower(audio, sr, 120.0f) + 0.5 * tonePower(audio, sr, 180.0f);
    const float base = e50 >= e60 ? 50.0f : 60.0f;

    // Only engage if a coherent mains family is meaningfully present.
    double rms = 0.0;
    for (float x : audio) rms += static_cast<double>(x) * x;
    rms = std::sqrt(rms / std::max<size_t>(1, audio.size()));
    const double tonal = std::max(e50, e60);
    if (tonal < rms * rms * 0.00005) return;

    const int maxHarmonic = (base < 55.0f) ? 5 : 4;
    for (int h = 1; h <= maxHarmonic; ++h) {
        const float f = base * h;
        if (f < 68.0f || f > 320.0f) continue; // HPF handles the fundamental.
        Biquad notch;
        const float q = 22.0f + 18.0f * amount;
        notch.notch(static_cast<float>(sr), f, q);
        for (float& x : audio) x = notch.process(x);
    }
}

void vocalLeveler(std::vector<float>& audio, int sr, float amount) {
    amount = std::clamp(amount, 0.0f, 1.0f);
    if (amount < 0.02f) return;
    const float attack = std::exp(-1.0f / (0.035f * sr));
    const float release = std::exp(-1.0f / (0.550f * sr));
    const float gainRelease = std::exp(-1.0f / (0.280f * sr));
    const float target = dbToGain(-18.5f + 2.0f * amount);
    float env = 0.0f;
    float gain = 1.0f;
    for (float& x : audio) {
        const float a = std::abs(x);
        env = a > env ? attack * env + (1.0f - attack) * a
                      : release * env + (1.0f - release) * a;
        float desired = 1.0f;
        if (env > dbToGain(-48.0f)) {
            desired = std::clamp(target / std::max(env, 1e-6f), 0.65f, 1.0f + 1.8f * amount);
            desired = 1.0f + (desired - 1.0f) * amount;
        }
        const float coef = desired < gain ? 0.985f : gainRelease;
        gain = coef * gain + (1.0f - coef) * desired;
        x *= gain;
    }
}

void multibandCompress(std::vector<float>& audio, int sr, float amount) {
    amount = std::clamp(amount, 0.0f, 1.0f);
    if (amount < 0.02f) return;
    const float aLow = 1.0f - std::exp(-2.0f * PI * 180.0f / sr);
    const float aHighSplit = 1.0f - std::exp(-2.0f * PI * 4300.0f / sr);
    float lowState = 0.0f;
    float midLowState = 0.0f;

    BandCompressor lowComp(sr, -16.0f - 4.0f * amount, 2.0f + 1.0f * amount, 14.0f, 150.0f);
    BandCompressor midComp(sr, -20.0f - 5.0f * amount, 2.5f + 2.0f * amount, 6.0f, 100.0f);
    BandCompressor highComp(sr, -23.0f - 3.0f * amount, 2.0f + 1.4f * amount, 2.0f, 65.0f);

    for (float& x : audio) {
        lowState += aLow * (x - lowState);
        midLowState += aHighSplit * (x - midLowState);
        const float low = lowState;
        const float high = x - midLowState;
        const float mid = midLowState - low;
        x = lowComp.process(low, amount * 0.72f)
          + midComp.process(mid, amount)
          + highComp.process(high, amount * 0.80f);
    }
}

float catmull(float xm1, float x0, float x1, float x2, float t) {
    const float a = 2.0f * x0;
    const float b = -xm1 + x1;
    const float c = 2.0f * xm1 - 5.0f * x0 + 4.0f * x1 - x2;
    const float d = -xm1 + 3.0f * x0 - 3.0f * x1 + x2;
    return 0.5f * (a + b * t + c * t * t + d * t * t * t);
}

void truePeakLimiter(std::vector<float>& audio, int sr, float ceilingDb = -1.0f) {
    if (audio.empty()) return;
    const float ceiling = dbToGain(ceilingDb);
    std::vector<float> metric(audio.size(), 0.0f);
    for (size_t i = 0; i < audio.size(); ++i) {
        const float xm1 = audio[i > 0 ? i - 1 : i];
        const float x0 = audio[i];
        const float x1 = audio[std::min(i + 1, audio.size() - 1)];
        const float x2 = audio[std::min(i + 2, audio.size() - 1)];
        float p = std::abs(x0);
        p = std::max(p, std::abs(catmull(xm1, x0, x1, x2, 0.25f)));
        p = std::max(p, std::abs(catmull(xm1, x0, x1, x2, 0.50f)));
        p = std::max(p, std::abs(catmull(xm1, x0, x1, x2, 0.75f)));
        metric[i] = p;
    }

    const int lookahead = std::max(1, static_cast<int>(0.0045f * sr));
    std::deque<size_t> dq;
    std::vector<float> futureMax(audio.size(), 0.0f);
    for (int i = static_cast<int>(audio.size()) - 1; i >= 0; --i) {
        while (!dq.empty() && dq.front() > static_cast<size_t>(i + lookahead)) dq.pop_front();
        while (!dq.empty() && metric[dq.back()] <= metric[static_cast<size_t>(i)]) dq.pop_back();
        dq.push_back(static_cast<size_t>(i));
        futureMax[static_cast<size_t>(i)] = metric[dq.front()];
    }

    const float release = std::exp(-1.0f / (0.085f * sr));
    float gain = 1.0f;
    for (size_t i = 0; i < audio.size(); ++i) {
        const float p = futureMax[i];
        const float desired = p > ceiling ? ceiling / std::max(p, 1e-9f) : 1.0f;
        gain = desired < gain ? desired : release * gain + (1.0f - release) * desired;
        audio[i] *= gain;
    }
}

} // namespace

void Biquad::set(float b0, float b1, float b2, float a0, float a1, float a2) {
    b0_ = b0 / a0; b1_ = b1 / a0; b2_ = b2 / a0;
    a1_ = a1 / a0; a2_ = a2 / a0;
}
void Biquad::reset() { z1_ = z2_ = 0.0f; }
float Biquad::process(float x) {
    const float y = b0_ * x + z1_;
    z1_ = b1_ * x - a1_ * y + z2_;
    z2_ = b2_ * x - a2_ * y;
    return y;
}
void Biquad::highPass(float sr, float f, float q) {
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w), a = s / (2.0f * q);
    set((1+c)/2, -(1+c), (1+c)/2, 1+a, -2*c, 1-a);
}
void Biquad::lowPass(float sr, float f, float q) {
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w), a = s / (2.0f * q);
    set((1-c)/2, 1-c, (1-c)/2, 1+a, -2*c, 1-a);
}
void Biquad::notch(float sr, float f, float q) {
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w), a = s / (2.0f * q);
    set(1.0f, -2.0f*c, 1.0f, 1.0f+a, -2.0f*c, 1.0f-a);
}
void Biquad::peaking(float sr, float f, float q, float gainDb) {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w), a = s / (2.0f * q);
    set(1+a*A, -2*c, 1-a*A, 1+a/A, -2*c, 1-a/A);
}
void Biquad::lowShelf(float sr, float f, float gainDb) {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w);
    const float beta = std::sqrt(A + A);
    set(
        A*((A+1)-(A-1)*c+beta*s),
        2*A*((A-1)-(A+1)*c),
        A*((A+1)-(A-1)*c-beta*s),
        (A+1)+(A-1)*c+beta*s,
        -2*((A-1)+(A+1)*c),
        (A+1)+(A-1)*c-beta*s
    );
}
void Biquad::highShelf(float sr, float f, float gainDb) {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w);
    const float beta = std::sqrt(A + A);
    set(
        A*((A+1)+(A-1)*c+beta*s),
        -2*A*((A-1)+(A+1)*c),
        A*((A+1)+(A-1)*c-beta*s),
        (A+1)-(A-1)*c+beta*s,
        2*((A-1)-(A+1)*c),
        (A+1)-(A-1)*c-beta*s
    );
}

void DspProcessors::preprocess(std::vector<float>& audio, int sr, float noiseAmount) {
    noiseAmount = std::clamp(noiseAmount, 0.0f, 1.0f);
    if (audio.empty()) return;

    // DC blocker + steeper vocal high-pass. Two cascaded biquads approximate a 4th-order filter.
    Biquad hp1, hp2;
    hp1.highPass(static_cast<float>(sr), 68.0f, 0.7071f);
    hp2.highPass(static_cast<float>(sr), 68.0f, 0.7071f);
    float dcX = 0.0f, dcY = 0.0f;
    for (float& s : audio) {
        const float dc = s - dcX + 0.995f * dcY;
        dcX = s; dcY = dc;
        s = hp2.process(hp1.process(dc));
    }

    removeMainsHum(audio, sr, noiseAmount);

    // Main studio denoiser: learned spectral profile + Wiener attenuation.
    SpectralDenoiser::process(audio, sr, noiseAmount);

    // Very soft downward expander after spectral cleanup. This closes room noise between phrases
    // without chopping breaths and consonants like a hard gate.
    const float threshold = dbToGain(-52.0f + 13.0f * noiseAmount);
    const float attack = std::exp(-1.0f / (0.004f * sr));
    const float release = std::exp(-1.0f / (0.160f * sr));
    float env = 0.0f, gain = 1.0f;
    for (float& s : audio) {
        const float a = std::abs(s);
        env = a > env ? attack * env + (1-attack) * a : release * env + (1-release) * a;
        float target = 1.0f;
        if (env < threshold) {
            const float t = std::clamp(env / std::max(threshold, 1e-7f), 0.0f, 1.0f);
            const float floor = 0.30f - 0.18f * noiseAmount;
            target = floor + (1.0f - floor) * t * t;
        }
        const float coef = target < gain ? 0.82f : 0.9985f;
        gain = coef * gain + (1.0f - coef) * target;
        s *= gain;
    }
}

void DspProcessors::master(std::vector<float>& audio, int sr,
                           float deEsserAmount, float compressionAmount, float reverbAmount,
                           float clarityAmount, float warmthAmount, float airAmount,
                           float levelingAmount) {
    deEsserAmount = std::clamp(deEsserAmount, 0.0f, 1.0f);
    compressionAmount = std::clamp(compressionAmount, 0.0f, 1.0f);
    reverbAmount = std::clamp(reverbAmount, 0.0f, 0.45f);
    clarityAmount = std::clamp(clarityAmount, 0.0f, 1.0f);
    warmthAmount = std::clamp(warmthAmount, 0.0f, 1.0f);
    airAmount = std::clamp(airAmount, 0.0f, 1.0f);
    levelingAmount = std::clamp(levelingAmount, 0.0f, 1.0f);
    if (audio.empty()) return;

    vocalLeveler(audio, sr, levelingAmount);
    multibandCompress(audio, sr, compressionAmount);

    // Corrective/character EQ: remove boxiness, add intelligibility, body and air independently.
    Biquad mud, box, presence, warmth, air;
    mud.peaking(static_cast<float>(sr), 245.0f, 1.05f, -1.2f - 2.0f * clarityAmount);
    box.peaking(static_cast<float>(sr), 620.0f, 1.15f, -0.4f - 1.2f * clarityAmount);
    presence.peaking(static_cast<float>(sr), 3150.0f, 0.80f, 0.8f + 2.7f * clarityAmount);
    warmth.lowShelf(static_cast<float>(sr), 180.0f, -0.3f + 2.0f * warmthAmount);
    air.highShelf(static_cast<float>(sr), 9200.0f, 0.4f + 3.1f * airAmount);

    // Split-band de-esser: detect sibilance but attenuate mostly the high-frequency component,
    // preserving the vowel/body instead of turning the whole signal down.
    Biquad sibilance, highBand;
    sibilance.highPass(static_cast<float>(sr), 5000.0f, 0.7071f);
    highBand.highPass(static_cast<float>(sr), 4700.0f, 0.7071f);
    const float deThreshold = dbToGain(-31.0f + 9.0f * (1.0f - deEsserAmount));
    const float deAttack = std::exp(-1.0f / (0.0012f * sr));
    const float deRelease = std::exp(-1.0f / (0.060f * sr));
    float deEnv = 0.0f;

    for (float& s : audio) {
        float x = warmth.process(s);
        x = mud.process(x);
        x = box.process(x);
        x = presence.process(x);

        const float sib = std::abs(sibilance.process(x));
        deEnv = sib > deEnv ? deAttack * deEnv + (1-deAttack)*sib
                            : deRelease * deEnv + (1-deRelease)*sib;
        float reduction = 1.0f;
        if (deEnv > deThreshold && deEsserAmount > 0.0f) {
            const float overDb = gainToDb(deEnv / deThreshold);
            const float reductionDb = std::min(9.0f * deEsserAmount, overDb * 0.72f * deEsserAmount);
            reduction = dbToGain(-reductionDb);
        }
        const float hi = highBand.process(x);
        x += hi * (reduction - 1.0f);
        x = air.process(x);

        // Gentle console/tape-style density. Keep drive low enough not to fuzz consonants.
        const float drive = 1.03f + 0.25f * compressionAmount + 0.08f * warmthAmount;
        s = std::tanh(x * drive) / std::tanh(drive);
    }

    // Parallel plate ambience with pre-delay. The dry vocal stays upfront.
    if (reverbAmount > 0.001f) {
        Comb c1(static_cast<int>(0.0297f * sr));
        Comb c2(static_cast<int>(0.0371f * sr));
        Comb c3(static_cast<int>(0.0411f * sr));
        Comb c4(static_cast<int>(0.0437f * sr));
        Allpass a1(static_cast<int>(0.0050f * sr));
        Allpass a2(static_cast<int>(0.0017f * sr));
        const int preDelay = std::max(1, static_cast<int>(0.022f * sr));
        std::vector<float> pre(static_cast<size_t>(preDelay), 0.0f);
        size_t preIndex = 0;
        const float wet = reverbAmount;
        for (float& s : audio) {
            const float dry = s;
            const float pd = pre[preIndex];
            pre[preIndex] = dry;
            preIndex = (preIndex + 1) % pre.size();
            float r = (c1.process(pd) + c2.process(pd) + c3.process(pd) + c4.process(pd)) * 0.25f;
            r = a2.process(a1.process(r));
            s = dry + r * wet * 0.72f;
        }
    }

    // Bring the finished master close to delivery level before the final true-peak stage.
    float preLimitPeak = 0.0f;
    for (float x : audio) preLimitPeak = std::max(preLimitPeak, std::abs(x));
    if (preLimitPeak > 1e-6f) {
        const float target = dbToGain(-1.35f);
        const float g = std::clamp(target / preLimitPeak, 0.55f, 1.35f);
        for (float& x : audio) x *= g;
    }
    truePeakLimiter(audio, sr, -1.0f);
}

void DspProcessors::normalize(std::vector<float>& audio, float targetPeak) {
    float peak = 0.0f;
    for (float v : audio) peak = std::max(peak, std::abs(v));
    if (peak < 1e-6f) return;
    float gain = targetPeak / peak;
    // Do not drag a weak/noisy file up by an extreme amount.
    gain = std::clamp(gain, 0.35f, 1.65f);
    for (float& v : audio) v = std::clamp(v * gain, -0.999f, 0.999f);
}

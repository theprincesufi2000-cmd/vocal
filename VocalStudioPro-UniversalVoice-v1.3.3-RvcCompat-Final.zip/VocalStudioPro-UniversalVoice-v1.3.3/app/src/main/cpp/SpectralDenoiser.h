#pragma once
#include <vector>

class SpectralDenoiser {
public:
    // Offline voice-oriented denoiser. Strength 0..1.
    // Learns a noise profile from the quietest frames, then applies a
    // temporally/frequency-smoothed Wiener-style mask with a vocal-safe floor.
    static void process(std::vector<float>& audio, int sampleRate, float strength);
};

#pragma once
#include <string>

struct VocalParams {
    int rootPitchClass = 0;
    int scaleMode = 0;
    float strength = 0.95f;
    float retuneMs = 20.0f;
    float humanize = 0.25f;

    float noiseReduction = 0.62f;
    float clarity = 0.66f;
    float warmth = 0.34f;
    float air = 0.52f;
    float deEsser = 0.52f;
    float compression = 0.68f;
    float leveling = 0.72f;
    float reverb = 0.14f;
};

class VocalEngine {
public:
    static int processFile(const std::string& inputPath, const std::string& outputPath,
                           const VocalParams& params, std::string& error);
    static int prepareForVoiceModel(const std::string& inputPath, const std::string& outputPath,
                                    const VocalParams& params, std::string& error);
    static int masterOnly(const std::string& inputPath, const std::string& outputPath,
                          const VocalParams& params, std::string& error);
    static const char* version();
};

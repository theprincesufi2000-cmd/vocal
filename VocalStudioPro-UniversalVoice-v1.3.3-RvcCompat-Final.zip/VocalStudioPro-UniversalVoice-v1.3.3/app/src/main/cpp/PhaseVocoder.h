#pragma once
#include <complex>
#include <vector>

class PhaseVocoder {
public:
    explicit PhaseVocoder(int sampleRate, int frameSize = 2048, int oversampling = 8);
    void reset();
    void process(const float* input, int count, float pitchFactor, std::vector<float>& output);
    int hopSize() const { return stepSize_; }
    int latency() const { return latency_; }
    int frameSize() const { return frameSize_; }

private:
    int sampleRate_;
    int frameSize_;
    int oversampling_;
    int stepSize_;
    int latency_;
    int rover_;
    float freqPerBin_;
    float expectedPhase_;

    std::vector<float> inFifo_, outFifo_, lastPhase_, sumPhase_, outputAccum_;
    std::vector<float> anaMagn_, anaFreq_, synMagn_, synFreq_;
    std::vector<std::complex<float>> spectrum_;

    void processFrame(float pitchFactor);
    static void fft(std::vector<std::complex<float>>& a, bool inverse);
};

#include "PhaseVocoder.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace {
constexpr float TWO_PI = 6.28318530717958647692f;
}

PhaseVocoder::PhaseVocoder(int sampleRate, int frameSize, int oversampling)
    : sampleRate_(sampleRate), frameSize_(frameSize), oversampling_(oversampling) {
    stepSize_ = frameSize_ / oversampling_;
    latency_ = frameSize_ - stepSize_;
    freqPerBin_ = static_cast<float>(sampleRate_) / frameSize_;
    expectedPhase_ = TWO_PI * stepSize_ / frameSize_;

    inFifo_.resize(frameSize_);
    outFifo_.resize(frameSize_);
    lastPhase_.resize(frameSize_ / 2 + 1);
    sumPhase_.resize(frameSize_ / 2 + 1);
    outputAccum_.resize(frameSize_ * 2);
    anaMagn_.resize(frameSize_ / 2 + 1);
    anaFreq_.resize(frameSize_ / 2 + 1);
    synMagn_.resize(frameSize_ / 2 + 1);
    synFreq_.resize(frameSize_ / 2 + 1);
    spectrum_.resize(frameSize_);
    reset();
}

void PhaseVocoder::reset() {
    std::fill(inFifo_.begin(), inFifo_.end(), 0.0f);
    std::fill(outFifo_.begin(), outFifo_.end(), 0.0f);
    std::fill(lastPhase_.begin(), lastPhase_.end(), 0.0f);
    std::fill(sumPhase_.begin(), sumPhase_.end(), 0.0f);
    std::fill(outputAccum_.begin(), outputAccum_.end(), 0.0f);
    rover_ = latency_;
}

void PhaseVocoder::process(const float* input, int count, float pitchFactor, std::vector<float>& output) {
    output.resize(std::max(0, count));
    if (!input || count <= 0) return;
    pitchFactor = std::clamp(pitchFactor, 0.60f, 1.67f);

    for (int i = 0; i < count; ++i) {
        inFifo_[rover_] = input[i];
        output[i] = outFifo_[rover_ - latency_];
        ++rover_;
        if (rover_ >= frameSize_) processFrame(pitchFactor);
    }
}

void PhaseVocoder::processFrame(float pitchFactor) {
    rover_ = latency_;
    const int half = frameSize_ / 2;

    for (int k = 0; k < frameSize_; ++k) {
        const float window = 0.5f - 0.5f * std::cos(TWO_PI * k / frameSize_);
        spectrum_[k] = std::complex<float>(inFifo_[k] * window, 0.0f);
    }
    fft(spectrum_, false);

    for (int k = 0; k <= half; ++k) {
        const float real = spectrum_[k].real();
        const float imag = spectrum_[k].imag();
        const float magn = 2.0f * std::sqrt(real * real + imag * imag);
        const float phase = std::atan2(imag, real);

        float delta = phase - lastPhase_[k];
        lastPhase_[k] = phase;
        delta -= k * expectedPhase_;
        delta = std::remainder(delta, TWO_PI);
        const float binDeviation = oversampling_ * delta / TWO_PI;

        anaMagn_[k] = magn;
        anaFreq_[k] = (k + binDeviation) * freqPerBin_;
    }

    std::fill(synMagn_.begin(), synMagn_.end(), 0.0f);
    std::fill(synFreq_.begin(), synFreq_.end(), 0.0f);

    for (int k = 0; k <= half; ++k) {
        const float target = k * pitchFactor;
        const int index = static_cast<int>(std::lround(target));
        if (index <= half) {
            if (anaMagn_[k] > synMagn_[index]) {
                synFreq_[index] = anaFreq_[k] * pitchFactor;
            }
            synMagn_[index] += anaMagn_[k];
        }
    }

    std::fill(spectrum_.begin(), spectrum_.end(), std::complex<float>(0.0f, 0.0f));
    for (int k = 0; k <= half; ++k) {
        const float magn = synMagn_[k];
        float trueFreq = synFreq_[k];
        if (magn <= 1e-12f) trueFreq = k * freqPerBin_;

        float delta = trueFreq - k * freqPerBin_;
        delta /= freqPerBin_;
        delta = TWO_PI * delta / oversampling_;
        delta += k * expectedPhase_;
        sumPhase_[k] += delta;

        const float phase = sumPhase_[k];
        const std::complex<float> bin(
            0.5f * magn * std::cos(phase),
            0.5f * magn * std::sin(phase)
        );
        spectrum_[k] = bin;
        if (k > 0 && k < half) spectrum_[frameSize_ - k] = std::conj(bin);
    }

    fft(spectrum_, true);

    for (int k = 0; k < frameSize_; ++k) {
        const float window = 0.5f - 0.5f * std::cos(TWO_PI * k / frameSize_);
        outputAccum_[k] += (4.0f / oversampling_) * window * spectrum_[k].real();
    }

    for (int k = 0; k < stepSize_; ++k) outFifo_[k] = outputAccum_[k];
    std::move(outputAccum_.begin() + stepSize_, outputAccum_.begin() + frameSize_, outputAccum_.begin());
    std::fill(outputAccum_.begin() + (frameSize_ - stepSize_), outputAccum_.end(), 0.0f);
    std::move(inFifo_.begin() + stepSize_, inFifo_.end(), inFifo_.begin());
}

void PhaseVocoder::fft(std::vector<std::complex<float>>& a, bool inverse) {
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }

    for (size_t len = 2; len <= n; len <<= 1) {
        const float ang = TWO_PI / static_cast<float>(len) * (inverse ? 1.0f : -1.0f);
        const std::complex<float> wlen(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) {
            std::complex<float> w(1.0f, 0.0f);
            for (size_t j = 0; j < len / 2; ++j) {
                const auto u = a[i + j];
                const auto v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
    if (inverse) {
        for (auto& v : a) v /= static_cast<float>(n);
    }
}

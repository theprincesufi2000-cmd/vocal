#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct AudioBuffer {
    int sampleRate = 48000;
    std::vector<float> mono;
};

class WavIO {
public:
    static bool readMonoFloat(const std::string& path, AudioBuffer& out, std::string& error);
    static bool writeMono24(const std::string& path, const std::vector<float>& samples, int sampleRate, std::string& error);
    static std::vector<float> resampleSinc(const std::vector<float>& input, int srcRate, int dstRate);
};

#include "WavIO.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <fstream>
#include <limits>

namespace {
constexpr double PI = 3.14159265358979323846;

uint16_t u16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0] | (p[1] << 8));
}
uint32_t u32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) |
           (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) |
           (static_cast<uint32_t>(p[3]) << 24);
}
void put16(std::ofstream& f, uint16_t v) {
    char b[2] = {static_cast<char>(v & 0xff), static_cast<char>((v >> 8) & 0xff)};
    f.write(b, 2);
}
void put32(std::ofstream& f, uint32_t v) {
    char b[4] = {
        static_cast<char>(v & 0xff), static_cast<char>((v >> 8) & 0xff),
        static_cast<char>((v >> 16) & 0xff), static_cast<char>((v >> 24) & 0xff)
    };
    f.write(b, 4);
}
float sinc(double x) {
    if (std::abs(x) < 1e-10) return 1.0f;
    const double px = PI * x;
    return static_cast<float>(std::sin(px) / px);
}
}

bool WavIO::readMonoFloat(const std::string& path, AudioBuffer& out, std::string& error) {
    std::ifstream f(path, std::ios::binary);
    if (!f) { error = "Cannot open input WAV"; return false; }

    std::array<uint8_t, 12> head{};
    if (!f.read(reinterpret_cast<char*>(head.data()), head.size())) {
        error = "WAV header is truncated"; return false;
    }
    if (std::memcmp(head.data(), "RIFF", 4) != 0 || std::memcmp(head.data() + 8, "WAVE", 4) != 0) {
        error = "Input is not RIFF/WAVE"; return false;
    }

    uint16_t format = 0, channels = 0, bits = 0;
    uint32_t sampleRate = 0;
    std::vector<uint8_t> data;
    bool gotFmt = false, gotData = false;

    while (f && !(gotFmt && gotData)) {
        std::array<uint8_t, 8> ch{};
        if (!f.read(reinterpret_cast<char*>(ch.data()), ch.size())) break;
        uint32_t size = u32(ch.data() + 4);
        std::vector<uint8_t> payload(size);
        if (size && !f.read(reinterpret_cast<char*>(payload.data()), size)) break;
        if (size & 1u) f.get();

        if (std::memcmp(ch.data(), "fmt ", 4) == 0 && size >= 16) {
            format = u16(payload.data());
            channels = u16(payload.data() + 2);
            sampleRate = u32(payload.data() + 4);
            bits = u16(payload.data() + 14);
            if (format == 0xfffe && size >= 40) {
                // WAVE_FORMAT_EXTENSIBLE: Data1 of SubFormat starts at byte 24.
                format = static_cast<uint16_t>(u32(payload.data() + 24) & 0xffffu);
            }
            gotFmt = true;
        } else if (std::memcmp(ch.data(), "data", 4) == 0) {
            data = std::move(payload);
            gotData = true;
        }
    }

    if (!gotFmt || !gotData || channels == 0 || sampleRate == 0 || bits == 0) {
        error = "Incomplete WAV format/data chunks"; return false;
    }
    if (format != 1 && format != 3) {
        error = "Unsupported WAV encoding"; return false;
    }

    const int bytesPerSample = bits / 8;
    if (bytesPerSample <= 0) { error = "Invalid WAV bit depth"; return false; }
    const size_t frameBytes = static_cast<size_t>(bytesPerSample) * channels;
    if (frameBytes == 0) { error = "Invalid WAV channels"; return false; }
    const size_t frames = data.size() / frameBytes;
    std::vector<float> mono(frames, 0.0f);

    auto decode = [&](const uint8_t* p) -> float {
        if (format == 3 && bits == 32) {
            float v;
            std::memcpy(&v, p, sizeof(float));
            return std::clamp(v, -1.0f, 1.0f);
        }
        switch (bits) {
            case 8: return (static_cast<int>(*p) - 128) / 128.0f;
            case 16: {
                int16_t v = static_cast<int16_t>(u16(p));
                return v / 32768.0f;
            }
            case 24: {
                int32_t v = static_cast<int32_t>(p[0]) |
                            (static_cast<int32_t>(p[1]) << 8) |
                            (static_cast<int32_t>(p[2]) << 16);
                if (v & 0x00800000) v |= static_cast<int32_t>(0xff000000);
                return v / 8388608.0f;
            }
            case 32: {
                int32_t v = static_cast<int32_t>(u32(p));
                return static_cast<float>(v / 2147483648.0);
            }
            default: return 0.0f;
        }
    };

    const uint8_t* ptr = data.data();
    for (size_t i = 0; i < frames; ++i) {
        double sum = 0.0;
        for (uint16_t c = 0; c < channels; ++c) {
            sum += decode(ptr + (i * channels + c) * bytesPerSample);
        }
        mono[i] = static_cast<float>(sum / channels);
    }

    out.sampleRate = static_cast<int>(sampleRate);
    out.mono = std::move(mono);
    return true;
}

std::vector<float> WavIO::resampleSinc(const std::vector<float>& input, int srcRate, int dstRate) {
    if (input.empty() || srcRate <= 0 || dstRate <= 0 || srcRate == dstRate) return input;
    const double ratio = static_cast<double>(srcRate) / dstRate;
    const size_t outCount = static_cast<size_t>(std::llround(input.size() / ratio));
    std::vector<float> out(outCount, 0.0f);
    constexpr int radius = 12;

    for (size_t i = 0; i < outCount; ++i) {
        const double pos = i * ratio;
        const int center = static_cast<int>(std::floor(pos));
        double sum = 0.0, norm = 0.0;
        for (int k = -radius + 1; k <= radius; ++k) {
            const int idx = center + k;
            if (idx < 0 || idx >= static_cast<int>(input.size())) continue;
            const double x = pos - idx;
            const double ax = std::abs(x) / radius;
            if (ax >= 1.0) continue;
            const double window = 0.5 * (1.0 + std::cos(PI * ax));
            const double w = sinc(x) * window;
            sum += input[idx] * w;
            norm += w;
        }
        out[i] = norm != 0.0 ? static_cast<float>(sum / norm) : 0.0f;
    }
    return out;
}

bool WavIO::writeMono24(const std::string& path, const std::vector<float>& samples, int sampleRate, std::string& error) {
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    if (!f) { error = "Cannot create output WAV"; return false; }
    const uint32_t dataSize = static_cast<uint32_t>(std::min<uint64_t>(
        static_cast<uint64_t>(samples.size()) * 3ull, 0xffffffffull - 36ull));

    f.write("RIFF", 4); put32(f, 36u + dataSize); f.write("WAVE", 4);
    f.write("fmt ", 4); put32(f, 16); put16(f, 1); put16(f, 1);
    put32(f, static_cast<uint32_t>(sampleRate));
    put32(f, static_cast<uint32_t>(sampleRate * 3));
    put16(f, 3); put16(f, 24);
    f.write("data", 4); put32(f, dataSize);

    const size_t count = dataSize / 3;
    for (size_t i = 0; i < count; ++i) {
        float x = std::clamp(samples[i], -1.0f, 0.99999988f);
        int32_t v = static_cast<int32_t>(std::lrint(x * 8388607.0f));
        char b[3] = {
            static_cast<char>(v & 0xff),
            static_cast<char>((v >> 8) & 0xff),
            static_cast<char>((v >> 16) & 0xff)
        };
        f.write(b, 3);
    }
    if (!f) { error = "Failed writing WAV data"; return false; }
    return true;
}

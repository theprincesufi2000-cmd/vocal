#pragma once

class ScaleQuantizer {
public:
    static float hzToMidi(float hz);
    static float nearestScaleMidi(float midi, int rootPitchClass, int scaleMode);
    static float correctionSemitones(float hz, int rootPitchClass, int scaleMode);
};

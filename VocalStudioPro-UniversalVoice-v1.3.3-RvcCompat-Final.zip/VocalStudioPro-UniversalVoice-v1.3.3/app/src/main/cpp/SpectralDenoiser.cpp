#include "SpectralDenoiser.h"
#include <algorithm>
#include <cmath>
#include <complex>
#include <deque>
#include <numeric>
#include <vector>

namespace {
constexpr float TWO_PI = 6.28318530717958647692f;

void fft(std::vector<std::complex<float>>& a, bool inverse) {
    const size_t n = a.size();
    for (size_t i = 1, j = 0; i < n; ++i) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (size_t len = 2; len <= n; len <<= 1) {
        const float ang = TWO_PI / static_cast<float>(len) * (inverse ? 1.0f : -1.0f);
        const std::complex<float> wlen(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < n; i += len) {
            std::complex<float> w(1.0f, 0.0f);
            for (size_t j = 0; j < len / 2; ++j) {
                const auto u = a[i + j];
                const auto v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
    if (inverse) {
        for (auto& v : a) v /= static_cast<float>(n);
    }
}

float percentile(std::vector<float> values, float q) {
    if (values.empty()) return 0.0f;
    q = std::clamp(q, 0.0f, 1.0f);
    const size_t index = static_cast<size_t>(q * static_cast<float>(values.size() - 1));
    std::nth_element(values.begin(), values.begin() + static_cast<long>(index), values.end());
    return values[index];
}

} // namespace

void SpectralDenoiser::process(std::vector<float>& audio, int sr, float strength) {
    strength = std::clamp(strength, 0.0f, 1.0f);
    if (strength < 0.02f || audio.size() < 4096 || sr < 8000) return;

    constexpr int N = 2048;
    constexpr int HOP = 512;
    constexpr int HALF = N / 2;
    const int frames = 1 + static_cast<int>((audio.size() + HOP - 1) / HOP);

    std::vector<float> window(N);
    for (int i = 0; i < N; ++i) {
        // sqrt-Hann: good overlap-add behavior for analysis/synthesis.
        window[i] = std::sqrt(std::max(0.0f, 0.5f - 0.5f * std::cos(TWO_PI * i / N)));
    }

    // First pass: frame energies. Quiet frames are the noise-profile candidates.
    std::vector<float> frameRms(frames, 0.0f);
    for (int f = 0; f < frames; ++f) {
        const int start = f * HOP - N / 2;
        double sum = 0.0;
        for (int i = 0; i < N; ++i) {
            const int idx = start + i;
            const float x = (idx >= 0 && idx < static_cast<int>(audio.size())) ? audio[idx] : 0.0f;
            sum += static_cast<double>(x) * x;
        }
        frameRms[f] = std::sqrt(static_cast<float>(sum / N));
    }

    // The quietest 18-30% becomes the noise model. A lower percentile at high
    // strength avoids teaching the model sustained vocal notes.
    const float profileQuantile = 0.30f - 0.12f * strength;
    const float quietThreshold = percentile(frameRms, profileQuantile) * 1.08f + 1e-7f;

    std::vector<double> noisePower(HALF + 1, 0.0);
    int profileFrames = 0;
    std::vector<std::complex<float>> spec(N);
    for (int f = 0; f < frames; ++f) {
        if (frameRms[f] > quietThreshold) continue;
        const int start = f * HOP - N / 2;
        for (int i = 0; i < N; ++i) {
            const int idx = start + i;
            const float x = (idx >= 0 && idx < static_cast<int>(audio.size())) ? audio[idx] : 0.0f;
            spec[i] = {x * window[i], 0.0f};
        }
        fft(spec, false);
        for (int k = 0; k <= HALF; ++k) noisePower[k] += std::norm(spec[k]);
        ++profileFrames;
    }

    // If the performance has no obvious silence, use a conservative global floor.
    if (profileFrames < 3) {
        std::fill(noisePower.begin(), noisePower.end(), 1e-10);
        for (int f = 0; f < std::min(frames, 10); ++f) {
            const int start = f * HOP - N / 2;
            for (int i = 0; i < N; ++i) {
                const int idx = start + i;
                const float x = (idx >= 0 && idx < static_cast<int>(audio.size())) ? audio[idx] : 0.0f;
                spec[i] = {x * window[i], 0.0f};
            }
            fft(spec, false);
            for (int k = 0; k <= HALF; ++k) noisePower[k] += std::norm(spec[k]) * 0.12;
            ++profileFrames;
        }
    }

    const double invProfiles = 1.0 / std::max(1, profileFrames);
    for (double& v : noisePower) v = std::max(v * invProfiles, 1e-12);

    std::vector<float> output(audio.size() + N, 0.0f);
    std::vector<float> weight(audio.size() + N, 0.0f);
    std::vector<float> previousGain(HALF + 1, 1.0f);
    std::vector<float> rawGain(HALF + 1, 1.0f);
    std::vector<float> smoothGain(HALF + 1, 1.0f);

    const float overSubtract = 1.10f + 1.75f * strength;
    const float temporalRelease = 0.78f + 0.16f * strength;

    for (int f = 0; f < frames; ++f) {
        const int start = f * HOP - N / 2;
        for (int i = 0; i < N; ++i) {
            const int idx = start + i;
            const float x = (idx >= 0 && idx < static_cast<int>(audio.size())) ? audio[idx] : 0.0f;
            spec[i] = {x * window[i], 0.0f};
        }
        fft(spec, false);

        // Wiener-like gain. Keep more energy in the vocal fundamentals/presence
        // region and permit stronger attenuation above ~10 kHz where hiss lives.
        for (int k = 0; k <= HALF; ++k) {
            const float hz = static_cast<float>(k) * sr / N;
            const float power = std::norm(spec[k]) + 1e-12f;
            const float noise = static_cast<float>(noisePower[k]);
            const float snr = std::max(0.0f, (power - noise) / noise);
            float wiener = snr / (snr + overSubtract);
            wiener = std::sqrt(std::clamp(wiener, 0.0f, 1.0f));

            float floor = 0.08f + 0.20f * (1.0f - strength);
            if (hz >= 90.0f && hz <= 5200.0f) floor += 0.07f; // preserve vocal body/formants
            if (hz > 10500.0f) floor -= 0.025f * strength;
            floor = std::clamp(floor, 0.045f, 0.36f);

            float g = floor + (1.0f - floor) * wiener;

            // Strong, narrow tonal components are likely harmonics: protect them.
            const float binSnrDb = 10.0f * std::log10(std::max(power / noise, 1e-6f));
            if (binSnrDb > 12.0f && hz < 9000.0f) {
                const float protect = std::clamp((binSnrDb - 12.0f) / 18.0f, 0.0f, 1.0f);
                g = g + (1.0f - g) * protect * 0.55f;
            }
            rawGain[k] = std::clamp(g, floor, 1.0f);
        }

        // Frequency smoothing prevents musical-noise holes between neighboring bins.
        for (int k = 0; k <= HALF; ++k) {
            float sum = 0.0f;
            float weights = 0.0f;
            for (int d = -2; d <= 2; ++d) {
                const int j = std::clamp(k + d, 0, HALF);
                const float w = (d == 0) ? 3.0f : (std::abs(d) == 1 ? 2.0f : 1.0f);
                sum += rawGain[j] * w;
                weights += w;
            }
            smoothGain[k] = sum / weights;
        }

        // Temporal smoothing: attenuation engages quickly and releases slowly.
        for (int k = 0; k <= HALF; ++k) {
            const float desired = smoothGain[k];
            const float coef = desired < previousGain[k] ? 0.38f : temporalRelease;
            const float g = coef * previousGain[k] + (1.0f - coef) * desired;
            previousGain[k] = g;
            spec[k] *= g;
            if (k > 0 && k < HALF) spec[N - k] *= g;
        }

        fft(spec, true);
        for (int i = 0; i < N; ++i) {
            const int idx = start + i;
            if (idx < 0 || idx >= static_cast<int>(output.size())) continue;
            const float w = window[i];
            output[idx] += spec[i].real() * w;
            weight[idx] += w * w;
        }
    }

    for (size_t i = 0; i < audio.size(); ++i) {
        const float clean = output[i] / std::max(weight[i], 1e-6f);
        // Partial dry blend at light settings is safer for breath and consonants.
        const float mix = 0.72f + 0.28f * strength;
        audio[i] = audio[i] * (1.0f - mix) + clean * mix;
    }
}

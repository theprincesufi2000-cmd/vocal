# VSPVOICE v2 format

VSPVOICE is a ZIP container used by Vocal Studio Pro. v1.3.3 can also auto-import ordinary ZIP/ONNX/RVC checkpoint bundles, so creating VSPVOICE manually is optional.

## Ready ONNX pack

Typical contents:

```text
metadata.json
content_encoder.onnx
voice.onnx
pitch.onnx       # optional direct-Hz F0 model
model.index      # optional, preserved with the pack
model.pth        # optional original checkpoint, preserved for reference
cover.png        # optional
license.txt      # optional
```

`pitch.onnx` is optional. If it is absent, the native C++ F0 tracker is used.

## Important RMVPE note

A stock RMVPE ONNX export can output a 360-bin salience tensor, not direct frequency in Hz. The universal importer recognizes this shape and does not feed it into the direct-F0 path. Native F0 is selected instead unless the pitch graph outputs direct Hz values.

## metadata.json example

```json
{
  "format": "VSPVOICE",
  "formatVersion": 3,
  "id": "my-authorized-voice",
  "name": "My Voice",
  "author": "Owner",
  "license": "Private authorized use",
  "authorized": true,
  "sourceFormat": "RVC_ONNX",
  "state": "READY",
  "engine": "rvc-onnx-v2",
  "sampleRate": 40000,
  "contentSampleRate": 16000,
  "featureChannels": 768,
  "contentModel": "content_encoder.onnx",
  "pitchModel": "",
  "voiceModel": "voice.onnx",
  "contentInput": "input_values",
  "contentOutput": "hidden_states",
  "contentInputRank": 2,
  "contentOutputLayout": "BTC",
  "featureUpsample": 2,
  "voicePhoneInput": "phone",
  "voicePhoneLengthsInput": "phone_lengths",
  "voicePitchInput": "pitch",
  "voicePitchFInput": "pitchf",
  "voiceSpeakerInput": "ds",
  "voiceNoiseInput": "rnd",
  "voiceOutput": "audio",
  "speakerId": 0
}
```

## Automatic importer states

- `READY`: executable ONNX voice + content pipeline is installed.
- `MISSING_CORE`: voice ONNX exists but a content encoder is still needed.
- `CONVERSION_REQUIRED`: raw PyTorch/RVC `.pth` was imported but is not an executable ONNX graph.
- `INCOMPLETE`: recognized files are incomplete.

## RVC ONNX synthesizer contract

The engine targets the common RVC ONNX synthesizer signature exported with inputs equivalent to:

```text
phone
phone_lengths
pitch
pitchf
ds
rnd
```

The importer reads actual input/output names from ONNX Runtime and maps common aliases automatically.

# DSP Architecture — Vocal Studio Pro 1.1

## Internal format

All DSP uses mono 32-bit float at 48 kHz. Input is decoded/resampled before processing; final export is PCM 24-bit/48 kHz WAV.

## Stage 1: Studio Clean

1. DC blocking.
2. Cascaded vocal high-pass filtering around 68 Hz.
3. Offline mains-family analysis chooses 50 Hz or 60 Hz family.
4. Narrow notches attenuate detected mains harmonics above the high-pass region.
5. STFT denoiser uses N=2048, hop=512 and sqrt-Hann windows.
6. Quiet-frame percentile analysis estimates a per-bin stationary noise power profile.
7. A Wiener-style mask estimates gain per FFT bin.
8. Harmonic/vocal range protection prevents aggressive suppression of strong tonal components.
9. Frequency and temporal smoothing reduce musical-noise artifacts.
10. A soft downward expander cleans phrase gaps without hard-gating breaths.

## Stage 2: Pitch correction

- 4096-sample YIN analysis window.
- Confidence thresholding and octave-error rejection.
- Musical scale quantization.
- Strength, retune time and humanize controls.
- Dynamic phase-vocoder pitch ratio per processing block.

## Stage 3: Vocal mastering

- Slow vocal leveler.
- Complementary three-band dynamics (low / vocal body-mid / high).
- Corrective mud/box cuts.
- Independent warmth, presence/clarity and air controls.
- Split-band de-essing driven by a high-frequency sidechain.
- Low-drive tanh saturation for density.
- Parallel Schroeder-style plate ambience with pre-delay.
- Lookahead true-peak limiter using 4x cubic inter-sample peak estimation.
- Final conservative peak normalization.

## Design intent

The engine is intentionally vocal-specific. It favors preserving pitch harmonics and formant-bearing bands over maximum numeric noise attenuation. Stronger denoise settings may remove more background noise but can make poor recordings less natural; the Studio preset is the recommended balance.

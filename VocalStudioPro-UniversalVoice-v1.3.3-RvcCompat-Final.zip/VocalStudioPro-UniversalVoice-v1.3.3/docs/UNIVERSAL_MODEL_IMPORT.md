# Universal model import — v1.3.3

## User flow

1. Open **Universal Voice Models**.
2. Enable **I confirm that I have the right to use this voice model**.
3. Tap **Import any model**.
4. Select `.zip`, `.vspvoice`, `.onnx`, `.ort`, `.pth`, or a bundle containing those files.
5. The app scans and classifies the package.

No manual ZIP folder layout is required for auto-import.

## Detection states

### READY
The model has an RVC-compatible ONNX synthesizer plus a content encoder. It can be enabled immediately.

### MISSING_CORE
A valid voice ONNX was found but no Content Encoder was available. Import a Content Encoder ONNX/ZIP once; waiting models are upgraded automatically.

### CONVERSION_REQUIRED
A PyTorch RVC checkpoint (`.pth`) was found. It is preserved locally, together with `.index` when present, but cannot be executed by ONNX Runtime until exported to an executable graph. The `.index` is retained for compatibility; FAISS retrieval is not executed by the current Android runtime.

### INCOMPLETE
Files were recognized but do not form a runnable model.

## Why `.pth` is not executed directly

The `.pth` extension does not define one runtime graph format. In common RVC downloads it normally contains Python/PyTorch checkpoint data plus architecture configuration. Loading weights alone is not enough to execute a network on Android; the exact architecture must be reconstructed and exported or run by a compatible PyTorch runtime.

The app deliberately reports this accurately rather than treating arbitrary checkpoints as interchangeable models.

## ZIP security

The importer:

- rejects path traversal
- limits entry count
- limits per-entry and total expanded size
- stores imports under private app storage
- uses staging directories and replacement backup during installation
- supports ZIP64-sized voice bundles within configured limits

## F0 fallback

`pitch.onnx` is optional. If a compatible direct-Hz pitch model is absent, the native C++ YIN-based tracker supplies an F0 track automatically. Raw 360-bin RMVPE salience output is not interpreted as Hz.


## Standalone ONNX names

A single ONNX voice file does not need to contain `rvc` or `voice` in its filename. Files such as `Nova_HD.onnx` are accepted as a voice candidate when they are not clearly a ContentVec/HuBERT/RMVPE core file. If the shared 768-channel core is missing, the model is installed in `MISSING_CORE` state and can be completed with the one-tap RVC v2 Core download.

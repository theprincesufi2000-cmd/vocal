# Changelog

## 1.3.3 · Universal RVC Signature Compatibility

- Fixed Nova/Applio RVC input signature `feats, p_len, pitch, pitchf, sid`.
- Added `p_len`, `p_length`, `seq_len`, `feature_lengths`, and related length aliases.
- Made `rnd/noise/z` optional; five-input RVC models no longer fail because they do not expose a noise tensor.
- Added official six-input RVC compatibility: `phone, phone_lengths, pitch, pitchf, ds, rnd`.
- Added non-F0 three-input compatibility: `feats, p_len, sid`.
- RVC input roles are resolved from the live ONNX graph rather than persisted metadata.
- Added runtime type/rank-aware tensor creation for INT64/INT32 length, pitch, and speaker inputs.
- Preserved dynamic ContentVec/HuBERT I/O support from v1.3.2.
- Existing imported models do not need to be re-imported after updating the app.
- versionCode 8 / versionName 1.3.3.

## 1.3.1 · Universal ONNX Import Fix

- Fixed standalone RVC ONNX files with arbitrary names such as `Nova_HD.onnx` being rejected when model probing cannot classify them during import.
- Added safe fallback classification for a single non-core ONNX file as a voice candidate.
- Added one-tap download of a shared quantized RVC v2 ContentVec 768 core (~95 MB) from Hugging Face.
- Shared core is stored once under `voice_models/_core` and referenced by installed models instead of being duplicated per voice.
- Added download progress and automatic refresh of models waiting for RVC Core.
- Added INTERNET permission only for optional core download; audio processing remains local/offline after the core is installed.

## 1.3.0 — Universal Voice Model Import

- Added one-picker universal importer for ZIP / VSPVOICE / ONNX / RVC PTH / INDEX.
- Added recursive ZIP discovery and automatic handling of an extra top-level folder.
- Added ONNX signature probing for RVC synthesizer/content/pitch roles.
- Added shared Content Encoder core installation and automatic completion of waiting models.
- Added honest RVC `.pth + .index` cataloguing with `CONVERSION_REQUIRED` state.
- Added optional pitch ONNX with native C++ F0 fallback.
- Added raw RMVPE salience detection so 360-bin outputs are not treated as Hz.
- Added model readiness/status UI and rights-confirmation gate.
- Increased secure importer limits for large voice-model ZIPs and reduced temporary duplication by moving staged files where possible.
- Kept StudioClean, Auto-Tune, 24-bit WAV, NNAPI/XNNPACK/CPU fallback, and long-file overlap processing.
- versionCode 5 / versionName 1.3.0.

## 1.2.0

- Added local ONNX voice-conversion packs and VSPVOICE format.

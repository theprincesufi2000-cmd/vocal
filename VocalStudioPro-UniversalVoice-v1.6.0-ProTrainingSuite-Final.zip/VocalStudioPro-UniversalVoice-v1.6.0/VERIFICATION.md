# Vocal Studio Pro 1.6.0 — Verification

- versionName: 1.6.0
- versionCode: 12
- C++/JNI strict compile: tested with `-Wall -Wextra -Werror`.
- VSPTRAIN3 multi-clip train/inspect/validate/apply: tested end-to-end on the host toolchain.
- Training source smoke test: two independent 4 s / 48 kHz / PCM24 clips.
- Output: 48 kHz / PCM24 with source frame count preserved.
- Profile size in synthetic test: ~19 KB.
- 50-minute hard limit: verified via header/duration validation; 50:01 is rejected before processing.
- Existing RVC/Applio adaptive-frame engine retained.

A full Android `assembleRelease` is delegated to the included GitHub Actions workflow when the local environment does not contain the Android SDK/Maven dependency set.

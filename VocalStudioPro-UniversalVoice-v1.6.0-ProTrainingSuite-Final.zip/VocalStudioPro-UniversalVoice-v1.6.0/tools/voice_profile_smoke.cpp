#include "VoiceProfileEngine.h"
#include "WavIO.h"
#include <cmath>
#include <iostream>
#include <string>
#include <vector>

namespace {
std::vector<float> makeVoiceLike(float f0, float seconds) {
    constexpr int sr = 48000;
    constexpr float pi = 3.14159265358979323846f;
    const size_t count = static_cast<size_t>(seconds * sr);
    std::vector<float> samples(count);
    for (size_t i = 0; i < count; ++i) {
        const float t = static_cast<float>(i) / sr;
        const float phrase = 0.52f + 0.48f * std::sin(2.0f * pi * 1.7f * t);
        const float attack = std::min(1.0f, t * 8.0f) * std::min(1.0f, (seconds - t) * 8.0f);
        samples[i] = attack * phrase * (
            0.28f * std::sin(2.0f * pi * f0 * t) +
            0.14f * std::sin(2.0f * pi * f0 * 2.0f * t) +
            0.07f * std::sin(2.0f * pi * f0 * 3.0f * t)
        );
    }
    return samples;
}
}

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: voice_profile_smoke <work-directory>\n";
        return 2;
    }
    const std::string base = argv[1];
    const std::string clipA = base + "/clip-a.wav";
    const std::string clipB = base + "/clip-b.wav";
    const std::string profile = base + "/test.vsptrain";
    const std::string applied = base + "/applied.wav";
    std::string error;

    if (!WavIO::writeMono24(clipA, makeVoiceLike(138.0f, 4.0f), 48000, error) ||
        !WavIO::writeMono24(clipB, makeVoiceLike(216.0f, 4.0f), 48000, error)) {
        std::cerr << "fixture failed: " << error << '\n';
        return 3;
    }
    const int trained = VoiceProfileEngine::trainMany({clipA, clipB}, profile, error);
    if (trained != 0 || VoiceProfileEngine::trainingProgress() < 0.999f) {
        std::cerr << "training failed " << trained << ": " << error << '\n';
        return 4;
    }
    VoiceProfileMetrics metrics{};
    if (VoiceProfileEngine::inspect(profile, metrics, error) != 0 || metrics.version != 3 ||
        metrics.sourceSeconds < 7.9f || metrics.qualityScore <= 0.0f) {
        std::cerr << "inspection failed: " << error << '\n';
        return 5;
    }
    if (VoiceProfileEngine::apply(clipA, applied, profile, 0.78f, error) != 0) {
        std::cerr << "application failed: " << error << '\n';
        return 6;
    }
    AudioBuffer output;
    if (!WavIO::readMonoFloat(applied, output, error) || output.mono.empty()) {
        std::cerr << "output validation failed: " << error << '\n';
        return 7;
    }
    std::cout << "PASS version=" << metrics.version
              << " source=" << metrics.sourceSeconds
              << " clean=" << metrics.cleanSeconds
              << " quality=" << metrics.qualityScore << '\n';
    return 0;
}

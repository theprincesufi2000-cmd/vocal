#include <jni.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include "VocalEngine.h"
#include "PitchDetector.h"
#include "VoiceProfileEngine.h"

namespace {
VocalParams paramsFrom(
    jint rootPitchClass, jint scaleMode,
    jfloat strength, jfloat retuneMs, jfloat humanize,
    jfloat noiseReduction, jfloat clarity, jfloat warmth, jfloat air,
    jfloat deEsser, jfloat compression, jfloat leveling, jfloat reverb) {
    VocalParams p;
    p.rootPitchClass = rootPitchClass;
    p.scaleMode = scaleMode;
    p.strength = strength;
    p.retuneMs = retuneMs;
    p.humanize = humanize;
    p.noiseReduction = noiseReduction;
    p.clarity = clarity;
    p.warmth = warmth;
    p.air = air;
    p.deEsser = deEsser;
    p.compression = compression;
    p.leveling = leveling;
    p.reverb = reverb;
    return p;
}

template <typename Fn>
jint withPaths(JNIEnv* env, jstring inputPath, jstring outputPath, Fn&& fn) {
    if (!inputPath || !outputPath) return 1;
    const char* in = env->GetStringUTFChars(inputPath, nullptr);
    const char* out = env->GetStringUTFChars(outputPath, nullptr);
    if (!in || !out) {
        if (in) env->ReleaseStringUTFChars(inputPath, in);
        if (out) env->ReleaseStringUTFChars(outputPath, out);
        return 2;
    }
    std::string error;
    const int result = fn(in, out, error);
    env->ReleaseStringUTFChars(inputPath, in);
    env->ReleaseStringUTFChars(outputPath, out);
    return result;
}
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_processWav(
    JNIEnv* env, jclass, jstring inputPath, jstring outputPath,
    jint rootPitchClass, jint scaleMode, jfloat strength, jfloat retuneMs, jfloat humanize,
    jfloat noiseReduction, jfloat clarity, jfloat warmth, jfloat air,
    jfloat deEsser, jfloat compression, jfloat leveling, jfloat reverb) {
    const VocalParams p = paramsFrom(rootPitchClass, scaleMode, strength, retuneMs, humanize,
                                     noiseReduction, clarity, warmth, air, deEsser,
                                     compression, leveling, reverb);
    return withPaths(env, inputPath, outputPath,
        [&](const char* in, const char* out, std::string& error) {
            return VocalEngine::processFile(in, out, p, error);
        });
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_prepareForVoiceModel(
    JNIEnv* env, jclass, jstring inputPath, jstring outputPath,
    jint rootPitchClass, jint scaleMode, jfloat strength, jfloat retuneMs, jfloat humanize,
    jfloat noiseReduction) {
    VocalParams p;
    p.rootPitchClass = rootPitchClass;
    p.scaleMode = scaleMode;
    p.strength = strength;
    p.retuneMs = retuneMs;
    p.humanize = humanize;
    p.noiseReduction = noiseReduction;
    return withPaths(env, inputPath, outputPath,
        [&](const char* in, const char* out, std::string& error) {
            return VocalEngine::prepareForVoiceModel(in, out, p, error);
        });
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_masterOnly(
    JNIEnv* env, jclass, jstring inputPath, jstring outputPath,
    jfloat clarity, jfloat warmth, jfloat air, jfloat deEsser,
    jfloat compression, jfloat leveling, jfloat reverb) {
    VocalParams p;
    p.clarity = clarity;
    p.warmth = warmth;
    p.air = air;
    p.deEsser = deEsser;
    p.compression = compression;
    p.leveling = leveling;
    p.reverb = reverb;
    return withPaths(env, inputPath, outputPath,
        [&](const char* in, const char* out, std::string& error) {
            return VocalEngine::masterOnly(in, out, p, error);
        });
}


extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_extractF0(
    JNIEnv* env, jclass, jfloatArray samplesArray, jint sampleRate,
    jint frameCount, jfloat minHz, jfloat maxHz) {
    if (!samplesArray || sampleRate <= 0 || frameCount <= 0 || minHz <= 0.0f || maxHz <= minHz) {
        return env->NewFloatArray(0);
    }

    const jsize length = env->GetArrayLength(samplesArray);
    jfloatArray resultArray = env->NewFloatArray(frameCount);
    if (!resultArray || length < 128) return resultArray;

    jboolean isCopy = JNI_FALSE;
    jfloat* samples = env->GetFloatArrayElements(samplesArray, &isCopy);
    if (!samples) return resultArray;

    std::vector<float> output(static_cast<size_t>(frameCount), 0.0f);
    const int decimation = sampleRate >= 12000 ? 2 : 1;
    const int detectorRate = sampleRate / decimation;
    const int sourceWindow = std::min<int>(length, std::max(512, sampleRate / 16));
    const int decimatedWindow = std::max(256, sourceWindow / decimation);
    std::vector<float> window(static_cast<size_t>(decimatedWindow));
    PitchDetector detector;

    for (int frame = 0; frame < frameCount; ++frame) {
        const double position = (static_cast<double>(frame) + 0.5) * static_cast<double>(length) /
                                static_cast<double>(frameCount);
        int start = static_cast<int>(std::llround(position)) - sourceWindow / 2;
        start = std::clamp(start, 0, std::max(0, static_cast<int>(length) - sourceWindow));

        int copied = 0;
        for (int i = 0; i < sourceWindow && copied < decimatedWindow; i += decimation) {
            window[static_cast<size_t>(copied++)] = samples[start + i];
        }
        if (copied < 128) continue;

        const PitchResult r = detector.detectYin(
            window.data(), copied, detectorRate,
            std::max(40.0f, minHz), std::min(2000.0f, maxHz), 0.15f);
        if (r.frequency > 0.0f && r.confidence >= 0.48f) {
            output[static_cast<size_t>(frame)] = r.frequency;
        }
    }

    // Lightweight 3-frame median smoothing on voiced tracks to reduce octave spikes.
    if (frameCount >= 3) {
        std::vector<float> smoothed = output;
        for (int i = 1; i + 1 < frameCount; ++i) {
            const float a = output[static_cast<size_t>(i - 1)];
            const float b = output[static_cast<size_t>(i)];
            const float c = output[static_cast<size_t>(i + 1)];
            if (a > 0.0f && b > 0.0f && c > 0.0f) {
                float values[3] = {a, b, c};
                std::sort(values, values + 3);
                smoothed[static_cast<size_t>(i)] = values[1];
            }
        }
        output.swap(smoothed);
    }

    env->ReleaseFloatArrayElements(samplesArray, samples, JNI_ABORT);
    env->SetFloatArrayRegion(resultArray, 0, frameCount, output.data());
    return resultArray;
}


extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_trainVoiceProfile(
    JNIEnv* env, jclass, jstring inputPath, jstring profilePath) {
    return withPaths(env, inputPath, profilePath,
        [&](const char* in, const char* out, std::string& error) {
            return VoiceProfileEngine::train(in, out, error);
        });
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_trainVoiceProfileSet(
    JNIEnv* env, jclass, jobjectArray inputPaths, jstring profilePath) {
    if (!inputPaths || !profilePath) return 1;
    const jsize count = env->GetArrayLength(inputPaths);
    if (count <= 0 || count > 64) return 2;

    std::vector<std::string> paths;
    paths.reserve(static_cast<size_t>(count));
    for (jsize i = 0; i < count; ++i) {
        auto value = static_cast<jstring>(env->GetObjectArrayElement(inputPaths, i));
        if (!value) return 3;
        const char* chars = env->GetStringUTFChars(value, nullptr);
        if (!chars) {
            env->DeleteLocalRef(value);
            return 4;
        }
        paths.emplace_back(chars);
        env->ReleaseStringUTFChars(value, chars);
        env->DeleteLocalRef(value);
    }

    const char* output = env->GetStringUTFChars(profilePath, nullptr);
    if (!output) return 5;
    std::string error;
    const int result = VoiceProfileEngine::trainMany(paths, output, error);
    env->ReleaseStringUTFChars(profilePath, output);
    return result;
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_inspectVoiceProfile(
    JNIEnv* env, jclass, jstring profilePath) {
    jfloatArray result = env->NewFloatArray(10);
    if (!result || !profilePath) return result;

    const char* path = env->GetStringUTFChars(profilePath, nullptr);
    if (!path) return result;
    VoiceProfileMetrics metrics{};
    std::string error;
    const int code = VoiceProfileEngine::inspect(path, metrics, error);
    env->ReleaseStringUTFChars(profilePath, path);

    jfloat values[10] = {
        code == 0 ? static_cast<jfloat>(metrics.version) : -1.0f,
        metrics.sourceSeconds,
        metrics.cleanSeconds,
        metrics.qualityScore,
        metrics.clippingRatio,
        metrics.noiseFloorDb,
        metrics.medianF0,
        metrics.voicedRatio,
        metrics.spectralCentroid,
        static_cast<jfloat>(metrics.analyzedFrames)
    };
    env->SetFloatArrayRegion(result, 0, 10, values);
    return result;
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_voiceProfileTrainingProgress(
    JNIEnv*, jclass) {
    return VoiceProfileEngine::trainingProgress();
}

extern "C" JNIEXPORT void JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_cancelVoiceProfileTraining(
    JNIEnv*, jclass) {
    VoiceProfileEngine::cancelTraining();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_applyVoiceProfile(
    JNIEnv* env, jclass, jstring inputPath, jstring outputPath,
    jstring profilePath, jfloat strength) {
    if (!inputPath || !outputPath || !profilePath) return 1;
    const char* in = env->GetStringUTFChars(inputPath, nullptr);
    const char* out = env->GetStringUTFChars(outputPath, nullptr);
    const char* profile = env->GetStringUTFChars(profilePath, nullptr);
    if (!in || !out || !profile) {
        if (in) env->ReleaseStringUTFChars(inputPath, in);
        if (out) env->ReleaseStringUTFChars(outputPath, out);
        if (profile) env->ReleaseStringUTFChars(profilePath, profile);
        return 2;
    }
    std::string error;
    const int result = VoiceProfileEngine::apply(in, out, profile, strength, error);
    env->ReleaseStringUTFChars(inputPath, in);
    env->ReleaseStringUTFChars(outputPath, out);
    env->ReleaseStringUTFChars(profilePath, profile);
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_validateVoiceProfile(
    JNIEnv* env, jclass, jstring profilePath) {
    if (!profilePath) return 1;
    const char* profile = env->GetStringUTFChars(profilePath, nullptr);
    if (!profile) return 2;
    std::string error;
    const int result = VoiceProfileEngine::validate(profile, error);
    env->ReleaseStringUTFChars(profilePath, profile);
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_engineVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF(VocalEngine::version());
}

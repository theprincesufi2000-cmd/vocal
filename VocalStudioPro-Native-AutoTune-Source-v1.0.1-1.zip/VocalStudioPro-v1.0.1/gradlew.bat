@echo off
setlocal enabledelayedexpansion

where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)

set ROOT=%~dp0
set VERSION=9.6.0
set BOOT=%ROOT%.gradle-bootstrap\gradle-%VERSION%
set ZIP=%ROOT%.gradle-bootstrap\gradle-%VERSION%-bin.zip
set URL=https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip

if not exist "%BOOT%\bin\gradle.bat" (
  if not exist "%ROOT%.gradle-bootstrap" mkdir "%ROOT%.gradle-bootstrap"
  echo Bootstrapping Gradle %VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop'; $zip='%ZIP%'; $url='%URL%'; if (!(Test-Path $zip)) { Invoke-WebRequest -Uri $url -OutFile $zip }; Expand-Archive -Path $zip -DestinationPath '%ROOT%.gradle-bootstrap' -Force"
  if errorlevel 1 (
    echo Failed to bootstrap Gradle %VERSION%.
    exit /b 1
  )
)

call "%BOOT%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%

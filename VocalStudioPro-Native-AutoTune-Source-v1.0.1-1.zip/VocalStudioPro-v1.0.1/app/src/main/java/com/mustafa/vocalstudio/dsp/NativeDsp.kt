package com.mustafa.vocalstudio.dsp

object NativeDsp {
    init {
        System.loadLibrary("vocal_dsp")
    }

    @JvmStatic
    external fun processWav(
        inputPath: String,
        outputPath: String,
        rootPitchClass: Int,
        scaleMode: Int,
        strength: Float,
        retuneMs: Float,
        humanize: Float,
        noiseReduction: Float,
        deEsser: Float,
        compression: Float,
        reverb: Float
    ): Int

    @JvmStatic
    external fun engineVersion(): String
}

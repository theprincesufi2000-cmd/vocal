package com.mustafa.vocalstudio

import android.app.Application
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.mustafa.vocalstudio.audio.AudioDecoder
import com.mustafa.vocalstudio.audio.AudioRecorder
import com.mustafa.vocalstudio.audio.WavPlayer
import com.mustafa.vocalstudio.dsp.NativeDsp
import com.mustafa.vocalstudio.dsp.ProcessingParams
import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.util.concurrent.Executors


data class StudioUiState(
    val sourceFile: File? = null,
    val sourceName: String = "لا يوجد تسجيل",
    val processedFile: File? = null,
    val sourceWaveform: List<Float> = emptyList(),
    val processedWaveform: List<Float> = emptyList(),
    val params: ProcessingParams = ProcessingParams(),
    val isRecording: Boolean = false,
    val isBusy: Boolean = false,
    val isPlayingSource: Boolean = false,
    val isPlayingProcessed: Boolean = false,
    val status: String = "جاهز",
    val engineVersion: String = "Native DSP"
)

class StudioViewModel(app: Application) : AndroidViewModel(app) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val recorder = AudioRecorder(app)
    private val player = WavPlayer()

    var uiState by mutableStateOf(
        StudioUiState(engineVersion = runCatching { NativeDsp.engineVersion() }.getOrDefault("Native DSP"))
    )
        private set

    fun setRoot(root: Int) = updateParams { copy(rootPitchClass = root.coerceIn(0, 11)) }
    fun setScaleMode(mode: Int) = updateParams { copy(scaleMode = mode.coerceIn(0, 1)) }
    fun setStrength(value: Float) = updateParams { copy(strength = value.coerceIn(0f, 1f)) }
    fun setRetune(value: Float) = updateParams { copy(retuneMs = value.coerceIn(2f, 140f)) }
    fun setHumanize(value: Float) = updateParams { copy(humanize = value.coerceIn(0f, 1f)) }
    fun setNoise(value: Float) = updateParams { copy(noiseReduction = value.coerceIn(0f, 1f)) }
    fun setDeEsser(value: Float) = updateParams { copy(deEsser = value.coerceIn(0f, 1f)) }
    fun setCompression(value: Float) = updateParams { copy(compression = value.coerceIn(0f, 1f)) }
    fun setReverb(value: Float) = updateParams { copy(reverb = value.coerceIn(0f, 1f)) }

    fun applyPreset(name: String) {
        val current = uiState.params
        val p = when (name) {
            "Natural" -> current.copy(
                strength = 0.78f,
                retuneMs = 72f,
                humanize = 0.72f,
                noiseReduction = 0.28f,
                deEsser = 0.35f,
                compression = 0.50f,
                reverb = 0.14f
            )
            "Hard" -> current.copy(
                strength = 1.0f,
                retuneMs = 5f,
                humanize = 0f,
                noiseReduction = 0.38f,
                deEsser = 0.52f,
                compression = 0.72f,
                reverb = 0.20f
            )
            else -> current.copy(
                strength = 0.95f,
                retuneMs = 20f,
                humanize = 0.25f,
                noiseReduction = 0.35f,
                deEsser = 0.45f,
                compression = 0.60f,
                reverb = 0.18f
            )
        }
        uiState = uiState.copy(params = p, status = "تم تطبيق إعداد $name")
    }

    fun startRecording() {
        if (uiState.isBusy || uiState.isRecording) return
        val dir = getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            ?: getApplication<Application>().filesDir
        val file = File(dir, "raw_vocal_${System.currentTimeMillis()}.wav")
        runCatching {
            player.stop()
            recorder.start(file)
            uiState = uiState.copy(
                isRecording = true,
                status = "جاري التسجيل الخام 48 kHz…",
                processedFile = null,
                processedWaveform = emptyList()
            )
        }.onFailure {
            uiState = uiState.copy(status = "فشل بدء التسجيل: ${it.message}")
        }
    }

    fun stopRecording() {
        if (!uiState.isRecording) return
        val dir = getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            ?: getApplication<Application>().filesDir
        // AudioRecorder writes to the latest raw_vocal file; find the newest finalized file.
        recorder.stop()
        val file = dir.listFiles { f -> f.name.startsWith("raw_vocal_") && f.extension == "wav" }
            ?.maxByOrNull { it.lastModified() }
        if (file != null && file.length() > 44) {
            setSource(file, "تسجيل جديد")
        } else {
            uiState = uiState.copy(isRecording = false, status = "لم يتم إنشاء تسجيل صالح")
        }
    }

    fun importAudio(uri: Uri) {
        if (uiState.isBusy || uiState.isRecording) return
        val app = getApplication<Application>()
        val displayName = queryName(uri) ?: "ملف صوت"
        uiState = uiState.copy(isBusy = true, status = "جاري فك الصوت وتحضيره…")
        executor.execute {
            try {
                val out = File(app.cacheDir, "import_${System.currentTimeMillis()}.wav")
                AudioDecoder.toWav(app, uri, out)
                val peaks = WavUtils.waveform(out)
                main.post {
                    player.stop()
                    uiState = uiState.copy(
                        sourceFile = out,
                        sourceName = displayName,
                        processedFile = null,
                        sourceWaveform = peaks,
                        processedWaveform = emptyList(),
                        isBusy = false,
                        status = "تم تجهيز الصوت للمعالجة"
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(isBusy = false, status = "فشل استيراد الصوت: ${t.message}")
                }
            }
        }
    }

    fun process() {
        val input = uiState.sourceFile ?: run {
            uiState = uiState.copy(status = "سجّل أو اختر ملفًا صوتيًا أولًا")
            return
        }
        if (uiState.isBusy || uiState.isRecording) return
        val app = getApplication<Application>()
        val dir = app.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: app.filesDir
        val output = File(dir, "studio_master_${System.currentTimeMillis()}.wav")
        val p = uiState.params
        player.stop()
        uiState = uiState.copy(
            isBusy = true,
            isPlayingSource = false,
            isPlayingProcessed = false,
            status = "تحليل النغمات وتصحيح الأداء ثم الماستر…"
        )
        executor.execute {
            try {
                val code = NativeDsp.processWav(
                    input.absolutePath,
                    output.absolutePath,
                    p.rootPitchClass,
                    p.scaleMode,
                    p.strength,
                    p.retuneMs,
                    p.humanize,
                    p.noiseReduction,
                    p.deEsser,
                    p.compression,
                    p.reverb
                )
                if (code != 0 || !output.exists() || output.length() <= 44) {
                    error("Native DSP error $code")
                }
                val peaks = WavUtils.waveform(output)
                main.post {
                    uiState = uiState.copy(
                        processedFile = output,
                        processedWaveform = peaks,
                        isBusy = false,
                        status = "اكتملت المعالجة — WAV 24-bit / 48 kHz"
                    )
                }
            } catch (t: Throwable) {
                main.post {
                    uiState = uiState.copy(isBusy = false, status = "فشلت المعالجة: ${t.message}")
                }
            }
        }
    }

    fun playSource() {
        val file = uiState.sourceFile ?: return
        if (uiState.isPlayingSource) {
            player.stop()
            uiState = uiState.copy(isPlayingSource = false)
            return
        }
        player.stop()
        uiState = uiState.copy(isPlayingSource = true, isPlayingProcessed = false)
        player.play(file) {
            main.post { uiState = uiState.copy(isPlayingSource = false) }
        }
    }

    fun playProcessed() {
        val file = uiState.processedFile ?: return
        if (uiState.isPlayingProcessed) {
            player.stop()
            uiState = uiState.copy(isPlayingProcessed = false)
            return
        }
        player.stop()
        uiState = uiState.copy(isPlayingProcessed = true, isPlayingSource = false)
        player.play(file) {
            main.post { uiState = uiState.copy(isPlayingProcessed = false) }
        }
    }

    fun exportTo(uri: Uri) {
        val source = uiState.processedFile ?: return
        uiState = uiState.copy(isBusy = true, status = "جاري حفظ WAV…")
        executor.execute {
            try {
                getApplication<Application>().contentResolver.openOutputStream(uri, "w").use { out ->
                    requireNotNull(out) { "Cannot open export destination" }
                    source.inputStream().use { it.copyTo(out, 256 * 1024) }
                }
                main.post { uiState = uiState.copy(isBusy = false, status = "تم حفظ ملف WAV بنجاح") }
            } catch (t: Throwable) {
                main.post { uiState = uiState.copy(isBusy = false, status = "فشل الحفظ: ${t.message}") }
            }
        }
    }

    fun suggestedExportName(): String = "VocalStudio_${System.currentTimeMillis()}.wav"

    private fun setSource(file: File, name: String) {
        val peaks = runCatching { WavUtils.waveform(file) }.getOrDefault(emptyList())
        uiState = uiState.copy(
            sourceFile = file,
            sourceName = name,
            sourceWaveform = peaks,
            processedFile = null,
            processedWaveform = emptyList(),
            isRecording = false,
            status = "تم حفظ التسجيل الخام"
        )
    }

    private fun queryName(uri: Uri): String? {
        val resolver = getApplication<Application>().contentResolver
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    private inline fun updateParams(block: ProcessingParams.() -> ProcessingParams) {
        uiState = uiState.copy(params = uiState.params.block())
    }

    override fun onCleared() {
        runCatching { recorder.stop() }
        player.stop()
        executor.shutdownNow()
        super.onCleared()
    }
}

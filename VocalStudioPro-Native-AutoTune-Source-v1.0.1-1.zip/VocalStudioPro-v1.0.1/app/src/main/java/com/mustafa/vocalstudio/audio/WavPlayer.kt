package com.mustafa.vocalstudio.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class WavPlayer {
    private val playing = AtomicBoolean(false)
    private var worker: Thread? = null
    private var track: AudioTrack? = null

    fun isPlaying(): Boolean = playing.get()

    fun play(file: File, onFinished: (() -> Unit)? = null) {
        stop()
        val info = WavUtils.readInfo(file)
        val channelMask = if (info.channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val min = AudioTrack.getMinBufferSize(
            info.sampleRate,
            channelMask,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(16 * 1024)

        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(info.sampleRate)
                    .setChannelMask(channelMask)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(min * 2)
            .build()

        track = audioTrack
        playing.set(true)
        audioTrack.play()

        worker = thread(name = "VocalStudioPlayer", isDaemon = true) {
            try {
                RandomAccessFile(file, "r").use { raf ->
                    raf.seek(info.dataOffset)
                    val frameBytes = info.channels * (info.bitsPerSample / 8)
                    val maxData = info.dataSize
                    var readData = 0L
                    val source = ByteArray(64 * 1024)
                    // 8-bit input expands 2x when converted to PCM16.
                    val pcm16 = ByteArray(128 * 1024)
                    val alignedCapacity = source.size - (source.size % frameBytes.coerceAtLeast(1))

                    while (playing.get() && readData < maxData) {
                        var wanted = minOf(alignedCapacity.toLong(), maxData - readData).toInt()
                        wanted -= wanted % frameBytes.coerceAtLeast(1)
                        if (wanted <= 0) break
                        val n = raf.read(source, 0, wanted)
                        if (n <= 0) break
                        readData += n
                        val converted = convertTo16(source, n, info.bitsPerSample, info.audioFormat, pcm16)
                        var offset = 0
                        while (playing.get() && offset < converted) {
                            val written = audioTrack.write(pcm16, offset, converted - offset, AudioTrack.WRITE_BLOCKING)
                            if (written <= 0) break
                            offset += written
                        }
                    }
                }
            } finally {
                playing.set(false)
                runCatching { audioTrack.stop() }
                runCatching { audioTrack.release() }
                if (track === audioTrack) track = null
                onFinished?.invoke()
            }
        }
    }

    fun stop() {
        if (!playing.getAndSet(false)) return
        runCatching { track?.pause() }
        runCatching { track?.flush() }
        worker?.join(1_000)
        worker = null
        track = null
    }

    private fun convertTo16(
        source: ByteArray,
        length: Int,
        bits: Int,
        format: Int,
        out: ByteArray
    ): Int {
        if (format == 1 && bits == 16) {
            val n = minOf(length, out.size)
            source.copyInto(out, endIndex = n)
            return n
        }
        val bytesPerSample = (bits / 8).coerceAtLeast(1)
        val samples = length / bytesPerSample
        val usable = minOf(samples, out.size / 2)
        var src = 0
        var dst = 0
        repeat(usable) {
            val v = when {
                format == 3 && bits == 32 -> {
                    val raw = (source[src].toInt() and 0xff) or
                        ((source[src + 1].toInt() and 0xff) shl 8) or
                        ((source[src + 2].toInt() and 0xff) shl 16) or
                        ((source[src + 3].toInt() and 0xff) shl 24)
                    (Float.fromBits(raw).coerceIn(-1f, 1f) * 32767f).toInt()
                }
                bits == 24 -> {
                    var raw = (source[src].toInt() and 0xff) or
                        ((source[src + 1].toInt() and 0xff) shl 8) or
                        ((source[src + 2].toInt() and 0xff) shl 16)
                    if ((raw and 0x800000) != 0) raw = raw or -0x1000000
                    raw shr 8
                }
                bits == 32 -> {
                    val raw = (source[src].toInt() and 0xff) or
                        ((source[src + 1].toInt() and 0xff) shl 8) or
                        ((source[src + 2].toInt() and 0xff) shl 16) or
                        ((source[src + 3].toInt() and 0xff) shl 24)
                    raw shr 16
                }
                bits == 8 -> ((source[src].toInt() and 0xff) - 128) shl 8
                else -> 0
            }.coerceIn(-32768, 32767)
            out[dst++] = (v and 0xff).toByte()
            out[dst++] = ((v ushr 8) and 0xff).toByte()
            src += bytesPerSample
        }
        return dst
    }
}

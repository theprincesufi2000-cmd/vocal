package com.mustafa.vocalstudio.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import com.mustafa.vocalstudio.util.WavUtils
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class AudioRecorder(private val context: Context) {
    private val running = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private var recordThread: Thread? = null

    fun isRecording(): Boolean = running.get()

    fun start(output: File) {
        check(!running.get()) { "Recorder already running" }
        val sampleRate = 48_000
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(sampleRate / 10)

        val source = if (supportsUnprocessed()) {
            MediaRecorder.AudioSource.UNPROCESSED
        } else {
            MediaRecorder.AudioSource.VOICE_RECOGNITION
        }

        val audioRecord = AudioRecord.Builder()
            .setAudioSource(source)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(minBuffer * 4)
            .build()

        check(audioRecord.state == AudioRecord.STATE_INITIALIZED) { "AudioRecord initialization failed" }
        disablePlatformEffects(audioRecord.audioSessionId)

        output.parentFile?.mkdirs()
        val raf = RandomAccessFile(output, "rw")
        raf.setLength(0)
        WavUtils.writePcmHeader(raf, sampleRate, 1, 16, 0)

        recorder = audioRecord
        running.set(true)
        audioRecord.startRecording()

        recordThread = thread(name = "VocalStudioRecorder", isDaemon = true) {
            val buffer = ShortArray(minBuffer)
            var dataBytes = 0L
            try {
                while (running.get()) {
                    val n = audioRecord.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                    if (n > 0) {
                        for (i in 0 until n) {
                            val v = buffer[i].toInt()
                            raf.write(v and 0xff)
                            raf.write((v ushr 8) and 0xff)
                        }
                        dataBytes += n * 2L
                    }
                }
            } finally {
                runCatching { audioRecord.stop() }
                runCatching { audioRecord.release() }
                WavUtils.writePcmHeader(raf, sampleRate, 1, 16, dataBytes)
                raf.close()
            }
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        recordThread?.join(2_000)
        recordThread = null
        recorder = null
    }

    private fun supportsUnprocessed(): Boolean {
        val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return manager.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED)
            ?.equals("true", ignoreCase = true) == true
    }

    private fun disablePlatformEffects(sessionId: Int) {
        runCatching { AutomaticGainControl.create(sessionId)?.apply { enabled = false } }
        runCatching { NoiseSuppressor.create(sessionId)?.apply { enabled = false } }
        runCatching { AcousticEchoCanceler.create(sessionId)?.apply { enabled = false } }
    }
}

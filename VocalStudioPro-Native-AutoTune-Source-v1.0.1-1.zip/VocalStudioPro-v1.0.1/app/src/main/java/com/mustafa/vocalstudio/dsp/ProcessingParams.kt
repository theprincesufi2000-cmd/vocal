package com.mustafa.vocalstudio.dsp

data class ProcessingParams(
    val rootPitchClass: Int = 0,
    val scaleMode: Int = 0, // 0 major, 1 natural minor
    val strength: Float = 0.95f,
    val retuneMs: Float = 20f,
    val humanize: Float = 0.25f,
    val noiseReduction: Float = 0.35f,
    val deEsser: Float = 0.45f,
    val compression: Float = 0.60f,
    val reverb: Float = 0.18f
)

#include "VocalEngine.h"
#include "DspProcessors.h"
#include "PhaseVocoder.h"
#include "PitchDetector.h"
#include "ScaleQuantizer.h"
#include "WavIO.h"
#include <algorithm>
#include <cmath>
#include <vector>

namespace {
constexpr int INTERNAL_SR = 48000;
}

const char* VocalEngine::version() {
    return "VocalDSP 1.0 · YIN + Scale Quantizer + Phase Vocoder";
}

int VocalEngine::processFile(const std::string& inputPath, const std::string& outputPath,
                             const VocalParams& rawParams, std::string& error) {
    VocalParams p = rawParams;
    p.rootPitchClass = ((p.rootPitchClass % 12) + 12) % 12;
    p.scaleMode = p.scaleMode == 1 ? 1 : 0;
    p.strength = std::clamp(p.strength, 0.0f, 1.0f);
    p.retuneMs = std::clamp(p.retuneMs, 2.0f, 140.0f);
    p.humanize = std::clamp(p.humanize, 0.0f, 1.0f);
    p.noiseReduction = std::clamp(p.noiseReduction, 0.0f, 1.0f);
    p.deEsser = std::clamp(p.deEsser, 0.0f, 1.0f);
    p.compression = std::clamp(p.compression, 0.0f, 1.0f);
    p.reverb = std::clamp(p.reverb, 0.0f, 0.5f);

    AudioBuffer source;
    if (!WavIO::readMonoFloat(inputPath, source, error)) return 10;
    if (source.mono.size() < 2048) { error = "Audio is too short"; return 11; }

    std::vector<float> audio = source.sampleRate == INTERNAL_SR
        ? source.mono
        : WavIO::resampleSinc(source.mono, source.sampleRate, INTERNAL_SR);

    if (audio.empty()) { error = "Resampling produced no audio"; return 12; }
    DspProcessors::preprocess(audio, INTERNAL_SR, p.noiseReduction);

    PitchDetector detector;
    PhaseVocoder shifter(INTERNAL_SR, 2048, 8);
    const int hop = shifter.hopSize();
    const int detectN = 4096;
    const int halfDetect = detectN / 2;
    std::vector<float> detectFrame(detectN, 0.0f);
    std::vector<float> streamed;
    streamed.reserve(audio.size() + shifter.latency() + 4096);

    float smoothedShift = 0.0f;
    float lastVoicedShift = 0.0f;
    float stableF0 = 0.0f;
    const float blockSeconds = hop / static_cast<float>(INTERNAL_SR);
    const float retuneTau = std::max(0.002f, p.retuneMs / 1000.0f);
    const float voicedAlpha = std::exp(-blockSeconds / retuneTau);
    const float unvoicedAlpha = std::exp(-blockSeconds / 0.080f);

    for (size_t pos = 0; pos < audio.size(); pos += hop) {
        const int count = static_cast<int>(std::min<size_t>(hop, audio.size() - pos));
        const int center = static_cast<int>(pos) + count / 2;
        for (int i = 0; i < detectN; ++i) {
            const int idx = center - halfDetect + i;
            detectFrame[i] = (idx >= 0 && idx < static_cast<int>(audio.size())) ? audio[idx] : 0.0f;
        }

        PitchResult pitch = detector.detectYin(detectFrame.data(), detectN, INTERNAL_SR);
        float targetShift = 0.0f;
        const bool voiced = pitch.frequency > 0.0f && pitch.confidence >= 0.66f;
        if (voiced) {
            if (stableF0 <= 0.0f) stableF0 = pitch.frequency;
            else {
                const float octaveRatio = pitch.frequency / stableF0;
                // Reject occasional octave mistakes from the detector.
                float f = pitch.frequency;
                if (octaveRatio > 1.85f && octaveRatio < 2.15f) f *= 0.5f;
                else if (octaveRatio > 0.46f && octaveRatio < 0.54f) f *= 2.0f;
                stableF0 = 0.82f * stableF0 + 0.18f * f;
                pitch.frequency = f;
            }

            targetShift = ScaleQuantizer::correctionSemitones(pitch.frequency, p.rootPitchClass, p.scaleMode);
            targetShift = std::clamp(targetShift, -4.0f, 4.0f);

            // Strength sets how tightly notes snap; Humanize protects micro-pitch and vibrato near a note center.
            const float absShift = std::abs(targetShift);
            const float preserve = p.humanize * 0.55f * std::exp(-absShift * 2.2f);
            targetShift *= p.strength * (1.0f - preserve);
            if (absShift < 0.025f) targetShift = 0.0f;
            lastVoicedShift = targetShift;
            smoothedShift = voicedAlpha * smoothedShift + (1.0f - voicedAlpha) * targetShift;
        } else {
            stableF0 = 0.0f;
            // Do not retune breaths/unvoiced consonants; smoothly return to neutral.
            const float fallback = lastVoicedShift * 0.15f;
            smoothedShift = unvoicedAlpha * smoothedShift + (1.0f - unvoicedAlpha) * fallback;
        }

        const float factor = std::pow(2.0f, smoothedShift / 12.0f);
        std::vector<float> blockOut;
        shifter.process(audio.data() + pos, count, factor, blockOut);
        streamed.insert(streamed.end(), blockOut.begin(), blockOut.end());
    }

    // Flush the phase-vocoder latency so the offline file keeps the original duration.
    std::vector<float> zeros(shifter.latency() + shifter.frameSize(), 0.0f);
    std::vector<float> tail;
    const float finalFactor = std::pow(2.0f, smoothedShift / 12.0f);
    shifter.process(zeros.data(), static_cast<int>(zeros.size()), finalFactor, tail);
    streamed.insert(streamed.end(), tail.begin(), tail.end());

    const size_t latency = static_cast<size_t>(shifter.latency());
    std::vector<float> tuned(audio.size(), 0.0f);
    for (size_t i = 0; i < tuned.size(); ++i) {
        const size_t src = i + latency;
        if (src < streamed.size()) tuned[i] = streamed[src];
    }

    DspProcessors::master(tuned, INTERNAL_SR, p.deEsser, p.compression, p.reverb);
    DspProcessors::normalize(tuned, 0.89125f);

    if (!WavIO::writeMono24(outputPath, tuned, INTERNAL_SR, error)) return 20;
    return 0;
}

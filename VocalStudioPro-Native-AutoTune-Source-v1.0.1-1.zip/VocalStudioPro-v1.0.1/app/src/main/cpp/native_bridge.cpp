#include <jni.h>
#include <string>
#include "VocalEngine.h"

extern "C" JNIEXPORT jint JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_processWav(
    JNIEnv* env,
    jclass,
    jstring inputPath,
    jstring outputPath,
    jint rootPitchClass,
    jint scaleMode,
    jfloat strength,
    jfloat retuneMs,
    jfloat humanize,
    jfloat noiseReduction,
    jfloat deEsser,
    jfloat compression,
    jfloat reverb
) {
    if (!inputPath || !outputPath) return 1;
    const char* in = env->GetStringUTFChars(inputPath, nullptr);
    const char* out = env->GetStringUTFChars(outputPath, nullptr);
    if (!in || !out) {
        if (in) env->ReleaseStringUTFChars(inputPath, in);
        if (out) env->ReleaseStringUTFChars(outputPath, out);
        return 2;
    }

    VocalParams p;
    p.rootPitchClass = rootPitchClass;
    p.scaleMode = scaleMode;
    p.strength = strength;
    p.retuneMs = retuneMs;
    p.humanize = humanize;
    p.noiseReduction = noiseReduction;
    p.deEsser = deEsser;
    p.compression = compression;
    p.reverb = reverb;

    std::string error;
    int result = VocalEngine::processFile(in, out, p, error);
    env->ReleaseStringUTFChars(inputPath, in);
    env->ReleaseStringUTFChars(outputPath, out);
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mustafa_vocalstudio_dsp_NativeDsp_engineVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF(VocalEngine::version());
}

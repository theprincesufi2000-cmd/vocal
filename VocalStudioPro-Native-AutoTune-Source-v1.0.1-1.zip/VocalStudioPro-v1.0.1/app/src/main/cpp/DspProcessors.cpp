#include "DspProcessors.h"
#include <algorithm>
#include <cmath>
#include <numeric>

namespace {
constexpr float PI = 3.14159265358979323846f;
float dbToGain(float db) { return std::pow(10.0f, db / 20.0f); }
float gainToDb(float x) { return 20.0f * std::log10(std::max(x, 1e-9f)); }

struct Comb {
    std::vector<float> buf;
    size_t index = 0;
    float feedback = 0.78f;
    float damp = 0.25f;
    float filter = 0.0f;
    explicit Comb(int delay) : buf(std::max(1, delay), 0.0f) {}
    float process(float x) {
        const float y = buf[index];
        filter = y * (1.0f - damp) + filter * damp;
        buf[index] = x + filter * feedback;
        if (++index >= buf.size()) index = 0;
        return y;
    }
};

struct Allpass {
    std::vector<float> buf;
    size_t index = 0;
    float feedback = 0.5f;
    explicit Allpass(int delay) : buf(std::max(1, delay), 0.0f) {}
    float process(float x) {
        const float b = buf[index];
        const float y = -x + b;
        buf[index] = x + b * feedback;
        if (++index >= buf.size()) index = 0;
        return y;
    }
};
}

void Biquad::set(float b0, float b1, float b2, float a0, float a1, float a2) {
    b0_ = b0 / a0; b1_ = b1 / a0; b2_ = b2 / a0;
    a1_ = a1 / a0; a2_ = a2 / a0;
}
void Biquad::reset() { z1_ = z2_ = 0.0f; }
float Biquad::process(float x) {
    const float y = b0_ * x + z1_;
    z1_ = b1_ * x - a1_ * y + z2_;
    z2_ = b2_ * x - a2_ * y;
    return y;
}
void Biquad::highPass(float sr, float f, float q) {
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w), a = s / (2.0f * q);
    set((1+c)/2, -(1+c), (1+c)/2, 1+a, -2*c, 1-a);
}
void Biquad::peaking(float sr, float f, float q, float gainDb) {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w), a = s / (2.0f * q);
    set(1+a*A, -2*c, 1-a*A, 1+a/A, -2*c, 1-a/A);
}
void Biquad::highShelf(float sr, float f, float gainDb) {
    const float A = std::pow(10.0f, gainDb / 40.0f);
    const float w = 2.0f * PI * f / sr, c = std::cos(w), s = std::sin(w);
    const float beta = std::sqrt(A + A);
    set(
        A*((A+1)+(A-1)*c+beta*s),
        -2*A*((A-1)+(A+1)*c),
        A*((A+1)+(A-1)*c-beta*s),
        (A+1)-(A-1)*c+beta*s,
        2*((A-1)-(A+1)*c),
        (A+1)-(A-1)*c-beta*s
    );
}

void DspProcessors::preprocess(std::vector<float>& audio, int sr, float noiseAmount) {
    noiseAmount = std::clamp(noiseAmount, 0.0f, 1.0f);
    Biquad hp;
    hp.highPass(static_cast<float>(sr), 72.0f, 0.7071f);

    // Adaptive soft gate: preserve breaths, suppress the low-level room floor.
    const float threshold = 0.0025f + 0.0120f * noiseAmount;
    const float attack = std::exp(-1.0f / (0.003f * sr));
    const float release = std::exp(-1.0f / (0.080f * sr));
    float env = 0.0f, gain = 1.0f;
    float dcX = 0.0f, dcY = 0.0f;

    for (float& s : audio) {
        const float dc = s - dcX + 0.995f * dcY;
        dcX = s; dcY = dc;
        float x = hp.process(dc);
        const float a = std::abs(x);
        env = a > env ? attack * env + (1-attack) * a : release * env + (1-release) * a;
        float target = 1.0f;
        if (env < threshold) {
            const float t = std::clamp(env / std::max(threshold, 1e-6f), 0.0f, 1.0f);
            target = (0.15f + 0.85f * t * t) * (1.0f - 0.35f * noiseAmount) + 0.35f * noiseAmount;
        }
        const float gCoef = target < gain ? 0.92f : 0.995f;
        gain = gCoef * gain + (1.0f - gCoef) * target;
        s = x * gain;
    }
}

void DspProcessors::master(std::vector<float>& audio, int sr,
                           float deEsserAmount, float compressionAmount, float reverbAmount) {
    deEsserAmount = std::clamp(deEsserAmount, 0.0f, 1.0f);
    compressionAmount = std::clamp(compressionAmount, 0.0f, 1.0f);
    reverbAmount = std::clamp(reverbAmount, 0.0f, 0.5f);

    // Musical vocal EQ.
    Biquad mud, presence, air;
    mud.peaking(static_cast<float>(sr), 260.0f, 1.0f, -1.4f - compressionAmount * 0.8f);
    presence.peaking(static_cast<float>(sr), 3200.0f, 0.85f, 1.3f + compressionAmount * 1.2f);
    air.highShelf(static_cast<float>(sr), 9000.0f, 1.2f + deEsserAmount * 0.5f);

    // De-esser sidechain.
    Biquad sibilance;
    sibilance.highPass(static_cast<float>(sr), 5200.0f, 0.7071f);
    const float deThreshold = dbToGain(-27.0f + 6.0f * (1.0f - deEsserAmount));
    const float deAttack = std::exp(-1.0f / (0.0015f * sr));
    const float deRelease = std::exp(-1.0f / (0.055f * sr));
    float deEnv = 0.0f;

    // Compressor.
    const float thresholdDb = -14.0f - 8.0f * compressionAmount;
    const float ratio = 1.8f + 3.6f * compressionAmount;
    const float compAttack = std::exp(-1.0f / (0.006f * sr));
    const float compRelease = std::exp(-1.0f / (0.095f * sr));
    const float makeup = dbToGain(1.0f + 3.5f * compressionAmount);
    float compEnv = 0.0f, compGain = 1.0f;

    for (float& s : audio) {
        float x = mud.process(s);
        x = presence.process(x);
        x = air.process(x);

        const float sib = std::abs(sibilance.process(x));
        deEnv = sib > deEnv ? deAttack * deEnv + (1-deAttack)*sib : deRelease * deEnv + (1-deRelease)*sib;
        float deGain = 1.0f;
        if (deEnv > deThreshold && deEsserAmount > 0.0f) {
            const float over = deEnv / deThreshold;
            deGain = 1.0f / (1.0f + (over - 1.0f) * 1.8f * deEsserAmount);
            deGain = std::max(deGain, dbToGain(-8.0f * deEsserAmount));
        }
        x *= deGain;

        const float level = std::abs(x);
        compEnv = level > compEnv ? compAttack*compEnv + (1-compAttack)*level
                                  : compRelease*compEnv + (1-compRelease)*level;
        const float levelDb = gainToDb(compEnv);
        float targetGain = 1.0f;
        if (levelDb > thresholdDb) {
            const float outDb = thresholdDb + (levelDb - thresholdDb) / ratio;
            targetGain = dbToGain(outDb - levelDb);
        }
        const float cg = targetGain < compGain ? 0.75f : 0.995f;
        compGain = cg * compGain + (1-cg) * targetGain;
        x *= compGain * makeup;

        // Very light analog-style saturation for density.
        const float drive = 1.08f + 0.32f * compressionAmount;
        s = std::tanh(x * drive) / std::tanh(drive);
    }

    // Schroeder plate-style reverb, mixed in parallel.
    if (reverbAmount > 0.001f) {
        Comb c1(static_cast<int>(0.0297f * sr));
        Comb c2(static_cast<int>(0.0371f * sr));
        Comb c3(static_cast<int>(0.0411f * sr));
        Comb c4(static_cast<int>(0.0437f * sr));
        Allpass a1(static_cast<int>(0.0050f * sr));
        Allpass a2(static_cast<int>(0.0017f * sr));
        const float wet = reverbAmount;
        for (float& s : audio) {
            const float dry = s;
            float r = (c1.process(dry) + c2.process(dry) + c3.process(dry) + c4.process(dry)) * 0.25f;
            r = a2.process(a1.process(r));
            s = dry * (1.0f - wet * 0.30f) + r * wet;
        }
    }

    // Fast peak limiter with smooth release.
    const float limit = dbToGain(-1.0f);
    const float release = std::exp(-1.0f / (0.060f * sr));
    float limiterGain = 1.0f;
    for (float& s : audio) {
        const float a = std::abs(s);
        const float target = a > limit ? limit / std::max(a, 1e-9f) : 1.0f;
        limiterGain = target < limiterGain ? target : release * limiterGain + (1-release) * target;
        s *= limiterGain;
    }
}

void DspProcessors::normalize(std::vector<float>& audio, float targetPeak) {
    float peak = 0.0f;
    for (float v : audio) peak = std::max(peak, std::abs(v));
    if (peak < 1e-6f) return;
    float gain = targetPeak / peak;
    gain = std::clamp(gain, 0.30f, 2.2f);
    for (float& v : audio) v = std::clamp(v * gain, -0.999f, 0.999f);
}

#pragma once
#include <string>

struct VocalParams {
    int rootPitchClass = 0;
    int scaleMode = 0;
    float strength = 0.95f;
    float retuneMs = 20.0f;
    float humanize = 0.25f;
    float noiseReduction = 0.35f;
    float deEsser = 0.45f;
    float compression = 0.60f;
    float reverb = 0.18f;
};

class VocalEngine {
public:
    static int processFile(const std::string& inputPath, const std::string& outputPath,
                           const VocalParams& params, std::string& error);
    static const char* version();
};

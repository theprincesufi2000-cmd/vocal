-keep class com.mustafa.vocalstudio.dsp.NativeDsp { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

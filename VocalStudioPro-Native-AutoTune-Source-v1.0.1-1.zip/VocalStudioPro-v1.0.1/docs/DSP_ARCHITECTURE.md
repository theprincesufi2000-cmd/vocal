# DSP Architecture

## Processing graph

```text
Input file / microphone
  -> decode PCM
  -> mono float 48 kHz
  -> DC blocker
  -> high-pass (~72 Hz)
  -> adaptive soft gate
  -> YIN F0 detector
  -> voiced confidence + note tracking
  -> musical scale quantizer
  -> correction smoothing (retune)
  -> humanize / strength blend
  -> dynamic STFT phase-vocoder pitch correction
  -> latency trim
  -> vocal EQ
  -> de-esser
  -> compressor
  -> soft saturation
  -> parallel plate-style reverb
  -> peak limiter
  -> normalization
  -> PCM 24-bit WAV / 48 kHz
```

## Pitch correction

For each analysis frame, YIN estimates fundamental frequency `F0`. The engine converts F0 to a floating MIDI note:

```text
midi = 69 + 12 * log2(F0 / 440)
```

The quantizer searches for the nearest allowed pitch class in the selected Major or Natural Minor scale. The distance between detected and target MIDI notes becomes a semitone correction. Strength and humanize attenuate that correction; retune controls temporal smoothing.

The phase-vocoder receives a continuously updated pitch ratio, so the file is not shifted by one fixed number of semitones.

## Formant note

This self-contained engine prioritizes offline portability and does not bundle a third-party formant-preserving library. Mild spectral-envelope stability comes from the small dynamic corrections and post chain, but very large pitch corrections can still alter timbre. For a later premium engine, Signalsmith Stretch or a dedicated PSOLA/formant-envelope stage can be integrated behind the same JNI API without changing the UI.

## Recommended input

- Isolated monophonic lead vocal.
- Dry recording with minimal room reverb.
- Correct musical key.
- Avoid clipping during capture.
- Keep microphone distance stable.

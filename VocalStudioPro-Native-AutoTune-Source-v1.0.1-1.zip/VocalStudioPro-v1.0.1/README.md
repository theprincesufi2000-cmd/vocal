# Vocal Studio Pro

تطبيق Android Native لمعالجة الغناء محليًا بالكامل على الهاتف. المشروع مكتوب بـ **Kotlin + Jetpack Compose + C++17/Android NDK + JNI** ولا يحتاج Flutter أو خادم أو API لمعالجة الصوت.

## الميزات

- تسجيل صوت خام داخل التطبيق بصيغة WAV مع محاولة تعطيل AGC/AEC/Noise Suppression الخاصة بالنظام لتقليل التلوين قبل المعالجة.
- استيراد WAV مباشرة، وفك الصيغ التي يدعمها MediaCodec في الجهاز مثل MP3/M4A/AAC/FLAC/OGG إلى PCM قبل المعالجة.
- اختيار الجذر الموسيقي C..B مع Major أو Natural Minor.
- Pitch Detection حقيقي باستخدام YIN.
- Scale Quantizer لتحديد أقرب نغمة مسموحة داخل المقام.
- Dynamic Phase-Vocoder Pitch Correction لتغيير مقدار التصحيح مع النغمة المكتشفة، وليس Pitch Shift ثابتًا.
- Retune Speed + Strength + Humanize.
- سلسلة DSP بعد التصحيح: High-pass، adaptive gate، Vocal EQ، De-Esser، Compressor، saturation، Plate-style reverb، limiter، normalization.
- Presets: Natural / Modern / Hard Tune.
- معاينة waveform وتشغيل التسجيل الأصلي والناتج.
- تصدير WAV نهائي **48 kHz / 24-bit PCM / mono**.
- المعالجة Offline بالكامل.

> للحصول على أفضل نتيجة استخدم Vocal منفردًا وجافًا قدر الإمكان، بدون موسيقى في نفس الملف، واختر المقام الصحيح. تصحيح النغمة والمعالجة يمكن أن يحسّنا الأداء بشكل كبير، لكن لا يمكن تقنيًا ضمان جعل أي خامة صوت مطابقة 100% لمغنٍ آخر؛ ذلك يتطلب تسجيلًا وأداءً وخامة صوت وبيئة مناسبة، وقد يدخل في Voice Conversion مختلف عن Auto‑Tune.

## البنية

```text
Jetpack Compose UI
        ↓
StudioViewModel
        ↓
NativeDsp.kt
        ↓ JNI
C++ VocalEngine
        ├─ WAV loader/resampler
        ├─ YIN F0 detector
        ├─ scale quantizer
        ├─ dynamic phase vocoder
        ├─ vocal DSP/mastering
        └─ 24-bit WAV writer
```

## متطلبات البناء

- JDK 17
- Android SDK Platform 37
- Android NDK `28.2.13676358`
- CMake `3.22.1`
- Gradle `9.6.0`
- Android Gradle Plugin `9.4.0`
- Compose Compiler plugin / Kotlin `2.3.21`

Android Studio يستطيع تثبيت مكونات SDK/NDK/CMake المطلوبة عند Sync. ويمكن أيضًا استخدام GitHub Actions المرفق في `.github/workflows/build.yml`.

## البناء محليًا

Linux/macOS:

```bash
chmod +x gradlew
./gradlew :app:assembleDebug
```

Windows:

```bat
gradlew.bat :app:assembleDebug
```

ملف `gradlew` في المشروع يستطيع تنزيل Gradle 9.6 تلقائيًا عند عدم وجود Gradle محليًا. يحتاج أول Build إلى الإنترنت لتنزيل Gradle وAndroidX إذا لم تكن موجودة في الكاش.

### Release

```bash
./gradlew :app:assembleRelease
```

الناتج الافتراضي غير الموقّع/الموقّع بمفتاح build حسب إعداد Gradle يوجد داخل:

```text
app/build/outputs/apk/
```

للتوزيع الفعلي أضف Signing Config بمفتاحك JKS ولا تضع المفتاح أو كلمات المرور داخل Git.

## الاستخدام

1. افتح التطبيق.
2. اضغط **تسجيل** أو **استيراد صوت**.
3. اختر Key والمود Major/Minor.
4. اختر Natural أو Modern أو Hard Tune، أو عدّل القيم يدويًا.
5. اضغط **تحسين الصوت**.
6. استمع إلى Before/After.
7. اضغط **تنزيل WAV** واختر مكان الحفظ.

## إعدادات الـ Presets

- **Natural**: تصحيح أبطأ وأكثر Humanize للحفاظ على انتقالات المغني.
- **Modern**: تصحيح أقوى وسريع مناسب لمعظم الغناء الحديث.
- **Hard Tune**: Retune شديد السرعة وتأثير Auto‑Tune واضح.

## ملاحظات جودة مهمة

- المحرك يعالج داخليًا عند 48 kHz Float ثم يخرج 24-bit PCM.
- ملفات Stereo يتم Downmix لها إلى mono لأن المشروع مخصص لـ lead vocal منفرد.
- YIN مضبوط تقريبًا على نطاق 70–1000 Hz، وهو مناسب لمعظم الغناء البشري الأساسي.
- ملفات WAV PCM/Float هي المسار الأكثر ثباتًا. دعم الصيغ المضغوطة عند الاستيراد يعتمد على decoder الموجود في Android الجهاز.
- الـ reverb مدمج DSP وليس FFmpegKit؛ لا يوجد اعتماد على مشروع FFmpegKit المتوقف.

## الاختبار

تمت مراجعة وتجميع ملفات C++ وواجهة JNI على مستوى host compiler، كما تم تشغيل اختبار DSP اصطناعي: نغمة قريبة من C#4 مع C Major صُححت إلى D4 تقريبًا، مع إنتاج WAV 48 kHz/24-bit والحفاظ على المدة.

## الترخيص

كود المشروع المولد هنا مرفق بترخيص MIT. تبعيات AndroidX/Gradle/Android SDK تخضع لتراخيصها الخاصة ولا تُضمّن مصادرها في هذا المستودع.

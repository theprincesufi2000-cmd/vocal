# Third-party notices

The native DSP source under `app/src/main/cpp` is self-contained project code and does not embed FFmpegKit, SoundTouch, aubio, Autotalent, or Signalsmith Stretch.

The Android application references AndroidX / Jetpack Compose artifacts from Google's Maven repositories during build. Those components remain subject to their respective licenses.

The Android SDK, Android NDK, CMake, Gradle and Android Gradle Plugin are build tools and are not redistributed inside this source archive.
